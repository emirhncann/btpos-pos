import { useState, useEffect, useRef } from 'react'
import LicenseBanner from '../components/LicenseBanner'
import { useLicenseCheck } from '../hooks/useLicenseCheck'

interface CartItem extends ProductRow {
  quantity: number
  lineTotal: number
}

interface Props {
  companyId: string
  cashier: CashierRow
  allProducts: ProductRow[]
  onBack: () => void
  onLogout: () => void
}

let receiptCounter = parseInt(localStorage.getItem('receipt_counter') || '1000')

function nextReceiptNo(): string {
  receiptCounter++
  localStorage.setItem('receipt_counter', String(receiptCounter))
  return `FIS-${receiptCounter}`
}

export default function POSScreen({ companyId, cashier, allProducts, onBack, onLogout }: Props) {
  const [cart, setCart]             = useState<CartItem[]>([])
  const [search, setSearch]         = useState('')
  const [paymentMode, setPaymentMode] = useState(false)
  const [paymentType, setPaymentType] = useState<'cash' | 'card' | 'mixed'>('cash')
  const [cashInput, setCashInput]   = useState('')
  const [saving, setSaving]         = useState(false)
  const [lastReceipt, setLastReceipt] = useState<string | null>(null)
  const searchRef = useRef<HTMLInputElement>(null)
  const license   = useLicenseCheck(companyId)

  useEffect(() => {
    searchRef.current?.focus()
  }, [])

  useEffect(() => {
    if (search.length < 2) return

    const timeout = setTimeout(() => {
      const byBarcode = allProducts.find(p => p.barcode === search)
      if (byBarcode) {
        addToCart(byBarcode)
        setSearch('')
      }
    }, 300)

    return () => clearTimeout(timeout)
  }, [search, allProducts])

  function addToCart(product: ProductRow, qty = 1) {
    setCart(prev => {
      const existing = prev.find(c => c.id === product.id)
      if (existing) {
        return prev.map(c =>
          c.id === product.id
            ? { ...c, quantity: c.quantity + qty, lineTotal: (c.quantity + qty) * c.price }
            : c
        )
      }
      return [...prev, { ...product, quantity: qty, lineTotal: qty * product.price }]
    })
  }

  function updateQty(id: string, delta: number) {
    setCart(prev => prev
      .map(c => c.id === id ? { ...c, quantity: c.quantity + delta, lineTotal: (c.quantity + delta) * c.price } : c)
      .filter(c => c.quantity > 0)
    )
  }

  function removeFromCart(id: string) {
    setCart(prev => prev.filter(c => c.id !== id))
  }

  const total       = cart.reduce((sum, c) => sum + c.lineTotal, 0)
  const cashAmount  = parseFloat(cashInput) || 0
  const change      = cashAmount - total

  const filtered = search.length >= 2
    ? allProducts.filter(p =>
        p.name.toLowerCase().includes(search.toLowerCase()) ||
        (p.code ?? '').toLowerCase().includes(search.toLowerCase())
      ).slice(0, 20)
    : []

  async function completeSale() {
    if (cart.length === 0) return
    setSaving(true)
    try {
      const receiptNo = nextReceiptNo()
      const saleData: SaleRow = {
        receiptNo,
        totalAmount: total,
        paymentType,
        cashAmount: paymentType === 'card'  ? 0 : cashAmount || total,
        cardAmount: paymentType === 'cash'  ? 0 : (paymentType === 'card' ? total : total - cashAmount),
      }

      const items: SaleItem[] = cart.map(c => ({
        productId:   c.id,
        productName: c.name,
        quantity:    c.quantity,
        unitPrice:   c.price,
        vatRate:     c.vatRate ?? 18,
        lineTotal:   c.lineTotal,
      }))

      await window.electron.db.saveSale(saleData, items)

      setLastReceipt(receiptNo)
      setCart([])
      setPaymentMode(false)
      setCashInput('')
      setSearch('')
      searchRef.current?.focus()
    } catch (e) {
      alert('Satış kaydedilemedi: ' + (e instanceof Error ? e.message : 'Hata'))
    } finally {
      setSaving(false)
    }
  }

  return (
    <div className="flex flex-col h-screen bg-gray-950 text-white overflow-hidden">
      {license?.warning && (
        <LicenseBanner daysLeft={license.daysLeft} planName={license.planName} />
      )}

      <div className="flex flex-1 overflow-hidden">
        {/* SOL — Ürün arama */}
        <div className="flex-1 flex flex-col border-r border-gray-800">
          <div className="flex items-center gap-3 px-4 py-3 bg-gray-900 border-b border-gray-800">
            <button
              onClick={onBack}
              className="text-gray-400 hover:text-white text-sm px-3 py-1.5 rounded-lg hover:bg-gray-800 transition-colors"
            >
              ← Ürünler
            </button>
            <h2 className="text-sm font-semibold text-gray-300">Satış Ekranı</h2>
            <span className="text-xs text-gray-500">
              Kasiyer: <span className="text-gray-300">{cashier.fullName}</span>
            </span>
            <button
              onClick={onLogout}
              className="ml-auto text-gray-500 hover:text-red-400 text-xs px-2 py-1 rounded hover:bg-gray-800 transition-colors"
            >
              Çıkış
            </button>
            {lastReceipt && (
              <span className="text-xs text-green-400 bg-green-500/10 border border-green-500/20 px-3 py-1 rounded-full">
                ✓ {lastReceipt} kaydedildi
              </span>
            )}
          </div>

          <div className="px-4 py-3 border-b border-gray-800">
            <input
              ref={searchRef}
              type="text"
              value={search}
              onChange={e => setSearch(e.target.value)}
              placeholder="Ürün adı, kodu veya barkod okut..."
              className="w-full bg-gray-800 text-white border border-gray-700 rounded-lg px-4 py-2.5 text-sm focus:outline-none focus:border-blue-500"
            />
          </div>

          <div className="flex-1 overflow-auto p-4">
            {filtered.length > 0 ? (
              <div className="grid grid-cols-2 lg:grid-cols-3 gap-2">
                {filtered.map(p => (
                  <button
                    key={p.id}
                    onClick={() => { addToCart(p); setSearch(''); searchRef.current?.focus() }}
                    className="text-left bg-gray-900 border border-gray-800 hover:border-blue-500/50 hover:bg-gray-800 rounded-xl p-3 transition-all"
                  >
                    <p className="text-xs text-gray-500 font-mono">{p.code}</p>
                    <p className="text-sm font-medium text-white mt-0.5 line-clamp-2">{p.name}</p>
                    <p className="text-blue-400 font-bold mt-1">
                      {p.price?.toLocaleString('tr-TR', { minimumFractionDigits: 2 })} ₺
                    </p>
                  </button>
                ))}
              </div>
            ) : (
              <div className="flex items-center justify-center h-full text-gray-600 text-sm">
                {search.length < 2
                  ? 'Ürün aramak için yazmaya başlayın veya barkod okutun'
                  : 'Sonuç bulunamadı'}
              </div>
            )}
          </div>
        </div>

        {/* SAĞ — Sepet */}
        <div className="w-96 flex flex-col bg-gray-900">
          <div className="px-4 py-3 border-b border-gray-800">
            <h3 className="font-semibold text-sm">
              Sepet {cart.length > 0 && <span className="text-gray-400 font-normal">({cart.length} ürün)</span>}
            </h3>
          </div>

          <div className="flex-1 overflow-auto">
            {cart.length === 0 ? (
              <div className="flex items-center justify-center h-full text-gray-600 text-sm">
                Sepet boş
              </div>
            ) : (
              <div className="divide-y divide-gray-800">
                {cart.map(item => (
                  <div key={item.id} className="px-4 py-3 flex items-start gap-3">
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-medium text-white leading-tight truncate">{item.name}</p>
                      <p className="text-xs text-gray-500 mt-0.5">
                        {item.price?.toLocaleString('tr-TR', { minimumFractionDigits: 2 })} ₺ / {item.unit}
                      </p>
                    </div>
                    <div className="flex items-center gap-2 shrink-0">
                      <button onClick={() => updateQty(item.id, -1)} className="w-7 h-7 rounded-lg bg-gray-800 hover:bg-gray-700 text-white text-sm font-bold flex items-center justify-center">−</button>
                      <span className="w-8 text-center text-sm font-semibold">{item.quantity}</span>
                      <button onClick={() => updateQty(item.id, 1)} className="w-7 h-7 rounded-lg bg-gray-800 hover:bg-gray-700 text-white text-sm font-bold flex items-center justify-center">+</button>
                      <button onClick={() => removeFromCart(item.id)} className="w-7 h-7 rounded-lg bg-red-500/20 hover:bg-red-500/40 text-red-400 text-sm flex items-center justify-center ml-1">✕</button>
                    </div>
                    <div className="w-20 text-right shrink-0">
                      <p className="text-sm font-bold text-white">
                        {item.lineTotal?.toLocaleString('tr-TR', { minimumFractionDigits: 2 })} ₺
                      </p>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>

          <div className="border-t border-gray-800 p-4 space-y-3">
            <div className="flex justify-between items-center">
              <span className="text-gray-400 text-sm">Toplam</span>
              <span className="text-2xl font-bold text-white">
                {total.toLocaleString('tr-TR', { minimumFractionDigits: 2 })} ₺
              </span>
            </div>

            {!paymentMode ? (
              <button
                onClick={() => setPaymentMode(true)}
                disabled={cart.length === 0}
                className="w-full bg-blue-600 hover:bg-blue-500 disabled:bg-gray-700 disabled:text-gray-500 text-white font-bold py-3.5 rounded-xl transition-colors text-sm"
              >
                Ödeme Al
              </button>
            ) : (
              <div className="space-y-3">
                <div className="grid grid-cols-3 gap-1.5">
                  {(['cash', 'card', 'mixed'] as const).map(t => (
                    <button
                      key={t}
                      onClick={() => setPaymentType(t)}
                      className={`py-2 rounded-lg text-xs font-semibold transition-colors ${
                        paymentType === t ? 'bg-blue-600 text-white' : 'bg-gray-800 text-gray-400 hover:bg-gray-700'
                      }`}
                    >
                      {t === 'cash' ? '💵 Nakit' : t === 'card' ? '💳 Kart' : '🔀 Karma'}
                    </button>
                  ))}
                </div>

                {(paymentType === 'cash' || paymentType === 'mixed') && (
                  <div>
                    <label className="text-xs text-gray-400 block mb-1">
                      {paymentType === 'mixed' ? 'Nakit Tutar (₺)' : 'Alınan Nakit (₺)'}
                    </label>
                    <input
                      type="number"
                      value={cashInput}
                      onChange={e => setCashInput(e.target.value)}
                      placeholder="0,00"
                      className="w-full bg-gray-800 border border-gray-700 text-white rounded-lg px-3 py-2 text-sm focus:outline-none focus:border-blue-500"
                      autoFocus
                    />
                    {paymentType === 'cash' && cashAmount >= total && (
                      <p className="text-green-400 text-xs mt-1 font-medium">
                        Para Üstü: {change.toLocaleString('tr-TR', { minimumFractionDigits: 2 })} ₺
                      </p>
                    )}
                  </div>
                )}

                <div className="grid grid-cols-2 gap-2">
                  <button
                    onClick={() => { setPaymentMode(false); setCashInput('') }}
                    className="bg-gray-800 hover:bg-gray-700 text-gray-300 py-3 rounded-xl text-sm font-medium transition-colors"
                  >
                    İptal
                  </button>
                  <button
                    onClick={completeSale}
                    disabled={saving || (paymentType === 'cash' && cashAmount < total)}
                    className="bg-green-600 hover:bg-green-500 disabled:bg-gray-700 disabled:text-gray-500 text-white py-3 rounded-xl text-sm font-bold transition-colors"
                  >
                    {saving ? 'Kaydediliyor...' : 'Tamamla ✓'}
                  </button>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  )
}
