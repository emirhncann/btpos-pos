import { useEffect, useState } from 'react'
import ActivationScreen   from './screens/ActivationScreen'
import CashierLoginScreen from './screens/CashierLoginScreen'
import ProductsScreen     from './screens/ProductsScreen'
import POSScreen          from './screens/POSScreen'

type AppState = 'loading' | 'activation' | 'cashier_login' | 'products' | 'pos'

export default function App() {
  const [state, setState]             = useState<AppState>('loading')
  const [companyId, setCompanyId]     = useState<string | null>(null)
  const [cashier, setCashier]         = useState<CashierRow | null>(null)
  const [allProducts, setAllProducts] = useState<ProductRow[]>([])

  useEffect(() => {
    checkActivation()
  }, [])

  async function checkActivation() {
    const activated       = await window.electron.store.get('activated')
    const storedCompanyId = await window.electron.store.get('company_id')

    if (activated && storedCompanyId) {
      setCompanyId(storedCompanyId as string)
      setState('cashier_login')
    } else {
      setState('activation')
    }
  }

  function handleActivated(cId: string) {
    setCompanyId(cId)
    setState('cashier_login')
  }

  function handleCashierLogin(c: CashierRow) {
    setCashier(c)
    setState('products')
  }

  function handleStartSale(products: ProductRow[]) {
    setAllProducts(products)
    setState('pos')
  }

  function handleLogout() {
    setCashier(null)
    setState('cashier_login')
  }

  if (state === 'loading') {
    return (
      <div className="flex h-screen items-center justify-center bg-gray-950">
        <div className="text-white text-lg animate-pulse">BTPOS Yükleniyor...</div>
      </div>
    )
  }

  if (state === 'activation') {
    return <ActivationScreen onActivated={handleActivated} />
  }

  if (state === 'cashier_login') {
    return <CashierLoginScreen companyId={companyId!} onLogin={handleCashierLogin} />
  }

  if (state === 'pos') {
    return (
      <POSScreen
        companyId={companyId!}
        cashier={cashier!}
        allProducts={allProducts}
        onBack={() => setState('products')}
        onLogout={handleLogout}
      />
    )
  }

  return (
    <ProductsScreen
      companyId={companyId!}
      cashier={cashier!}
      onStartSale={handleStartSale}
      onLogout={handleLogout}
    />
  )
}
