import { writeFileSync, unlinkSync } from 'fs'
import { tmpdir } from 'os'
import { join } from 'path'
import { BrowserWindow } from 'electron'
import type { IpcMain } from 'electron'
import type Database from 'better-sqlite3'
import {
  DEFAULT_PRINT_BEHAVIOR,
  normalizePrintBehavior,
  type PrintBehavior,
  type RenderData,
} from '../src/lib/templateEngine'
import { isPdfmeTemplate, renderPdfme, renderThermalReceipt } from './pdfmeRenderer'
import {
  isPrinterActive,
  printReceipt,
  settingsRowToConfig,
  type PrinterSettingsRow,
} from './printerService'

function getPrintBehavior(db: Database.Database, cashierId?: string | null): Record<string, PrintBehavior> {
  if (!cashierId) return { ...DEFAULT_PRINT_BEHAVIOR }
  const row = db.prepare(
    `SELECT print_behavior FROM cashier_settings_cache WHERE cashier_id = ?`,
  ).get(cashierId) as { print_behavior?: string | null } | undefined
  if (!row?.print_behavior) return { ...DEFAULT_PRINT_BEHAVIOR }
  try {
    return normalizePrintBehavior(JSON.parse(row.print_behavior))
  } catch {
    return { ...DEFAULT_PRINT_BEHAVIOR }
  }
}

function getDefaultTemplateIds(db: Database.Database): Record<string, string> {
  const row = db.prepare(
    `SELECT default_template_ids FROM terminal_settings_cache WHERE id = 1`,
  ).get() as { default_template_ids?: string | null } | undefined
  if (!row?.default_template_ids) return {}
  try {
    const parsed = JSON.parse(row.default_template_ids) as Record<string, unknown>
    const out: Record<string, string> = {}
    for (const [k, v] of Object.entries(parsed)) {
      if (v != null && String(v).trim()) out[k] = String(v)
    }
    return out
  } catch {
    return {}
  }
}

async function doPrint(
  db: Database.Database,
  templateId: string,
  data: RenderData,
): Promise<{ success: boolean; message?: string }> {
  try {
    const tpl = db.prepare('SELECT * FROM receipt_templates WHERE id = ?').get(templateId) as {
      id: string
      schema: string
      paper_width_mm: number
      paper_height_mm: number | null
      template_type: string
    } | undefined

    if (!tpl) return { success: false, message: 'Şablon bulunamadı' }

    let templateJson: unknown
    try {
      templateJson = typeof tpl.schema === 'string'
        ? JSON.parse(tpl.schema)
        : tpl.schema
    } catch {
      return { success: false, message: 'Şablon JSON parse hatası' }
    }

    if (!isPdfmeTemplate(templateJson)) {
      return { success: false, message: 'Geçersiz pdfme şablonu — schemas veya basePdf eksik' }
    }

    const bp = (templateJson as { basePdf?: { width?: number } }).basePdf
    const paperW = Number((bp && typeof bp === 'object' && bp.width) || tpl.paper_width_mm || 80)
    const isThermal = tpl.template_type !== 'pdf'

    console.log('[doPrint] tür:', tpl.template_type, 'kağıt:', paperW, 'mm, termal:', isThermal)

    if (isThermal) {
      const printerCfg = getPrinterRow(db)
      if (!printerCfg || !isPrinterActive(printerCfg)) {
        return { success: false, message: 'Fiş yazıcısı tanımlı değil' }
      }
      const printerW = Number(printerCfg.paper_width ?? 80)
      if ((printerW <= 58) !== (paperW <= 58)) {
        console.warn(`[doPrint] Şablon ${paperW} mm, yazıcı ${printerW} mm — şablon yazıcıya uygun değil`)
      }
      const escBuf = await renderThermalReceipt(templateJson, data, paperW)
      await printReceipt(settingsRowToConfig(printerCfg), escBuf)
    } else {
      const doc = db.prepare('SELECT printer_name FROM document_printer_settings WHERE id = 1')
        .get() as { printer_name?: string | null } | undefined
      if (!doc?.printer_name) {
        return { success: false, message: 'Belge yazıcısı tanımlı değil (Cihazlar › Belge yazıcısı)' }
      }
      const pdfBuf = await renderPdfme(templateJson, data)
      await printPdfBuffer(db, pdfBuf, { printer_name: doc.printer_name } as PrinterSettingsRow)
    }
    return { success: true }
  } catch (e) {
    console.error('[doPrint]', e)
    return { success: false, message: String(e) }
  }
}

function getPrinterRow(db: Database.Database): PrinterSettingsRow | undefined {
  return db.prepare('SELECT * FROM printer_settings LIMIT 1').get() as PrinterSettingsRow | undefined
}

async function printPdfBuffer(
  db: Database.Database,
  pdfBuf: Buffer,
  printerCfg: PrinterSettingsRow,
): Promise<void> {
  const win = new BrowserWindow({ show: false })
  const tmpPath = join(tmpdir(), `btpos-receipt-${Date.now()}.pdf`)
  writeFileSync(tmpPath, pdfBuf)
  try {
    await win.loadURL(`file://${tmpPath.replace(/\\/g, '/')}`)
    await new Promise<void>((resolve, reject) => {
      const deviceName = printerCfg.printer_name
        ? String(printerCfg.printer_name)
        : undefined
      win.webContents.print(
        { silent: true, printBackground: true, deviceName },
        (success, failureReason) => {
          if (success) resolve()
          else reject(new Error(failureReason ?? 'PDF yazdırılamadı'))
        },
      )
    })
  } finally {
    if (!win.isDestroyed()) win.close()
    try {
      unlinkSync(tmpPath)
    } catch {
      /* yok say */
    }
  }
}

function normalizeTemplateRow(t: Record<string, unknown>) {
  return {
    id:              String(t.id ?? ''),
    name:            String(t.name ?? ''),
    trigger_type:    String(t.trigger_type ?? t.triggerType ?? ''),
    template_type:   String(t.template_type ?? t.templateType ?? 'thermal'),
    paper_width_mm:  Number(t.paper_width_mm ?? t.paperWidthMm ?? 80),
    paper_height_mm: t.paper_height_mm != null || t.paperHeightMm != null
      ? Number(t.paper_height_mm ?? t.paperHeightMm)
      : null,
    schema: typeof t.schema === 'string' ? t.schema : JSON.stringify(t.schema ?? []),
    is_default:      t.is_default === true || t.is_default === 1 || t.isDefault === true ? 1 : 0,
  }
}

export function registerTemplatesIpc(ipcMain: IpcMain, db: Database.Database): void {
  db.exec(`
    CREATE TABLE IF NOT EXISTS receipt_templates (
      id               TEXT PRIMARY KEY,
      name             TEXT NOT NULL,
      trigger_type     TEXT NOT NULL,
      template_type    TEXT NOT NULL DEFAULT 'thermal',
      paper_width_mm   INTEGER NOT NULL DEFAULT 80,
      paper_height_mm  INTEGER,
      schema           TEXT NOT NULL DEFAULT '[]',
      is_default       INTEGER DEFAULT 0,
      synced_at        TEXT
    )
  `)

  ipcMain.handle('templates:getAll', () => {
    return db.prepare(
      'SELECT * FROM receipt_templates ORDER BY trigger_type, name',
    ).all()
  })

  ipcMain.handle('templates:getByTrigger', (_e, triggerType: string) => {
    return db.prepare(`
      SELECT * FROM receipt_templates
      WHERE trigger_type = ?
      ORDER BY is_default DESC, name
    `).all(triggerType)
  })

  ipcMain.handle('templates:getDefault', (_e, triggerType: string) => {
    return db.prepare(`
      SELECT * FROM receipt_templates
      WHERE trigger_type = ? AND is_default = 1
      LIMIT 1
    `).get(triggerType)
  })

  ipcMain.handle('templates:save', (_e, templates: unknown[]) => {
    const stmt = db.prepare(`
      INSERT INTO receipt_templates
        (id, name, trigger_type, template_type, paper_width_mm, paper_height_mm, schema, is_default, synced_at)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
      ON CONFLICT(id) DO UPDATE SET
        name            = excluded.name,
        trigger_type    = excluded.trigger_type,
        template_type   = excluded.template_type,
        paper_width_mm  = excluded.paper_width_mm,
        paper_height_mm = excluded.paper_height_mm,
        schema          = excluded.schema,
        is_default      = excluded.is_default,
        synced_at       = excluded.synced_at
    `)
    const syncedAt = new Date().toISOString()

    const syncAll = db.transaction((rows: unknown[]) => {
      const ids: string[] = []
      for (const raw of rows) {
        const t = normalizeTemplateRow(raw as Record<string, unknown>)
        if (t.template_type === 'label') continue
        stmt.run(
          t.id, t.name, t.trigger_type, t.template_type,
          t.paper_width_mm, t.paper_height_mm,
          t.schema, t.is_default, syncedAt,
        )
        ids.push(t.id)
      }
      let deleted = 0
      if (ids.length) {
        const info = db.prepare(
          `DELETE FROM receipt_templates WHERE id NOT IN (${ids.map(() => '?').join(',')})`,
        ).run(...ids)
        deleted = Number(info.changes ?? 0)
      } else {
        const info = db.prepare('DELETE FROM receipt_templates').run()
        deleted = Number(info.changes ?? 0)
      }
      return { count: ids.length, deleted }
    })

    const saved = syncAll(templates)
    return { success: true as const, count: saved.count, deleted: saved.deleted }
  })

  ipcMain.handle('templates:printWithBehavior', async (_e, opts: {
    triggerType: string
    data:        RenderData
    templateId?: string
    cashierId?:  string | null
  }) => {
    try {
      const pb       = getPrintBehavior(db, opts.cashierId)
      const behavior = pb[opts.triggerType] ?? 'none'

      if (behavior === 'none') {
        return { success: true as const, skipped: true as const }
      }

      const templates = db.prepare(`
        SELECT id, name, template_type, is_default, schema
        FROM receipt_templates
        WHERE trigger_type = ?
        ORDER BY is_default DESC, name
      `).all(opts.triggerType) as Array<{
        id: string
        name: string
        template_type: string
        is_default: number
        schema: string
      }>

      const toItem = (t: (typeof templates)[number]) => ({
        id:            String(t.id),
        name:          String(t.name),
        template_type: String(t.template_type),
        is_default:    t.is_default === 1,
        schema:        String(t.schema ?? ''),
      })

      if (!templates.length) {
        return { success: false as const, message: 'Şablon bulunamadı' }
      }

      if (opts.templateId) {
        const tpl = templates.find(t => String(t.id) === opts.templateId)
        if (!tpl) return { success: false as const, message: 'Şablon bulunamadı' }
        return await doPrint(db, tpl.id, opts.data)
      }

      if (templates.length === 1 || behavior === 'default') {
        let chosen = templates[0]
        if (templates.length > 1) {
          const defaultIds = getDefaultTemplateIds(db)
          const configuredId = defaultIds[opts.triggerType]
          chosen = (configuredId
            ? templates.find(t => String(t.id) === configuredId)
            : undefined)
            ?? templates.find(t => t.is_default === 1)
            ?? templates[0]
        }
        return {
          success:      true as const,
          pendingPrint: true as const,
          template:     toItem(chosen),
        }
      }

      if (behavior === 'ask') {
        return {
          success:        true as const,
          needsSelection: true as const,
          templates:      templates.map(toItem),
          data: opts.data,
        }
      }

      return { success: true as const, skipped: true as const }
    } catch (e) {
      return { success: false as const, message: String(e) }
    }
  })
}
