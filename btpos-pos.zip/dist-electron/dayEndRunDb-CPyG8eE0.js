"use strict";
Object.defineProperty(exports, Symbol.toStringTag, { value: "Module" });
const crypto = require("crypto");
const index = require("./index-CZKasiGD.js");
const operations = require("./operations-CbpYi4Uc.js");
const main = require("./main-Bq_q_YP5.js");
const IST_DATE_TIME = {
  timeZone: "Europe/Istanbul",
  day: "2-digit",
  month: "2-digit",
  year: "numeric",
  hour: "2-digit",
  minute: "2-digit",
  hour12: false
};
function formatIstanbulDateTime(iso) {
  if (!iso) return "";
  const d = new Date(iso);
  if (Number.isNaN(d.getTime())) return "";
  return new Intl.DateTimeFormat("tr-TR", IST_DATE_TIME).format(d);
}
function formatIstanbulRange(start, end) {
  const a = formatIstanbulDateTime(start);
  const b = formatIstanbulDateTime(end);
  if (!a || !b) return "";
  return `${a} – ${b}`;
}
function fisLabel(receiptNo) {
  const raw = String(receiptNo ?? "").trim();
  if (/^\d+$/.test(raw)) return raw.padStart(4, "0");
  return raw || "—";
}
function hasIsbasiId(row) {
  return operations.isbasiIdOf(row ?? {}) !== "";
}
function torbaMissingProblem(code) {
  const shown = code.trim() || "—";
  return {
    code: "TORBA_CARI_YOK",
    message: `Torba cari (${shown}) kasada yok. Yönetim panelinden müşteri listesini kasaya gönderin.`
  };
}
function cariMissingProblem(receiptNo, name) {
  const who = name.trim() || "Cari";
  return {
    code: "CARI_ERP_EKSIK",
    message: `Fiş ${fisLabel(receiptNo)}: ${who} carisinin ERP kaydı yok.`
  };
}
function cashAccountProblem() {
  return { code: "NAKIT_HESAP_YOK", message: "Nakit kasa hesabı eşlenmemiş." };
}
function bankAccountProblem(name, acquirerId) {
  const label = name.trim() || "Banka";
  const id = acquirerId.trim() || "—";
  return { code: "BANKA_HESAP_YOK", message: `${label} (${id}) için banka hesabı eşlenmemiş.` };
}
function otherAccountProblem(name) {
  const label = name.trim() || "Ödeme";
  return { code: "ODEME_HESAP_YOK", message: `${label} için hesap eşlenmemiş.` };
}
function lineMissingProblem(receiptNo, productName, kind) {
  const name = productName.trim() || "Ürün";
  const tail = kind === "code" ? "ürün kodu yok" : kind === "unit" ? "birimi yok" : "KDV oranı yok";
  return { code: "KALEM_EKSIK", message: `Fiş ${fisLabel(receiptNo)}: '${name}' ${tail}.` };
}
function collectDayEndProblems(input) {
  const problems = [];
  const seen = /* @__PURE__ */ new Set();
  const add = (problem) => {
    if (seen.has(problem.message)) return;
    seen.add(problem.message);
    problems.push(problem);
  };
  if (input.needsTorba && !input.torbaReady) add(torbaMissingProblem(input.torbaCode));
  for (const sale of input.sales) {
    if (!sale.customerId) continue;
    if (!sale.hasErp) add(cariMissingProblem(sale.receiptNo, sale.customerName));
  }
  let cashMissing = false;
  for (const tender of input.tenders) {
    if (tender.accountMatched) continue;
    if (tender.method === "cash") {
      cashMissing = true;
      continue;
    }
    if (tender.method === "card") {
      add(bankAccountProblem(tender.acquirerName, tender.acquirerId ?? ""));
      continue;
    }
    add(otherAccountProblem(tender.acquirerName || tender.method));
  }
  if (cashMissing) add(cashAccountProblem());
  for (const line of input.lines) {
    if (!line.productCode.trim()) add(lineMissingProblem(line.receiptNo, line.name, "code"));
    if (!line.unit.trim()) add(lineMissingProblem(line.receiptNo, line.name, "unit"));
    if (line.vatRate == null || !Number.isFinite(line.vatRate)) add(lineMissingProblem(line.receiptNo, line.name, "vat"));
  }
  return problems;
}
const PACKAGE_LIMIT = 200;
function chunks(rows, size) {
  const out = [];
  for (let i = 0; i < rows.length; i += size) out.push(rows.slice(i, i + size));
  return out;
}
function parseDayEndMode(value) {
  return String(value ?? "").trim() === "per_sale" ? "per_sale" : "z_single";
}
function planDayEndDocs(rows, mode) {
  const sorted = [...rows].sort((a, b) => {
    const at = new Date(a.createdAt).getTime();
    const bt = new Date(b.createdAt).getTime();
    const delta = (Number.isNaN(at) ? 0 : at) - (Number.isNaN(bt) ? 0 : bt);
    return delta || a.id.localeCompare(b.id);
  });
  const anon = (sale) => !sale.customerId;
  const anonSale = sorted.filter((s) => !s.isReturn && anon(s));
  const anonRefund = sorted.filter((s) => s.isReturn && anon(s));
  const cariSale = sorted.filter((s) => !s.isReturn && !anon(s));
  const cariRefund = sorted.filter((s) => s.isReturn && !anon(s));
  const docs = [];
  if (mode === "per_sale") {
    for (const sale of anonSale) {
      docs.push({ docKey: `sale:${sale.id}`, docKind: "retail_invoice", queueType: "invoice", sales: [sale] });
    }
  } else {
    chunks(anonSale, PACKAGE_LIMIT).forEach((part, index2) => {
      docs.push({ docKey: `retail:${index2 + 1}`, docKind: "retail_invoice", queueType: "invoice", sales: part });
    });
  }
  if (mode === "per_sale") {
    for (const sale of anonRefund) {
      docs.push({ docKey: `refund:${sale.id}`, docKind: "retail_refund", queueType: "return_invoice", sales: [sale] });
    }
  } else {
    chunks(anonRefund, PACKAGE_LIMIT).forEach((part, index2) => {
      docs.push({ docKey: `retail_refund:${index2 + 1}`, docKind: "retail_refund", queueType: "return_invoice", sales: part });
    });
  }
  for (const sale of cariSale) {
    docs.push({ docKey: `sale:${sale.id}`, docKind: "customer_invoice", queueType: "invoice", sales: [sale] });
  }
  for (const sale of cariRefund) {
    docs.push({ docKey: `refund:${sale.id}`, docKind: "customer_refund", queueType: "return_invoice", sales: [sale] });
  }
  return docs;
}
function dayEndDocLabel(rangeLabel, doc) {
  var _a;
  const head = `Gün sonu ${rangeLabel}`;
  if (doc.docKind === "retail_invoice") return `${head} · Perakende faturası (${doc.sales.length} satış)`;
  if (doc.docKind === "retail_refund") return `${head} · İade faturası (${doc.sales.length})`;
  const sale = doc.sales[0];
  const receipt = main.formatReceiptNo((sale == null ? void 0 : sale.receiptNo) ?? "");
  const name = ((_a = sale == null ? void 0 : sale.customerName) == null ? void 0 : _a.trim()) || "Cari";
  if (doc.docKind === "customer_refund") return `${head} · Cari iade · Fiş ${receipt} · ${name}`;
  return `${head} · Cari fatura · Fiş ${receipt} · ${name}`;
}
function dayEndPaymentLabel(rangeLabel, methodLabel2) {
  return `Gün sonu ${rangeLabel} · Tahsilat · ${methodLabel2}`;
}
function nextDayEndReport(reported, statuses) {
  if (statuses.length === 0) return null;
  const open = statuses.some((status) => status === "pending" || status === "processing" || status === "pending_dayend");
  if (open) return reported === "failed" ? "processing" : null;
  if (statuses.some((status) => status === "failed")) return reported === "failed" ? null : "failed";
  if (statuses.every((status) => status === "success")) return reported === "completed" ? null : "completed";
  return null;
}
function paymentDocKey(parentDocKey, method, acquirerId) {
  if (method === "cash") return `pay:${parentDocKey}:cash`;
  if (method === "card") return `pay:${parentDocKey}:card:${acquirerId || "unknown"}`;
  return `pay:${parentDocKey}:${method}:${acquirerId || "other"}`;
}
function round2(n) {
  return Math.round(n * 100) / 100;
}
function loadTenders(saleIds) {
  if (saleIds.length === 0) return [];
  const db = index.getSqlite();
  const placeholders = saleIds.map(() => "?").join(",");
  const rows = db.prepare(`
    SELECT method,
           acquirer_id,
           MAX(acquirer_name) AS acquirer_name,
           SUM(amount) AS total
    FROM sale_payments
    WHERE sale_id IN (${placeholders})
    GROUP BY method, COALESCE(acquirer_id, '')
  `).all(...saleIds);
  return rows.map((row) => ({
    method: String(row.method ?? ""),
    acquirerId: row.acquirer_id ? String(row.acquirer_id) : null,
    acquirerName: String(row.acquirer_name ?? "").trim(),
    amount: round2(Number(row.total ?? 0))
  })).filter((row) => row.amount > 4e-3);
}
function methodLabel(tender) {
  if (tender.method === "cash") return "Nakit";
  if (tender.method === "card") return tender.acquirerName || "Kart";
  if (tender.method === "meal_card") return tender.acquirerName || "Yemek Kartı";
  return tender.acquirerName || "Diğer";
}
function applyDayEndRun(input) {
  const db = index.getSqlite();
  const bound = db.prepare(`SELECT COUNT(*) AS c FROM sales WHERE day_end_run_id = ?`).get(input.runId);
  if (Number((bound == null ? void 0 : bound.c) ?? 0) === 0) {
    const problems = problemsForUnboundRange(db, input);
    if (problems.length > 0) {
      return { empty: false, rejected: true, problems, saleCount: 0, refundCount: 0, docCount: 0, docsTotal: 0 };
    }
  }
  const settings = index.readTerminalSettings(db);
  const invoiceType = settings.invoiceType === "paper" ? "paper" : "e_archive";
  const endpointBase = invoiceType === "paper" ? "invoice-paper" : "invoice";
  const mode = parseDayEndMode(input.invoiceMode);
  const rangeLabel = input.rangeLabel.trim() || formatIstanbulRange(input.rangeStart, input.rangeEnd) || input.rangeStart.slice(0, 10);
  const run = db.transaction(() => {
    var _a, _b, _c;
    const bound2 = db.prepare(`
      SELECT id, created_at, customer_id, customer_name, receipt_no, is_return, net_amount
      FROM sales
      WHERE day_end_run_id = ?
      ORDER BY julianday(created_at) ASC
    `).all(input.runId);
    let source = bound2;
    if (source.length === 0) {
      source = db.prepare(`
        SELECT id, created_at, customer_id, customer_name, receipt_no, is_return, net_amount
        FROM sales
        WHERE julianday(created_at) >= julianday(?)
          AND julianday(created_at) <= julianday(?)
          AND invoice_sent = 0
          AND day_end_run_id IS NULL
        ORDER BY julianday(created_at) ASC
      `).all(input.rangeStart, input.rangeEnd);
      if (source.length === 0) {
        return { empty: true, rejected: false, problems: [], saleCount: 0, refundCount: 0, docCount: 0, docsTotal: 0 };
      }
      const stamp = db.prepare(`UPDATE sales SET day_end_run_id = ? WHERE id = ? AND day_end_run_id IS NULL`);
      for (const row of source) stamp.run(input.runId, String(row.id));
    }
    const briefs = source.map((row) => ({
      id: String(row.id),
      createdAt: String(row.created_at),
      customerId: row.customer_id ? String(row.customer_id) : null,
      customerName: row.customer_name ? String(row.customer_name) : null,
      receiptNo: String(row.receipt_no ?? ""),
      isReturn: Number(row.is_return ?? 0) === 1,
      netAmount: Math.abs(Number(row.net_amount ?? 0))
    }));
    db.prepare(`DELETE FROM day_end_runs WHERE run_id = ? AND status = 'completed_empty'`).run(input.runId);
    const plans = planDayEndDocs(briefs, mode);
    const insert = db.prepare(`
      INSERT OR IGNORE INTO operation_queue (
        id, company_id, type, payload, status, attempts, max_attempts, created_at, label, day_end_run_id, doc_key
      ) VALUES (?, ?, ?, ?, 'pending', 0, 3, ?, ?, ?, ?)
    `);
    const now = (/* @__PURE__ */ new Date()).toISOString();
    let inserted = 0;
    let expectedPayments = 0;
    for (const plan of plans) {
      const saleIds = plan.sales.map((s) => s.id);
      const lines = /* @__PURE__ */ new Map();
      let expected = 0;
      for (const sale of plan.sales) {
        expected = round2(expected + sale.netAmount);
        for (const item of operations.getSaleItems(sale.id)) {
          const qty = Math.abs(Number(item.quantity) || 0);
          const unitPriceGross = Number(item.unitPriceGross ?? item.price);
          const grossAmount = Number(item.grossAmount ?? (unitPriceGross * qty).toFixed(2));
          const discountAmount = Number(item.discountAmount ?? 0);
          const netAmount = Number(item.netAmount ?? (grossAmount - discountAmount).toFixed(2));
          const rate = grossAmount > 0 ? round2(discountAmount / grossAmount * 100) : 0;
          const key = `${item.productCode}|${unitPriceGross}|${item.vatRate}|${rate}`;
          const existing = lines.get(key);
          if (existing) {
            existing.quantity = round2(Number(existing.quantity) + qty);
            existing.gross_amount = round2(Number(existing.gross_amount) + grossAmount);
            existing.discount_amount = round2(Number(existing.discount_amount) + discountAmount);
            existing.net_amount = round2(Number(existing.net_amount) + netAmount);
          } else {
            lines.set(key, {
              product_code: item.productCode,
              name: item.productName ?? item.productCode,
              quantity: qty,
              vatRate: item.vatRate,
              unit: item.unit ?? "Adet",
              product_id: item.productId ? Number.parseInt(item.productId, 10) || 0 : 0,
              unit_price_gross: unitPriceGross,
              gross_amount: grossAmount,
              discount_amount: discountAmount,
              net_amount: netAmount
            });
          }
        }
      }
      const tenders = loadTenders(saleIds);
      expectedPayments += tenders.length;
      const cashAmount = round2(tenders.filter((t) => t.method === "cash").reduce((s, t) => s + t.amount, 0));
      const cardTenders = tenders.filter((t) => t.method === "card");
      const cardByBank = {};
      for (const tender of cardTenders) {
        const key = tender.acquirerId || "unknown";
        const prev = cardByBank[key];
        cardByBank[key] = {
          amount: round2(((prev == null ? void 0 : prev.amount) ?? 0) + tender.amount),
          acquirerName: tender.acquirerName || (prev == null ? void 0 : prev.acquirerName) || ""
        };
      }
      const cardAmount = round2(Object.values(cardByBank).reduce((s, row) => s + row.amount, 0));
      const paymentAccounts = index.matchPaymentAccounts(db, {
        cashAmount,
        cardAmount,
        cardAcquirerId: null,
        cardByBank
      });
      const last = plan.sales[plan.sales.length - 1];
      const customerId = ((_a = plan.sales.find((s) => s.customerId)) == null ? void 0 : _a.customerId) ?? null;
      const customerName = plan.docKind.startsWith("retail") ? ((_b = plan.sales.find((s) => s.customerName)) == null ? void 0 : _b.customerName) || "Perakende" : last.customerName || "Cari";
      const label = dayEndDocLabel(rangeLabel, plan);
      const saleId = plan.sales.length === 1 ? plan.sales[0].id : `gunsonu-${plan.docKey}`;
      const payload = {
        sale_id: saleId,
        day_end_sale_ids: saleIds,
        customer_ref: customerId ? { type: "customer", id: customerId } : { type: "torba" },
        items: [...lines.values()],
        expected_total: expected,
        invoice_date: main.invoiceDateStamp(last.createdAt),
        description: label,
        endpoint: plan.queueType === "return_invoice" ? `/integration/return-invoice/${input.companyId}` : `/integration/${endpointBase}/${input.companyId}`,
        cash_amount: cashAmount,
        card_amount: cardAmount,
        card_acquirer_id: null,
        card_by_bank: cardByBank,
        terminal_id: input.terminalId,
        payment_accounts: paymentAccounts,
        day_end_run_id: input.runId,
        doc_key: plan.docKey,
        doc_kind: plan.docKind,
        terminal_amount: expected,
        sale_count: plan.sales.length,
        customer_name: customerName,
        receipt_no: ((_c = plan.sales[0]) == null ? void 0 : _c.receiptNo) ?? "",
        range_label: rangeLabel,
        terminal_no: input.terminalNo ?? ""
      };
      const result = insert.run(
        crypto.randomUUID(),
        input.companyId,
        plan.queueType,
        JSON.stringify(payload),
        now,
        label,
        input.runId,
        plan.docKey
      );
      if (Number((result == null ? void 0 : result.changes) ?? 0) > 0) inserted += 1;
    }
    const saleCount = briefs.filter((s) => !s.isReturn).length;
    const refundCount = briefs.filter((s) => s.isReturn).length;
    const docsTotal = inserted + expectedPayments;
    if (docsTotal > 0) {
      db.prepare(`
        INSERT INTO day_end_runs (run_id, status, reported_at, docs_total, docs_sent)
        VALUES (?, 'processing', NULL, ?, 0)
        ON CONFLICT(run_id) DO UPDATE SET
          docs_total = CASE WHEN excluded.docs_total > COALESCE(day_end_runs.docs_total, 0)
            THEN excluded.docs_total ELSE day_end_runs.docs_total END
      `).run(input.runId, docsTotal);
    }
    return { empty: false, rejected: false, problems: [], saleCount, refundCount, docCount: inserted, docsTotal };
  });
  return run();
}
function dayEndRunStatus(runId) {
  const row = index.getSqlite().prepare(`SELECT status FROM day_end_runs WHERE run_id = ?`).get(runId);
  return (row == null ? void 0 : row.status) ?? null;
}
function countDayEndProcessing(runId) {
  const row = index.getSqlite().prepare(`
    SELECT COUNT(*) AS c FROM operation_queue
    WHERE day_end_run_id = ? AND status = 'processing'
  `).get(runId);
  return Number((row == null ? void 0 : row.c) ?? 0);
}
function releaseDayEndRun(runId) {
  const db = index.getSqlite();
  const existing = db.prepare(`SELECT status, summary_days FROM day_end_runs WHERE run_id = ?`).get(runId);
  if ((existing == null ? void 0 : existing.status) === "released") {
    return { days: parseSummaryDays(existing.summary_days) };
  }
  const stamps = db.prepare(`SELECT created_at FROM sales WHERE day_end_run_id = ?`).all(runId);
  const days = [...new Set(stamps.map((row) => main.istanbulDayKey(String(row.created_at ?? ""))).filter(Boolean))].sort();
  const run = db.transaction(() => {
    db.prepare(`
      UPDATE operation_queue
      SET status = 'cancelled'
      WHERE day_end_run_id = ? AND status != 'success'
    `).run(runId);
    db.prepare(`
      UPDATE sales
      SET day_end_run_id = NULL, invoice_sent = 0, invoice_id = NULL, invoice_number = NULL, invoice_error = NULL
      WHERE day_end_run_id = ?
    `).run(runId);
    db.prepare(`
      INSERT INTO day_end_runs (run_id, status, reported_at, summary_days)
      VALUES (?, 'released', ?, ?)
      ON CONFLICT(run_id) DO UPDATE SET
        status = 'released',
        reported_at = excluded.reported_at,
        summary_days = excluded.summary_days
    `).run(runId, (/* @__PURE__ */ new Date()).toISOString(), JSON.stringify(days));
  });
  run();
  return { days };
}
function markDayEndRunStatus(runId, status) {
  index.getSqlite().prepare(`
    INSERT INTO day_end_runs (run_id, status, reported_at)
    VALUES (?, ?, ?)
    ON CONFLICT(run_id) DO UPDATE SET status = excluded.status, reported_at = excluded.reported_at
  `).run(runId, status, (/* @__PURE__ */ new Date()).toISOString());
}
function rememberQueueInvoice(queueId, invoiceId, invoiceNumber) {
  const number = String(invoiceNumber ?? "").trim();
  index.getSqlite().prepare(`
    UPDATE operation_queue
    SET invoice_number = COALESCE(NULLIF(?, ''), invoice_number),
        payload = json_set(
          payload,
          '$.erp_invoice_id', ?,
          '$.invoice_number', COALESCE(NULLIF(?, ''), json_extract(payload, '$.invoice_number'))
        )
    WHERE id = ?
  `).run(number, invoiceId, number, queueId);
}
function enqueueDayEndPayments(input) {
  const db = index.getSqlite();
  const row = db.prepare(`SELECT payload, company_id, day_end_run_id, doc_key FROM operation_queue WHERE id = ?`).get(input.queueId);
  if (!(row == null ? void 0 : row.day_end_run_id) || !row.doc_key) return 0;
  const payload = JSON.parse(row.payload);
  const saleIds = Array.isArray(payload.day_end_sale_ids) ? payload.day_end_sale_ids.filter((id) => typeof id === "string" && !id.startsWith("gunsonu-")) : [];
  const tenders = loadTenders(saleIds);
  if (tenders.length === 0) return 0;
  const rangeLabel = String(payload.range_label ?? "");
  const insert = db.prepare(`
    INSERT OR IGNORE INTO operation_queue (
      id, company_id, type, payload, status, attempts, max_attempts, created_at, label, day_end_run_id, doc_key, invoice_number
    ) VALUES (?, ?, 'payment', ?, 'pending', 0, 3, ?, ?, ?, ?, ?)
  `);
  let count = 0;
  const txn = db.transaction(() => {
    for (const tender of tenders) {
      const docKey = paymentDocKey(row.doc_key, tender.method, tender.acquirerId);
      const labelName = methodLabel(tender);
      const cardByBank = tender.method === "cash" ? {} : {
        [tender.acquirerId || tender.method]: {
          amount: tender.amount,
          acquirerName: tender.acquirerName || methodLabel(tender)
        }
      };
      const body = {
        invoice_id: input.invoiceId,
        invoice_number: input.invoiceNumber ?? null,
        invoice_date: payload.invoice_date ?? (/* @__PURE__ */ new Date()).toISOString(),
        customer_id: input.customerId ?? 0,
        customer_code: input.customerCode ?? "",
        customer_name: input.customerName ?? "",
        cash_amount: tender.method === "cash" ? tender.amount : 0,
        card_amount: tender.method === "cash" ? 0 : tender.amount,
        card_acquirer_id: tender.method === "card" ? tender.acquirerId : null,
        card_by_bank: cardByBank,
        terminal_id: payload.terminal_id ?? "",
        payment_accounts: index.matchPaymentAccounts(db, {
          cashAmount: tender.method === "cash" ? tender.amount : 0,
          cardAmount: tender.method === "card" ? tender.amount : 0,
          cardAcquirerId: tender.acquirerId,
          cardByBank
        }),
        day_end_run_id: row.day_end_run_id,
        doc_key: docKey,
        parent_doc_key: row.doc_key,
        payment_label: labelName,
        range_label: rangeLabel,
        terminal_amount: tender.amount
      };
      const result = insert.run(
        crypto.randomUUID(),
        row.company_id,
        JSON.stringify(body),
        (/* @__PURE__ */ new Date()).toISOString(),
        dayEndPaymentLabel(rangeLabel, labelName),
        row.day_end_run_id,
        docKey,
        String(input.invoiceNumber ?? "").trim() || null
      );
      if (Number((result == null ? void 0 : result.changes) ?? 0) > 0) count += 1;
    }
  });
  txn();
  return count;
}
function settleDayEndRuns(companyId) {
  const db = index.getSqlite();
  const runs = db.prepare(`
    SELECT DISTINCT q.day_end_run_id AS run_id, r.status AS reported
    FROM operation_queue q
    LEFT JOIN day_end_runs r ON r.run_id = q.day_end_run_id
    WHERE q.company_id = ?
      AND q.day_end_run_id IS NOT NULL
      AND (r.status IS NULL OR r.status NOT IN ('completed', 'released', 'completed_empty'))
  `).all(companyId);
  const actions = [];
  for (const run of runs) {
    const rows = db.prepare(`
      SELECT id, type, status, label, error, payload
      FROM operation_queue
      WHERE day_end_run_id = ?
    `).all(run.run_id);
    if (rows.length === 0) continue;
    const decision = nextDayEndReport(run.reported, rows.map((row) => row.status));
    if (decision === "processing") {
      const progress = dayEndProgress(run.run_id);
      actions.push({
        runId: run.run_id,
        body: { status: "processing", docs_total: progress.docsTotal, docs_sent: progress.docsSent }
      });
      continue;
    }
    if (decision === null) continue;
    if (decision === "failed") {
      const failed = rows.find((row) => row.status === "failed");
      const name = (failed == null ? void 0 : failed.label) || (failed == null ? void 0 : failed.type) || "belge";
      actions.push({
        runId: run.run_id,
        body: { status: "failed", error: `${name}: ${(failed == null ? void 0 : failed.error) ?? "Hata"}` }
      });
      continue;
    }
    let saleCount = 0;
    let refundCount = 0;
    let customerDocCount = 0;
    let terminalTotal = 0;
    const mark = db.prepare(`
      UPDATE sales
      SET invoice_sent = 1, invoice_id = ?, invoice_number = COALESCE(NULLIF(?, ''), invoice_number),
          invoice_error = NULL, invoice_at = ?
      WHERE id = ? AND day_end_run_id = ?
    `);
    const at = (/* @__PURE__ */ new Date()).toISOString();
    const apply = db.transaction(() => {
      for (const row of rows) {
        if (row.type === "payment") continue;
        const payload = JSON.parse(row.payload);
        const amount = Number(payload.terminal_amount ?? 0);
        const kind = String(payload.doc_kind ?? "");
        if (kind.endsWith("refund")) {
          refundCount += Number(payload.sale_count ?? 0);
          terminalTotal = round2(terminalTotal - amount);
        } else {
          saleCount += Number(payload.sale_count ?? 0);
          terminalTotal = round2(terminalTotal + amount);
        }
        if (kind.startsWith("customer")) customerDocCount += 1;
        const invoiceId = String(payload.erp_invoice_id ?? "");
        const invoiceNumber = String(payload.invoice_number ?? "").trim();
        if (!invoiceId) continue;
        for (const saleId of payload.day_end_sale_ids ?? []) {
          if (typeof saleId === "string") mark.run(invoiceId, invoiceNumber, at, saleId, run.run_id);
        }
      }
    });
    apply();
    actions.push({
      runId: run.run_id,
      body: {
        status: "completed",
        sale_count: saleCount,
        refund_count: refundCount,
        customer_doc_count: customerDocCount,
        terminal_total: terminalTotal
      }
    });
  }
  return actions;
}
function customerHit(row) {
  if (!row) return null;
  return {
    id: String(row.id),
    code: String(row.code ?? ""),
    name: String(row.name ?? ""),
    erpId: String(row.erp_id ?? "")
  };
}
function customerById(companyId, id) {
  const row = index.getSqlite().prepare(`
    SELECT id, code, name, erp_id FROM customers WHERE company_id = ? AND id = ?
  `).get(companyId, id);
  return customerHit(row);
}
function customerByCode(companyId, code) {
  const row = index.getSqlite().prepare(`
    SELECT id, code, name, erp_id FROM customers WHERE company_id = ? AND code = ?
  `).get(companyId, code);
  return customerHit(row);
}
function problemsForUnboundRange(db, input) {
  const sales = db.prepare(`
    SELECT id, customer_id, customer_name, receipt_no
    FROM sales
    WHERE julianday(created_at) >= julianday(?)
      AND julianday(created_at) <= julianday(?)
      AND invoice_sent = 0
      AND day_end_run_id IS NULL
  `).all(input.rangeStart, input.rangeEnd);
  if (sales.length === 0) return [];
  const settings = index.readTerminalSettings(db);
  const torbaCode = String(settings.torbaCariId ?? "").trim();
  const torba = torbaCode ? customerByCode(input.companyId, torbaCode) : null;
  const needsTorba = sales.some((sale) => !sale.customer_id);
  const briefs = sales.map((sale) => {
    const hit = sale.customer_id ? customerById(input.companyId, String(sale.customer_id)) : null;
    return {
      receiptNo: String(sale.receipt_no ?? ""),
      customerName: String(sale.customer_name ?? (hit == null ? void 0 : hit.name) ?? ""),
      customerId: sale.customer_id ? String(sale.customer_id) : null,
      hasErp: hasIsbasiId(hit)
    };
  });
  const ids = sales.map((sale) => String(sale.id));
  const tenders = loadTenders(ids).map((tender) => ({
    method: tender.method,
    acquirerId: tender.acquirerId,
    acquirerName: tender.acquirerName || methodLabel(tender),
    accountMatched: index.resolveTenderAccount(db, tender) != null
  }));
  const placeholders = ids.map(() => "?").join(",");
  const lines = db.prepare(`
    SELECT s.receipt_no AS receipt_no, si.product_name AS product_name, si.vat_rate AS vat_rate,
           p.code AS product_code, p.unit AS unit
    FROM sale_items si
    JOIN sales s ON s.id = si.sale_id
    LEFT JOIN products p ON p.id = si.product_id
    WHERE si.sale_id IN (${placeholders})
  `).all(...ids);
  return collectDayEndProblems({
    needsTorba,
    torbaCode,
    torbaReady: hasIsbasiId(torba),
    sales: briefs,
    tenders,
    lines: lines.map((line) => ({
      receiptNo: String(line.receipt_no ?? ""),
      name: String(line.product_name ?? ""),
      productCode: String(line.product_code ?? ""),
      unit: String(line.unit ?? ""),
      vatRate: line.vat_rate == null ? null : Number(line.vat_rate)
    }))
  });
}
function dayEndProgress(runId) {
  const db = index.getSqlite();
  const run = db.prepare(`SELECT status, docs_total, docs_sent FROM day_end_runs WHERE run_id = ?`).get(runId);
  const counts = db.prepare(`
    SELECT COUNT(*) AS total,
           SUM(CASE WHEN status = 'success' THEN 1 ELSE 0 END) AS sent
    FROM operation_queue
    WHERE day_end_run_id = ?
  `).get(runId);
  const storedTotal = Number((run == null ? void 0 : run.docs_total) ?? 0);
  const liveTotal = Number((counts == null ? void 0 : counts.total) ?? 0);
  return {
    status: (run == null ? void 0 : run.status) ?? null,
    docsTotal: storedTotal > 0 ? storedTotal : liveTotal,
    docsSent: Number((counts == null ? void 0 : counts.sent) ?? 0),
    reportedTotal: storedTotal,
    reportedSent: Number((run == null ? void 0 : run.docs_sent) ?? 0)
  };
}
function listDayEndProgress(companyId) {
  const rows = index.getSqlite().prepare(`
    SELECT DISTINCT day_end_run_id AS run_id
    FROM operation_queue
    WHERE company_id = ? AND day_end_run_id IS NOT NULL
  `).all(companyId);
  return rows.map((row) => ({ runId: String(row.run_id), ...dayEndProgress(String(row.run_id)) }));
}
function markDayEndProgress(runId, docsTotal, docsSent) {
  index.getSqlite().prepare(`
    INSERT INTO day_end_runs (run_id, status, reported_at, docs_total, docs_sent)
    VALUES (?, 'processing', ?, ?, ?)
    ON CONFLICT(run_id) DO UPDATE SET
      status = 'processing',
      reported_at = excluded.reported_at,
      docs_total = excluded.docs_total,
      docs_sent = excluded.docs_sent
  `).run(runId, (/* @__PURE__ */ new Date()).toISOString(), docsTotal, docsSent);
}
function parseSummaryDays(raw) {
  try {
    const parsed = JSON.parse(String(raw ?? "[]"));
    return Array.isArray(parsed) ? parsed.filter((day) => typeof day === "string" && day.trim() !== "") : [];
  } catch {
    return [];
  }
}
function dayEndSummaryDays(runId) {
  const row = index.getSqlite().prepare(`SELECT summary_days FROM day_end_runs WHERE run_id = ?`).get(runId);
  return parseSummaryDays(row == null ? void 0 : row.summary_days);
}
function istanbulDayBounds(dayKey) {
  const parts = dayKey.split("-").map((part) => Number(part));
  if (parts.length !== 3 || parts.some((part) => !Number.isFinite(part))) return null;
  const [year, month, day] = parts;
  const start = new Date(Date.UTC(year, month - 1, day, -3, 0, 0));
  const end = new Date(start.getTime() + 864e5);
  return { start: start.toISOString(), end: end.toISOString() };
}
function buildDailySummary(dayKey) {
  const bounds = istanbulDayBounds(dayKey);
  if (!bounds) return null;
  const rows = index.getSqlite().prepare(`
    SELECT is_return, net_amount
    FROM sales
    WHERE julianday(created_at) >= julianday(?)
      AND julianday(created_at) < julianday(?)
  `).all(bounds.start, bounds.end);
  let saleCount = 0;
  let refundCount = 0;
  let saleTotal = 0;
  let refundTotal = 0;
  for (const row of rows) {
    const amount = round2(Math.abs(Number(row.net_amount ?? 0)));
    if (Number(row.is_return ?? 0) === 1) {
      refundCount += 1;
      refundTotal = round2(refundTotal + amount);
    } else {
      saleCount += 1;
      saleTotal = round2(saleTotal + amount);
    }
  }
  return {
    date: dayKey,
    sale_count: saleCount,
    refund_count: refundCount,
    sale_total: saleTotal,
    refund_total: refundTotal,
    net_total: round2(saleTotal - refundTotal)
  };
}
function paymentTenderOf(payload, docKey) {
  const parent = String(payload.parent_doc_key ?? "");
  const prefix = parent ? `pay:${parent}:` : "";
  const rest = prefix && docKey.startsWith(prefix) ? docKey.slice(prefix.length) : "";
  const [methodRaw, acquirerRaw] = rest.split(":");
  if (methodRaw) {
    return { method: methodRaw, acquirerId: acquirerRaw ? acquirerRaw : null, name: String(payload.payment_label ?? methodRaw) };
  }
  if (Number(payload.cash_amount ?? 0) > 0) return { method: "cash", acquirerId: null, name: "Nakit" };
  const acquirerId = payload.card_acquirer_id ? String(payload.card_acquirer_id) : null;
  return { method: "card", acquirerId, name: String(payload.payment_label ?? "Kart") };
}
function rebuildDayEndRetry(companyId, runId) {
  const db = index.getSqlite();
  const busy = db.prepare(`
    SELECT COUNT(*) AS c FROM operation_queue WHERE day_end_run_id = ? AND status = 'processing'
  `).get(runId);
  if (Number((busy == null ? void 0 : busy.c) ?? 0) > 0) throw new Error("Gün sonu belgesi hâlâ gönderiliyor");
  const rows = db.prepare(`
    SELECT id, type, status, payload, doc_key
    FROM operation_queue
    WHERE day_end_run_id = ? AND status != 'success'
  `).all(runId);
  if (rows.length === 0) return { ok: true, pending: 0, problems: [] };
  const settings = index.readTerminalSettings(db);
  const torbaCode = String(settings.torbaCariId ?? "").trim();
  const torba = torbaCode ? customerByCode(companyId, torbaCode) : null;
  const problems = [];
  const seen = /* @__PURE__ */ new Set();
  const add = (problem) => {
    if (seen.has(problem.message)) return;
    seen.add(problem.message);
    problems.push(problem);
  };
  const rebuilt = /* @__PURE__ */ new Map();
  const customersByDoc = /* @__PURE__ */ new Map();
  for (const row of rows) {
    const payload = JSON.parse(row.payload);
    if (row.type === "payment") continue;
    const ref = payload.customer_ref;
    const isCari = (ref == null ? void 0 : ref.type) === "customer" || String(payload.doc_kind ?? "").startsWith("customer");
    let hit = null;
    if (isCari) {
      hit = (ref == null ? void 0 : ref.id) ? customerById(companyId, ref.id) : null;
      if (!hasIsbasiId(hit)) {
        add(cariMissingProblem(String(payload.receipt_no ?? ""), String(payload.customer_name ?? (hit == null ? void 0 : hit.name) ?? "")));
        continue;
      }
    } else if (!hasIsbasiId(torba)) {
      add(torbaMissingProblem(torbaCode));
      continue;
    } else {
      hit = torba;
    }
    if (!hit) continue;
    const next = {
      ...payload,
      customer: operations.invoiceCustomerBody(hit),
      customer_erp_id: operations.customerErpNumber(hit),
      customer_ref: isCari ? { type: "customer", id: hit.id } : { type: "torba" },
      payment_accounts: index.matchPaymentAccounts(db, {
        cashAmount: Number(payload.cash_amount ?? 0),
        cardAmount: Number(payload.card_amount ?? 0),
        cardAcquirerId: payload.card_acquirer_id ? String(payload.card_acquirer_id) : null,
        cardByBank: payload.card_by_bank ?? {}
      })
    };
    if (isCari) next.customer_name = hit.name;
    rebuilt.set(row.id, next);
    if (row.doc_key) {
      customersByDoc.set(row.doc_key, {
        id: operations.customerErpNumber(hit),
        code: hit.code,
        name: hit.name
      });
    }
  }
  for (const row of rows) {
    if (row.type !== "payment") continue;
    const payload = JSON.parse(row.payload);
    const tender = paymentTenderOf(payload, String(row.doc_key ?? ""));
    const account = index.resolveTenderAccount(db, tender);
    if (!account) {
      if (tender.method === "cash") add({ code: "NAKIT_HESAP_YOK", message: "Nakit kasa hesabı eşlenmemiş." });
      else if (tender.method === "card") {
        add({ code: "BANKA_HESAP_YOK", message: `${tender.name || "Banka"} (${tender.acquirerId || "—"}) için banka hesabı eşlenmemiş.` });
      } else {
        add({ code: "ODEME_HESAP_YOK", message: `${tender.name || tender.method} için hesap eşlenmemiş.` });
      }
      continue;
    }
    const parent = customersByDoc.get(String(payload.parent_doc_key ?? ""));
    const accounts = tender.method === "cash" ? { cash: account, cards: [] } : { cash: null, cards: [{ acquirer_id: tender.acquirerId ?? tender.method, amount: Number(payload.terminal_amount ?? payload.card_amount ?? payload.cash_amount ?? 0), account }] };
    rebuilt.set(row.id, {
      ...payload,
      payment_accounts: accounts,
      ...parent ? { customer_id: parent.id, customer_code: parent.code, customer_name: parent.name } : {}
    });
  }
  if (problems.length > 0) return { ok: false, pending: 0, problems };
  const update = db.prepare(`
    UPDATE operation_queue
    SET payload = ?, status = 'pending', attempts = 0, error = NULL
    WHERE id = ? AND day_end_run_id = ?
  `);
  const write = db.transaction(() => {
    for (const [id, payload] of rebuilt) update.run(JSON.stringify(payload), id, runId);
  });
  write();
  return { ok: true, pending: rebuilt.size, problems: [] };
}
function prepareDayEndPayment(queueId) {
  const db = index.getSqlite();
  const row = db.prepare(`SELECT payload, doc_key, day_end_run_id FROM operation_queue WHERE id = ?`).get(queueId);
  if (!(row == null ? void 0 : row.day_end_run_id)) return null;
  const payload = JSON.parse(row.payload);
  const tender = paymentTenderOf(payload, String(row.doc_key ?? ""));
  const account = index.resolveTenderAccount(db, tender);
  const accounts = tender.method === "cash" ? { cash: account, cards: [] } : { cash: null, cards: [{ acquirer_id: tender.acquirerId ?? tender.method, amount: Number(payload.terminal_amount ?? payload.card_amount ?? 0), account }] };
  const next = { ...payload, payment_accounts: accounts };
  db.prepare(`UPDATE operation_queue SET payload = ? WHERE id = ?`).run(JSON.stringify(next), queueId);
  return next;
}
exports.applyDayEndRun = applyDayEndRun;
exports.buildDailySummary = buildDailySummary;
exports.countDayEndProcessing = countDayEndProcessing;
exports.dayEndProgress = dayEndProgress;
exports.dayEndRunStatus = dayEndRunStatus;
exports.dayEndSummaryDays = dayEndSummaryDays;
exports.enqueueDayEndPayments = enqueueDayEndPayments;
exports.listDayEndProgress = listDayEndProgress;
exports.markDayEndProgress = markDayEndProgress;
exports.markDayEndRunStatus = markDayEndRunStatus;
exports.prepareDayEndPayment = prepareDayEndPayment;
exports.rebuildDayEndRetry = rebuildDayEndRetry;
exports.releaseDayEndRun = releaseDayEndRun;
exports.rememberQueueInvoice = rememberQueueInvoice;
exports.settleDayEndRuns = settleDayEndRuns;
