"use strict";
Object.defineProperty(exports, Symbol.toStringTag, { value: "Module" });
const electron = require("electron");
const electronUpdater = require("electron-updater");
electronUpdater.autoUpdater.autoDownload = false;
electronUpdater.autoUpdater.autoInstallOnAppQuit = false;
electronUpdater.autoUpdater.allowDowngrade = true;
electronUpdater.autoUpdater.allowPrerelease = true;
async function prepareUpdate(baseUrl, targetVersion) {
  var _a;
  if (!electron.app.isPackaged) {
    throw new Error("Geliştirme modunda kurulum paketi yok. Güncelleme yalnızca kurulu programda çalışır.");
  }
  electronUpdater.autoUpdater.setFeedURL({ provider: "generic", url: baseUrl });
  const result = await electronUpdater.autoUpdater.checkForUpdates();
  const found = (_a = result == null ? void 0 : result.updateInfo) == null ? void 0 : _a.version;
  if (found !== targetVersion) {
    throw new Error(`Klasördeki sürüm (${found ?? "yok"}) hedefle (${targetVersion}) uyuşmuyor`);
  }
  return result.updateInfo;
}
function downloadUpdate(win) {
  electronUpdater.autoUpdater.removeAllListeners("download-progress");
  electronUpdater.autoUpdater.removeAllListeners("error");
  electronUpdater.autoUpdater.on("download-progress", (p) => {
    if (!win.isDestroyed()) win.webContents.send("update:progress", Math.round(p.percent));
  });
  return new Promise((resolve, reject) => {
    const onError = (err) => {
      cleanup();
      reject(err);
    };
    const cleanup = () => {
      electronUpdater.autoUpdater.removeListener("error", onError);
    };
    electronUpdater.autoUpdater.once("error", onError);
    electronUpdater.autoUpdater.downloadUpdate().then(() => {
      cleanup();
      resolve();
    }).catch((err) => {
      cleanup();
      reject(err);
    });
  });
}
function installNow() {
  electronUpdater.autoUpdater.quitAndInstall(true, true);
}
exports.downloadUpdate = downloadUpdate;
exports.installNow = installNow;
exports.prepareUpdate = prepareUpdate;
