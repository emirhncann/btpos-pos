"use strict";
const index = require("./index-CZKasiGD.js");
const crypto = require("crypto");
const main = require("./main-Bq_q_YP5.js");
const UNKNOWN_BANK_KEY = "__unknown__";
const UNKNOWN_BANK_LABEL = "Diğer banka";
function round2(n) {
  return Math.round((n + Number.EPSILON) * 100) / 100;
}
function aggregateReconciliation(input) {
  const bankById = /* @__PURE__ */ new Map();
  for (const bank of input.banks) {
    const id = String(bank.acquirerId ?? "").trim();
    if (!id || bankById.has(id)) continue;
    bankById.set(id, { label: bank.label || id, amount: 0 });
  }
  let unknown = 0;
  const brandByMediator = /* @__PURE__ */ new Map();
  const brands = [...input.brands].sort((a, b) => a.brandId - b.brandId);
  for (const brand of brands) {
    if (brand.brandId === 999) continue;
    if (brand.mediator === 1 || brand.mediator === 2) continue;
    if (brandByMediator.has(brand.mediator)) continue;
    brandByMediator.set(brand.mediator, { label: brand.label, amount: 0, brandId: brand.brandId });
  }
  let otherUnknown = 0;
  let cashSales = 0;
  let cashRefunds = 0;
  const paidBySale = /* @__PURE__ */ new Map();
  const salesWithPayments = /* @__PURE__ */ new Set();
  for (const pay of input.payments) {
    const amount = Number(pay.amount) || 0;
    const signed = pay.isReturn ? -amount : amount;
    salesWithPayments.add(pay.saleId);
    paidBySale.set(pay.saleId, round2((paidBySale.get(pay.saleId) ?? 0) + amount));
    const method = String(pay.method ?? "");
    if (method === "cash") {
      if (pay.isReturn) cashRefunds = round2(cashRefunds + amount);
      else cashSales = round2(cashSales + amount);
      continue;
    }
    if (method === "card") {
      const id = String(pay.acquirerId ?? "").trim();
      const hit = id ? bankById.get(id) : void 0;
      if (hit) hit.amount = round2(hit.amount + signed);
      else unknown = round2(unknown + signed);
      continue;
    }
    const mediator = pay.mediator == null ? null : Number(pay.mediator);
    const brand = mediator != null && Number.isFinite(mediator) ? brandByMediator.get(mediator) : void 0;
    if (brand) brand.amount = round2(brand.amount + signed);
    else otherUnknown = round2(otherUnknown + signed);
  }
  for (const sale of input.sales) {
    if (sale.isReturn || salesWithPayments.has(sale.id)) continue;
    const cash = Number(sale.cashAmount) || 0;
    const card = Number(sale.cardAmount) || 0;
    if (cash) cashSales = round2(cashSales + cash);
    if (card) unknown = round2(unknown + card);
    paidBySale.set(sale.id, round2(cash + card));
  }
  let cashCollections = 0;
  for (const row of input.collections) {
    const amount = Number(row.amount) || 0;
    const method = String(row.method ?? "cash");
    if (method === "card") unknown = round2(unknown + amount);
    else cashCollections = round2(cashCollections + amount);
  }
  let cashPayments = 0;
  for (const row of input.disbursements ?? []) {
    const amount = Number(row.amount) || 0;
    const method = String(row.method ?? "cash");
    if (method === "card") continue;
    cashPayments = round2(cashPayments + amount);
  }
  let onAccount = 0;
  let discount = 0;
  let saleCount = 0;
  let refundCount = 0;
  for (const sale of input.sales) {
    if (sale.isReturn) {
      refundCount += 1;
      continue;
    }
    saleCount += 1;
    discount = round2(discount + (Number(sale.discountAmount) || 0));
    const paid = paidBySale.get(sale.id) ?? 0;
    const gap = round2((Number(sale.netAmount) || 0) - paid);
    if (gap > 0) onAccount = round2(onAccount + gap);
  }
  const cards = [...bankById.entries()].map(([key, row]) => ({
    group: "card",
    key,
    label: row.label,
    system: row.amount
  }));
  if (unknown !== 0) {
    cards.push({ group: "card", key: UNKNOWN_BANK_KEY, label: UNKNOWN_BANK_LABEL, system: unknown });
  }
  const others = [...brandByMediator.entries()].sort((a, b) => a[1].brandId - b[1].brandId).map(([mediator, row]) => ({
    group: "other",
    key: String(mediator),
    label: row.label,
    system: row.amount
  }));
  if (otherUnknown !== 0) {
    others.push({ group: "other", key: "__other__", label: "Diğer", system: otherUnknown });
  }
  return {
    cards,
    others,
    cashSales,
    cashCollections,
    cashPayments,
    cashRefunds,
    onAccount,
    discount,
    saleCount,
    refundCount
  };
}
function catalogFromDefs(banks, brands) {
  const seenBanks = /* @__PURE__ */ new Set();
  const bankItems = [];
  for (const bank of banks) {
    const key = String(bank.acquirerId ?? "").trim();
    if (!key || seenBanks.has(key)) continue;
    seenBanks.add(key);
    bankItems.push({ key, label: bank.label || key });
  }
  bankItems.push({ key: UNKNOWN_BANK_KEY, label: UNKNOWN_BANK_LABEL });
  const seenMediators = /* @__PURE__ */ new Set();
  const others = [...brands].filter((b) => b.brandId !== 999 && b.mediator !== 1 && b.mediator !== 2).sort((a, b) => a.brandId - b.brandId).filter((b) => {
    if (seenMediators.has(b.mediator)) return false;
    seenMediators.add(b.mediator);
    return true;
  }).map((b) => ({ key: String(b.mediator), label: b.label }));
  return { banks: bankItems, others };
}
function digits(s) {
  return s.replace(/\D/g, "");
}
function planCustomerSyncRepair(locals, incoming) {
  const byTax = /* @__PURE__ */ new Map();
  for (const row of incoming) {
    const tax = digits(row.taxNo);
    const erpId = row.erpId.trim();
    if (tax.length >= 10 && erpId) byTax.set(tax, { id: row.id, erpId });
  }
  const deleteIds = [];
  const erpUpdates = [];
  for (const local of locals) {
    const tax = digits(local.taxNo);
    const hit = tax.length >= 10 ? byTax.get(tax) : void 0;
    const erpId = local.erpId.trim();
    if (hit) {
      if (local.id !== hit.id) deleteIds.push(local.id);
      else if (erpId !== hit.erpId) erpUpdates.push({ id: local.id, erpId: hit.erpId });
    } else if (!erpId) {
      deleteIds.push(local.id);
    }
  }
  return { deleteIds, erpUpdates };
}
function isbasiIdOf(row) {
  const erp = String(row.erpId ?? "").trim();
  if (erp && erp !== "0") return erp;
  const id = String(row.id ?? "").trim();
  if (/^\d+$/.test(id) && id !== "0") return id;
  return "";
}
function customerErpNumber(row) {
  const raw = isbasiIdOf(row);
  const n = Number.parseInt(raw, 10);
  return Number.isFinite(n) && n > 0 ? n : 0;
}
function invoiceCustomerBody(row) {
  return {
    code: row.code || void 0,
    name: row.name ?? "",
    firstName: row.firstName || void 0,
    lastName: row.lastName || void 0,
    taxNo: row.taxNo || void 0,
    address: row.address || void 0,
    phone: row.phone || void 0,
    email: row.email || void 0,
    postalCode: row.postalCode || void 0,
    city: row.city || void 0,
    district: row.district || void 0,
    isPerson: row.isPerson ?? true
  };
}
function applyCustomerPatch(payload, next, previousCode, nowIso) {
  const prev = payload._meta;
  const meta = prev && typeof prev === "object" && !Array.isArray(prev) ? { ...prev } : {};
  meta.customer_updated_at = nowIso;
  meta.previous_customer_code = previousCode;
  const out = {
    ...payload,
    customer: next.customer,
    customer_erp_id: next.customerErpId,
    customer_ref: next.ref,
    _meta: meta
  };
  if (next.touchName && next.customerName) out.customer_name = next.customerName;
  return out;
}
function saveProducts(items) {
  const db = index.getDB();
  db.delete(index.products).run();
  const now = (/* @__PURE__ */ new Date()).toISOString();
  for (const item of items) {
    db.insert(index.products).values({
      id: item.id || crypto.randomUUID(),
      code: item.code ?? "",
      name: item.name,
      barcode: item.barcode ?? "",
      price: item.price ?? 0,
      vatRate: item.vatRate ?? 18,
      unit: item.unit ?? "Adet",
      stock: item.stock ?? 0,
      category: item.category ?? "",
      syncedAt: now,
      modificationDate: item.modificationDate ?? null
    }).run();
  }
  return items.length;
}
function getAllProducts() {
  const db = index.getDB();
  return db.select().from(index.products).all();
}
function findByBarcode(barcode) {
  const db = index.getDB();
  const result = db.select().from(index.products).where(index.eq(index.products.barcode, barcode)).get();
  return result;
}
function saveSale(sale, items, device) {
  const db = index.getDB();
  const sqlite2 = index.getSqlite();
  const saleId = crypto.randomUUID();
  const now = (/* @__PURE__ */ new Date()).toISOString();
  const invoiceMode = main.parseInvoiceMode(getTerminalSettings().invoiceMode);
  const paymentDeviceData = device ? JSON.stringify({
    authCode: device.authCode ?? null,
    cardNo: device.cardNo ?? null,
    cardBrand: device.cardBrand ?? null,
    cardType: device.cardType ?? null,
    acquirer: device.acquirer ?? null,
    batchNo: device.batchNo ?? null,
    isOffline: device.isOffline ?? false,
    receiptUrl: device.receiptUrl ?? device.inquiryLink ?? null,
    invoiceNo: device.invoiceNo ?? null,
    documentUuid: device.documentUuid ?? null,
    saleUid: device.saleUid ?? null,
    inquiryLink: device.inquiryLink ?? device.receiptUrl ?? null,
    saleNumber: device.saleNumber ?? null,
    payments: device.payments ?? null,
    pavo_invoice_no: device.invoiceNo ?? null,
    pavo_sale_uid: device.saleUid ?? null,
    pavo_inquiry_link: device.inquiryLink ?? device.receiptUrl ?? null,
    pavo_sale_number: device.saleNumber ?? null,
    pavo_auth_code: device.authCode ?? null,
    pavo_card_no: device.cardNo ?? null,
    pavo_is_offline: device.isOffline ?? false,
    raw: device.raw
  }) : null;
  sqlite2.prepare(`
    INSERT INTO sales (
      id, receipt_no, order_no,
      total_amount, discount_rate, discount_amount, net_amount,
      payment_type, cash_amount, card_amount,
      created_at, synced,
      customer_id, customer_name, customer_code,
      cashier_id, cashier_name,
      invoice_sent, invoice_id, invoice_error, invoice_at,
      card_acquirer_id, payment_provider, payment_device_data, is_return, invoice_mode
    ) VALUES (
      ?,
      (SELECT COALESCE(MAX(receipt_no), 0) + 1 FROM sales),
      ?,
      ?, ?, ?, ?,
      ?, ?, ?,
      ?, 0,
      ?, ?, ?,
      ?, ?,
      0, NULL, NULL, NULL,
      ?, ?, ?, ?,
      ?
    )
  `).run(
    saleId,
    sale.orderNo ?? null,
    sale.totalAmount,
    sale.discountRate ?? 0,
    sale.discountAmount ?? 0,
    sale.netAmount,
    sale.paymentType,
    sale.cashAmount,
    sale.cardAmount,
    now,
    sale.customerId ?? null,
    sale.customerName ?? null,
    sale.customerCode ?? null,
    sale.cashierId ?? null,
    sale.cashierName ?? null,
    sale.cardAcquirerId ?? null,
    (device == null ? void 0 : device.provider) ?? null,
    paymentDeviceData,
    sale.isReturn ? 1 : 0,
    invoiceMode
  );
  for (const item of items) {
    const productRow = item.productCode ? sqlite2.prepare(
      "SELECT id FROM products WHERE code = ? LIMIT 1"
    ).get(item.productCode) : void 0;
    const unitPriceGross = item.unitPriceGross ?? item.unitPrice;
    const qtyAbs = Math.abs(item.quantity);
    const grossAmount = item.grossAmount ?? Number((unitPriceGross * qtyAbs).toFixed(2));
    const lineDiscount = item.lineDiscount ?? item.discountAmount ?? 0;
    const docDiscountShare = item.docDiscountShare ?? 0;
    const netAmount = item.netAmount ?? Number((grossAmount - lineDiscount - docDiscountShare).toFixed(2));
    const totalDiscount = Number((lineDiscount + docDiscountShare).toFixed(2));
    db.insert(index.saleItems).values({
      id: crypto.randomUUID(),
      saleId,
      productId: (productRow == null ? void 0 : productRow.id) ?? null,
      productName: item.productName,
      quantity: item.quantity,
      unitPrice: item.unitPrice,
      vatRate: item.vatRate,
      discountRate: item.discountRate ?? 0,
      discountAmount: totalDiscount,
      lineTotal: item.lineTotal ?? netAmount,
      appliedBy: item.appliedBy ?? null,
      unitPriceGross,
      grossAmount,
      lineDiscount,
      docDiscountShare,
      netAmount
    }).run();
  }
  const inserted = sqlite2.prepare(
    "SELECT receipt_no FROM sales WHERE id = ?"
  ).get(saleId);
  return { saleId, receiptNo: String(inserted.receipt_no), invoiceMode };
}
function getPendingInvoices(onlyAnonymous = false) {
  const db = index.getDB();
  if (onlyAnonymous) {
    return db.select().from(index.sales).where(index.and(
      index.eq(index.sales.invoiceSent, 0),
      index.isNull(index.sales.dayEndQueueId),
      index.or(index.isNull(index.sales.customerId), index.eq(index.sales.customerId, "")),
      index.or(index.isNull(index.sales.isReturn), index.eq(index.sales.isReturn, 0))
    )).orderBy(index.asc(index.sales.createdAt)).limit(200).all();
  }
  return db.select().from(index.sales).where(index.and(
    index.inArray(index.sales.invoiceSent, [0, 2]),
    index.or(index.isNull(index.sales.isReturn), index.eq(index.sales.isReturn, 0))
  )).orderBy(index.asc(index.sales.createdAt)).limit(50).all();
}
function markInvoiceSent(saleId, invoiceId, invoiceNumber) {
  const number = String(invoiceNumber ?? "").trim();
  index.getSqlite().prepare(`
    UPDATE sales
    SET invoice_sent = 1, invoice_id = ?, invoice_number = COALESCE(NULLIF(?, ''), invoice_number),
        invoice_error = NULL, invoice_at = ?
    WHERE id = ?
  `).run(invoiceId, number, (/* @__PURE__ */ new Date()).toISOString(), saleId);
}
function markInvoiceError(saleId, error) {
  const db = index.getDB();
  const at = (/* @__PURE__ */ new Date()).toISOString();
  db.update(index.sales).set({ invoiceSent: 2, invoiceError: error, invoiceAt: at }).where(index.eq(index.sales.id, saleId)).run();
}
function getSaleItems(saleId) {
  const sqlite2 = index.getSqlite();
  const rows = sqlite2.prepare(`
    SELECT
      si.product_id          AS product_id,
      si.product_name        AS product_name,
      si.quantity            AS quantity,
      si.unit_price          AS unit_price,
      si.vat_rate            AS vat_rate,
      si.discount_rate       AS discount_rate,
      si.discount_amount     AS discount_amount,
      si.line_total          AS line_total,
      si.unit_price_gross    AS unit_price_gross,
      si.gross_amount        AS gross_amount,
      si.line_discount       AS line_discount,
      si.doc_discount_share  AS doc_discount_share,
      si.net_amount          AS net_amount,
      p.code                 AS p_code,
      p.unit                 AS p_unit
    FROM sale_items si
    LEFT JOIN products p ON p.id = si.product_id
    WHERE si.sale_id = ?
  `).all(saleId);
  return rows.map((r) => {
    var _a;
    const qtyAbs = Math.abs(Number(r.quantity) || 0);
    const unitPriceGross = r.unit_price_gross != null ? Number(r.unit_price_gross) : Number(r.unit_price);
    const grossAmount = r.gross_amount != null ? Number(r.gross_amount) : Number((unitPriceGross * qtyAbs).toFixed(2));
    const lineDiscount = r.line_discount != null ? Number(r.line_discount) : r.doc_discount_share == null ? Number(r.discount_amount ?? 0) : 0;
    const docDiscountShare = Number(r.doc_discount_share ?? 0);
    const discountAmount = Number((lineDiscount + docDiscountShare).toFixed(2)) || Number(r.discount_amount ?? 0);
    const netAmount = r.net_amount != null ? Number(r.net_amount) : r.line_total != null ? Number(r.line_total) : Number((grossAmount - discountAmount).toFixed(2));
    return {
      productId: r.product_id ?? null,
      productCode: r.p_code || "",
      productName: r.product_name,
      quantity: r.quantity,
      price: unitPriceGross,
      vatRate: r.vat_rate == null ? Number.NaN : Number(r.vat_rate),
      unit: ((_a = r.p_unit) == null ? void 0 : _a.trim()) ? r.p_unit : "Adet",
      unitPriceGross,
      grossAmount,
      lineDiscount,
      docDiscountShare,
      discountAmount,
      netAmount
    };
  });
}
function getSaleByReceiptNo(receiptNo) {
  const sqlite2 = index.getSqlite();
  return sqlite2.prepare(
    "SELECT id, receipt_no AS receiptNo FROM sales WHERE receipt_no = ? LIMIT 1"
  ).get(receiptNo);
}
function getSaleByOrderNo(orderNo) {
  const sqlite2 = index.getSqlite();
  return sqlite2.prepare(
    "SELECT id, order_no AS orderNo FROM sales WHERE order_no = ? LIMIT 1"
  ).get(orderNo);
}
function saveSalePayments(db, payments) {
  const stmt = db.prepare(`
    INSERT INTO sale_payments (id, sale_id, method, amount, mediator, acquirer_id, acquirer_name, cashier_id, cashier_name, created_at)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
  `);
  for (const p of payments) {
    stmt.run(
      p.id,
      p.saleId,
      p.method,
      p.amount,
      p.mediator ?? null,
      p.acquirerId ?? null,
      p.acquirerName ?? null,
      p.cashierId ?? null,
      p.cashierName ?? null,
      p.createdAt ?? (/* @__PURE__ */ new Date()).toISOString()
    );
  }
}
function getSalePayments(db, saleId) {
  return db.prepare(`
    SELECT * FROM sale_payments WHERE sale_id = ? ORDER BY created_at
  `).all(saleId);
}
function getCardTotalsByBank(db, saleIds) {
  if (saleIds.length === 0) return {};
  const placeholders = saleIds.map(() => "?").join(",");
  const rows = db.prepare(`
    SELECT COALESCE(acquirer_id, 'unknown') AS acquirer_id,
           MAX(acquirer_name) AS acquirer_name,
           SUM(amount) AS total
    FROM sale_payments
    WHERE sale_id IN (${placeholders})
      AND method = 'card'
    GROUP BY COALESCE(acquirer_id, 'unknown')
  `).all(...saleIds);
  const result = {};
  for (const r of rows) {
    result[r.acquirer_id] = {
      amount: Number(r.total ?? 0),
      acquirerName: r.acquirer_name ?? ""
    };
  }
  return result;
}
function getCashTotal(db, saleIds) {
  if (saleIds.length === 0) return 0;
  const placeholders = saleIds.map(() => "?").join(",");
  const row = db.prepare(`
    SELECT SUM(amount) as total
    FROM sale_payments
    WHERE sale_id IN (${placeholders})
      AND method = 'cash'
  `).get(...saleIds);
  return Number((row == null ? void 0 : row.total) ?? 0);
}
function getSales(dateFrom, dateTo) {
  const db = index.getDB();
  if (dateFrom && dateTo) {
    return db.select().from(index.sales).where(index.and(index.gte(index.sales.createdAt, dateFrom), index.lte(index.sales.createdAt, dateTo))).all();
  }
  return db.select().from(index.sales).all();
}
function parsePavoFromPaymentData(paymentDeviceData) {
  let pavoSaleNumber = null;
  let orderNo = null;
  if (!paymentDeviceData) return { pavoSaleNumber, orderNo };
  try {
    const pd = JSON.parse(paymentDeviceData);
    const raw = pd.raw ?? pd;
    const data = raw.Data;
    const sale = data == null ? void 0 : data.Sale;
    const saleNum = (data == null ? void 0 : data.SaleNumber) ?? (sale == null ? void 0 : sale.SaleNumber);
    if (saleNum != null && String(saleNum).trim()) {
      pavoSaleNumber = String(saleNum).trim();
    }
    const ord = (data == null ? void 0 : data.OrderNo) ?? (sale == null ? void 0 : sale.OrderNo);
    if (ord != null && String(ord).trim()) {
      orderNo = String(ord).trim();
    }
  } catch {
  }
  return { pavoSaleNumber, orderNo };
}
function getRecentSales(opts = {}) {
  const db = index.getSqlite();
  const limit = opts.limit ?? 20;
  const conditions = ["is_return = 0"];
  const params = [];
  if (opts.dateFrom) {
    conditions.push("date(created_at) >= ?");
    params.push(opts.dateFrom);
  }
  if (opts.dateTo) {
    conditions.push("date(created_at) <= ?");
    params.push(opts.dateTo);
  }
  if (opts.timeFrom) {
    conditions.push(`strftime('%H:%M', datetime(created_at)) >= ?`);
    params.push(opts.timeFrom);
  }
  if (opts.timeTo) {
    conditions.push(`strftime('%H:%M', datetime(created_at)) <= ?`);
    params.push(opts.timeTo);
  }
  const rows = db.prepare(`
    SELECT * FROM sales
    WHERE ${conditions.join(" AND ")}
    ORDER BY created_at DESC
    LIMIT ?
  `).all(...params, limit);
  return rows.map((row) => {
    const { pavoSaleNumber, orderNo: pavoOrderNo } = parsePavoFromPaymentData(
      row.payment_device_data
    );
    return {
      id: String(row.id),
      receiptNo: String(row.receipt_no),
      pavoSaleNumber,
      orderNo: row.order_no != null ? String(row.order_no) : pavoOrderNo,
      netAmount: Number(row.net_amount),
      createdAt: String(row.created_at),
      customerName: row.customer_name != null ? String(row.customer_name) : null,
      cashierName: row.cashier_name != null ? String(row.cashier_name) : null
    };
  });
}
function getLastSale() {
  const recent = getRecentSales({ limit: 1 })[0];
  if (!recent) return null;
  return {
    receiptNo: recent.receiptNo,
    pavoSaleNumber: recent.pavoSaleNumber,
    orderNo: recent.orderNo
  };
}
function saveCashiers(items) {
  const db = index.getDB();
  db.delete(index.cashiers).run();
  const now = (/* @__PURE__ */ new Date()).toISOString();
  for (const item of items) {
    db.insert(index.cashiers).values({
      id: item.id,
      companyId: item.companyId ?? "",
      fullName: item.fullName,
      cashierCode: item.cashierCode,
      password: item.password,
      role: item.role ?? "cashier",
      isActive: item.isActive ?? true,
      cardNumber: item.cardNumber ?? null,
      syncedAt: now
    }).run();
  }
  return items.length;
}
function verifyCashier(code, password) {
  const db = index.getDB();
  const result = db.select().from(index.cashiers).where(index.and(
    index.eq(index.cashiers.cashierCode, code),
    index.eq(index.cashiers.password, password),
    index.eq(index.cashiers.isActive, true)
  )).get();
  return result;
}
function verifyCashierByCard(cardNumber) {
  if (!cardNumber.trim()) return null;
  const db = index.getDB();
  const result = db.select().from(index.cashiers).where(index.and(
    index.eq(index.cashiers.cardNumber, cardNumber.trim()),
    index.eq(index.cashiers.isActive, true)
  )).get();
  return result ? {
    id: result.id,
    companyId: result.companyId,
    fullName: result.fullName,
    cashierCode: result.cashierCode,
    password: result.password,
    role: result.role ?? "cashier",
    isActive: result.isActive ?? true,
    cardNumber: result.cardNumber ?? null
  } : null;
}
function getAllCashiers() {
  const db = index.getDB();
  return db.select().from(index.cashiers).where(index.eq(index.cashiers.isActive, true)).all().map((r) => ({
    id: r.id,
    companyId: r.companyId,
    fullName: r.fullName,
    cashierCode: r.cashierCode,
    password: r.password,
    role: r.role ?? "cashier",
    isActive: r.isActive ?? true,
    cardNumber: r.cardNumber ?? null
  }));
}
function holdDocument(doc) {
  const db = index.getDB();
  const id = crypto.randomUUID();
  const now = (/* @__PURE__ */ new Date()).toISOString();
  db.insert(index.heldDocuments).values({
    id,
    companyId: doc.companyId,
    receiptNo: doc.receiptNo ?? null,
    orderNo: doc.orderNo ?? null,
    label: doc.label ?? null,
    items: JSON.stringify(doc.items),
    totalAmount: doc.totalAmount,
    customerName: doc.customerName ?? null,
    cashierName: doc.cashierName ?? null,
    customer: doc.customer != null ? JSON.stringify(doc.customer) : null,
    createdAt: now
  }).run();
  return id;
}
function getHeldDocuments(companyId) {
  const db = index.getDB();
  const rows = db.select().from(index.heldDocuments).where(index.eq(index.heldDocuments.companyId, companyId)).orderBy(index.asc(index.heldDocuments.createdAt)).all();
  return rows.map((r) => ({
    id: r.id,
    companyId: r.companyId,
    receiptNo: r.receiptNo ?? void 0,
    orderNo: r.orderNo ?? void 0,
    label: r.label ?? void 0,
    items: JSON.parse(r.items),
    totalAmount: r.totalAmount ?? 0,
    customerName: r.customerName ?? void 0,
    cashierName: r.cashierName ?? void 0,
    customer: r.customer ? JSON.parse(r.customer) : void 0,
    createdAt: r.createdAt
  }));
}
function deleteHeldDocument(id) {
  const db = index.getDB();
  db.delete(index.heldDocuments).where(index.eq(index.heldDocuments.id, id)).run();
}
function updateHeldDocumentLabel(id, label) {
  const db = index.getDB();
  db.update(index.heldDocuments).set({ label: label || null }).where(index.eq(index.heldDocuments.id, id)).run();
}
function normalizePrintWidth(width) {
  const raw = String(width ?? "").toLowerCase().trim();
  if (raw === "58" || raw === "58mm" || raw.includes("58")) return "58mm";
  return "80mm";
}
function savePluGroups(groups) {
  const db = index.getDB();
  const now = (/* @__PURE__ */ new Date()).toISOString();
  if (groups.length === 0) return;
  const companyId = groups[0].companyId;
  const existingGroups = db.select({ id: index.pluGroupsCache.id }).from(index.pluGroupsCache).where(index.eq(index.pluGroupsCache.companyId, companyId)).all();
  for (const g of existingGroups) {
    db.delete(index.pluItemsCache).where(index.eq(index.pluItemsCache.groupId, g.id)).run();
  }
  db.delete(index.pluGroupsCache).where(index.eq(index.pluGroupsCache.companyId, companyId)).run();
  for (const group of groups) {
    db.insert(index.pluGroupsCache).values({
      id: group.id,
      companyId: group.companyId,
      workplaceId: group.workplaceId ?? null,
      terminalId: group.terminalId ?? null,
      cashierId: group.cashierId ?? null,
      name: group.name,
      color: group.color,
      sortOrder: group.sortOrder ?? 0,
      syncedAt: now
    }).run();
    for (const item of group.plu_items ?? []) {
      db.insert(index.pluItemsCache).values({
        id: item.id && item.id.length > 0 ? item.id : crypto.randomUUID(),
        groupId: group.id,
        productCode: item.product_code,
        sortOrder: item.sort_order ?? 0
      }).run();
    }
  }
}
function mapPluGroups(db, groups) {
  return groups.map((g) => {
    const items = db.select().from(index.pluItemsCache).where(index.eq(index.pluItemsCache.groupId, g.id)).orderBy(index.asc(index.pluItemsCache.sortOrder)).all();
    return {
      id: g.id,
      companyId: g.companyId,
      workplaceId: g.workplaceId ?? void 0,
      terminalId: g.terminalId ?? void 0,
      cashierId: g.cashierId ?? void 0,
      name: g.name,
      color: g.color,
      sortOrder: g.sortOrder ?? 0,
      plu_items: items.map((i) => ({
        id: i.id,
        product_code: i.productCode,
        sort_order: i.sortOrder ?? 0
      }))
    };
  });
}
function deleteCashierPluForTerminal(terminalId) {
  const sqlite2 = index.getSqlite();
  const groupIds = sqlite2.prepare(`
    SELECT id FROM plu_groups_cache
    WHERE terminal_id = ? AND cashier_id IS NOT NULL
  `).all(terminalId);
  if (groupIds.length === 0) return;
  const ids = groupIds.map((g) => g.id);
  const placeholders = ids.map(() => "?").join(",");
  sqlite2.prepare(`
    DELETE FROM plu_items_cache WHERE group_id IN (${placeholders})
  `).run(...ids);
  sqlite2.prepare(`
    DELETE FROM plu_groups_cache WHERE id IN (${placeholders})
  `).run(...ids);
  console.log(`[plu] ${ids.length} kasiyer bazlı grup temizlendi (terminal: ${terminalId})`);
}
function getPluGroups(companyId, workplaceId, cashierId) {
  const db = index.getDB();
  const sqlite2 = index.getSqlite();
  if (cashierId) {
    const groups = db.select().from(index.pluGroupsCache).where(index.and(
      index.eq(index.pluGroupsCache.companyId, companyId),
      index.eq(index.pluGroupsCache.cashierId, cashierId)
    )).orderBy(index.asc(index.pluGroupsCache.sortOrder)).all();
    if (groups.length > 0) return mapPluGroups(db, groups);
  }
  if (workplaceId) {
    const rows2 = sqlite2.prepare(`
      SELECT * FROM plu_groups_cache
      WHERE company_id = ? AND workplace_id = ? AND cashier_id IS NULL
      ORDER BY sort_order
    `).all(companyId, workplaceId);
    if (rows2.length > 0) return mapPluGroups(db, rows2);
  }
  const rows = sqlite2.prepare(`
    SELECT * FROM plu_groups_cache
    WHERE company_id = ? AND cashier_id IS NULL AND terminal_id IS NULL
    ORDER BY sort_order
  `).all(companyId);
  return mapPluGroups(db, rows);
}
function sqlite() {
  return index.getSqlite();
}
function getTerminalSettings() {
  return index.readTerminalSettings(sqlite());
}
function getCashierSettings(cashierId) {
  return index.readCashierSettings(sqlite(), cashierId);
}
function saveActivation(row) {
  const db = index.getSqlite();
  db.prepare(`
    INSERT OR REPLACE INTO activation (
      id, terminal_id, company_id, device_uid, activated_at,
      plan_name, expiry_date, license_key
    ) VALUES (1, ?, ?, ?, ?, ?, ?, ?)
  `).run(
    row.terminalId,
    row.companyId,
    row.deviceUid,
    (/* @__PURE__ */ new Date()).toISOString(),
    row.planName ?? null,
    row.expiryDate ?? null,
    row.licenseKey ?? null
  );
}
function getActivation() {
  const db = index.getSqlite();
  const row = db.prepare(`SELECT * FROM activation WHERE id = 1`).get();
  if (!(row == null ? void 0 : row.terminal_id)) return null;
  return {
    terminalId: String(row.terminal_id),
    companyId: String(row.company_id ?? ""),
    deviceUid: String(row.device_uid ?? ""),
    activatedAt: String(row.activated_at ?? ""),
    planName: row.plan_name != null ? String(row.plan_name) : null,
    expiryDate: row.expiry_date != null ? String(row.expiry_date) : null,
    licenseKey: row.license_key != null && String(row.license_key).trim() ? String(row.license_key).trim() : null
  };
}
function syncSettingsBundle(bundle, terminalId) {
  const db = sqlite();
  try {
    index.applySettingsBundle(db, bundle, terminalId);
    try {
      index.dropLegacySettingsTables(db);
    } catch (e) {
      console.warn("[settings] eski ayar tablosu silinemedi:", e);
    }
    return { success: true, inserted: 1, updated: bundle.cashiers.length, deleted: 0 };
  } catch (e) {
    return { success: false, inserted: 0, updated: 0, deleted: 0, error: String(e) };
  }
}
function matchPaymentAccountsForQueue(opts) {
  return index.matchPaymentAccounts(sqlite(), opts);
}
function getPaymentDeviceSettings(provider = "pavo") {
  const db = index.getSqlite();
  const row = db.prepare(`
    SELECT * FROM payment_device_settings
    WHERE provider = ? AND is_active = 1
    LIMIT 1
  `).get(provider);
  if (!row) return void 0;
  return mapPaymentDeviceRow(row);
}
function mapPaymentDeviceRow(row) {
  return {
    id: String(row.id ?? ""),
    companyId: String(row.company_id ?? ""),
    terminalId: String(row.terminal_id ?? ""),
    provider: String(row.provider ?? "pavo"),
    ipAddress: row.ip_address != null ? String(row.ip_address) : null,
    port: Number(row.port ?? 9100),
    serialNo: row.serial_no != null ? String(row.serial_no) : null,
    cardReadTimeout: Number(row.card_read_timeout ?? 30),
    printWidth: normalizePrintWidth(row.print_width),
    isActive: Number(row.is_active ?? 1) === 1,
    syncedAt: row.synced_at != null ? String(row.synced_at) : null,
    lastPairedAt: row.last_paired_at != null ? String(row.last_paired_at) : null
  };
}
function getAllPaymentDeviceSettings() {
  const db = index.getSqlite();
  const rows = db.prepare(`SELECT * FROM payment_device_settings`).all();
  return rows.map(mapPaymentDeviceRow);
}
function hasLocalPaymentDevice(provider = "pavo") {
  const db = index.getSqlite();
  const row = db.prepare(`
    SELECT id FROM payment_device_settings WHERE provider = ? LIMIT 1
  `).get(provider);
  return row != null;
}
function deactivatePaymentDevice(provider = "pavo") {
  const db = index.getSqlite();
  db.prepare(`
    UPDATE payment_device_settings SET is_active = 0 WHERE provider = ?
  `).run(provider);
}
function upsertPaymentDeviceSettings(row) {
  const db = index.getSqlite();
  const printWidth = normalizePrintWidth(row.printWidth);
  db.prepare(`
    INSERT INTO payment_device_settings
      (id, company_id, terminal_id, provider, ip_address, port, serial_no,
       card_read_timeout, print_width, is_active, synced_at, last_paired_at)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    ON CONFLICT(id) DO UPDATE SET
      company_id=excluded.company_id,
      terminal_id=excluded.terminal_id,
      provider=excluded.provider,
      ip_address=excluded.ip_address,
      port=excluded.port,
      serial_no=excluded.serial_no,
      card_read_timeout=excluded.card_read_timeout,
      print_width=excluded.print_width,
      is_active=excluded.is_active,
      synced_at=excluded.synced_at,
      last_paired_at=COALESCE(excluded.last_paired_at, payment_device_settings.last_paired_at)
  `).run(
    row.id,
    row.companyId,
    row.terminalId,
    row.provider,
    row.ipAddress,
    row.port,
    row.serialNo,
    row.cardReadTimeout,
    printWidth,
    row.isActive ? 1 : 0,
    row.syncedAt,
    row.lastPairedAt ?? null
  );
}
function getUnitPavoCode(db, unitName) {
  const row = db.prepare(`
    SELECT pavo_code FROM unit_mappings WHERE unit_name = ? LIMIT 1
  `).get(unitName);
  return (row == null ? void 0 : row.pavo_code) ?? "C62";
}
function upsertUnitMapping(db, row) {
  db.prepare(`
    INSERT INTO unit_mappings (id, company_id, unit_name, pavo_code)
    VALUES (lower(hex(randomblob(16))), ?, ?, ?)
    ON CONFLICT(company_id, unit_name) DO UPDATE SET pavo_code = excluded.pavo_code
  `).run(row.companyId, row.unitName, row.pavoCode);
}
function getAllUnitMappings(db, companyId) {
  return db.prepare(`SELECT * FROM unit_mappings WHERE company_id = ?`).all(companyId);
}
function getProductByCode(code) {
  const db = index.getDB();
  const result = db.select().from(index.products).where(index.eq(index.products.code, code)).get();
  return result ?? null;
}
function getProductIdByCode(code) {
  const sqlite2 = index.getSqlite();
  const row = sqlite2.prepare(
    "SELECT id FROM products WHERE code = ? LIMIT 1"
  ).get(code);
  return (row == null ? void 0 : row.id) ?? null;
}
function getProductByName(name) {
  const sqlite2 = index.getSqlite();
  const mapRow = (row) => {
    var _a;
    return {
      id: row.id,
      code: row.code ?? "",
      name: row.name,
      vatRate: row.vat_rate ?? 20,
      unit: ((_a = row.unit) == null ? void 0 : _a.trim()) || "Adet"
    };
  };
  const exact = sqlite2.prepare(
    "SELECT id, code, name, vat_rate, unit FROM products WHERE LOWER(TRIM(name)) = LOWER(TRIM(?)) LIMIT 1"
  ).get(name);
  if (exact) return mapRow(exact);
  const like = sqlite2.prepare(
    "SELECT id, code, name, vat_rate, unit FROM products WHERE LOWER(name) LIKE LOWER(?) LIMIT 1"
  ).get(`%${name.trim()}%`);
  return like ? mapRow(like) : null;
}
function nextPavoSequence() {
  const db = index.getSqlite();
  db.prepare("UPDATE pavo_sequence SET seq = seq + 1 WHERE id = 1").run();
  const row = db.prepare("SELECT seq FROM pavo_sequence WHERE id = 1").get();
  return Number((row == null ? void 0 : row.seq) ?? 0);
}
function updatePavoSequence(seq) {
  const db = index.getSqlite();
  const safeSeq = Number.isFinite(seq) ? Math.max(0, Math.floor(seq)) : 0;
  db.prepare("UPDATE pavo_sequence SET seq = ? WHERE id = 1").run(safeSeq);
}
function saveCommandHistory(row) {
  const sqlite2 = index.getSqlite();
  sqlite2.prepare(`
    INSERT OR IGNORE INTO command_history (id, command, payload, status, received_at, done_at)
    VALUES (@id, @command, @payload, @status, @receivedAt, @doneAt)
  `).run({
    id: row.id,
    command: row.command,
    payload: JSON.stringify(row.payload ?? {}),
    status: row.status,
    receivedAt: row.receivedAt,
    doneAt: row.doneAt ?? null
  });
}
function getCommandHistory(limit = 20) {
  const db = index.getDB();
  const rows = db.select().from(index.commandHistory).orderBy(index.desc(index.commandHistory.receivedAt)).limit(limit).all();
  return rows.map((r) => ({
    id: r.id,
    command: r.command,
    payload: JSON.parse(r.payload ?? "{}"),
    status: r.status,
    receivedAt: r.receivedAt,
    doneAt: r.doneAt ?? void 0
  }));
}
function syncProductsAcid(items, mode = "full") {
  const db = index.getSqlite();
  const now = (/* @__PURE__ */ new Date()).toISOString();
  let inserted = 0;
  let updated = 0;
  let deleted = 0;
  if (items.length === 0) {
    return { success: false, inserted: 0, updated: 0, deleted: 0, error: "Boş liste — sync iptal" };
  }
  const txn = db.transaction(() => {
    db.prepare("DELETE FROM products_temp").run();
    const insertTemp = db.prepare(`
      INSERT OR IGNORE INTO products_temp (id, code, name, barcode, price, vat_rate, unit, stock, category, synced_at, modification_date)
      VALUES (@id, @code, @name, @barcode, @price, @vatRate, @unit, @stock, @category, @syncedAt, @modificationDate)
    `);
    for (const item of items) {
      insertTemp.run({
        id: item.id,
        code: item.code ?? "",
        name: item.name,
        barcode: item.barcode ?? "",
        price: item.price ?? 0,
        vatRate: item.vatRate ?? 18,
        unit: item.unit ?? "Adet",
        stock: item.stock ?? 0,
        category: item.category ?? "",
        syncedAt: now,
        modificationDate: item.modificationDate ?? null
      });
    }
    const countRow = db.prepare("SELECT COUNT(*) as c FROM products_temp").get();
    if (countRow.c === 0) throw new Error("Temp tablo boş — rollback");
    if (mode === "full") {
      const prevRow = db.prepare("SELECT COUNT(*) as c FROM products").get();
      deleted = prevRow.c;
      db.prepare("DELETE FROM products").run();
      db.prepare("INSERT INTO products SELECT * FROM products_temp").run();
      inserted = items.length;
    } else {
      inserted = 0;
      updated = 0;
      const existing = new Map(
        db.prepare("SELECT id, price, name FROM products").all().map((r) => [r.id, r])
      );
      const insertMain = db.prepare(`
        INSERT OR REPLACE INTO products (id, code, name, barcode, price, vat_rate, unit, stock, category, synced_at, modification_date)
        VALUES (@id, @code, @name, @barcode, @price, @vatRate, @unit, @stock, @category, @syncedAt, @modificationDate)
      `);
      for (const item of items) {
        const ex = existing.get(item.id);
        if (!ex || ex.price !== item.price || ex.name !== item.name) {
          insertMain.run({
            id: item.id,
            code: item.code ?? "",
            name: item.name,
            barcode: item.barcode ?? "",
            price: item.price ?? 0,
            vatRate: item.vatRate ?? 18,
            unit: item.unit ?? "Adet",
            stock: item.stock ?? 0,
            category: item.category ?? "",
            syncedAt: now,
            modificationDate: item.modificationDate ?? null
          });
          if (ex) updated++;
          else inserted++;
        }
      }
    }
    db.prepare("DELETE FROM products_temp").run();
  });
  try {
    txn();
    return { success: true, inserted, updated, deleted };
  } catch (e) {
    return { success: false, inserted: 0, updated: 0, deleted: 0, error: String(e) };
  }
}
function syncPluGroupsAcid(groups, mode = "full") {
  const db = index.getSqlite();
  const now = (/* @__PURE__ */ new Date()).toISOString();
  let inserted = 0;
  let updated = 0;
  let deleted = 0;
  if (groups.length === 0) {
    return { success: false, inserted: 0, updated: 0, deleted: 0, error: "Boş PLU listesi — sync iptal" };
  }
  const txn = db.transaction(() => {
    db.prepare("DELETE FROM plu_groups_temp").run();
    db.prepare("DELETE FROM plu_items_temp").run();
    const insertGrp = db.prepare(`
      INSERT INTO plu_groups_temp (id, company_id, workplace_id, terminal_id, cashier_id, name, color, sort_order, synced_at)
      VALUES (@id, @companyId, @workplaceId, @terminalId, @cashierId, @name, @color, @sortOrder, @syncedAt)
    `);
    const insertItem = db.prepare(`
      INSERT INTO plu_items_temp (id, group_id, product_code, sort_order)
      VALUES (@id, @groupId, @productCode, @sortOrder)
    `);
    for (const g of groups) {
      insertGrp.run({
        id: g.id,
        companyId: g.companyId,
        workplaceId: g.workplaceId ?? null,
        terminalId: g.terminalId ?? null,
        cashierId: g.cashierId ?? null,
        name: g.name,
        color: g.color,
        sortOrder: g.sortOrder ?? 0,
        syncedAt: now
      });
      inserted++;
      for (const item of g.plu_items ?? []) {
        insertItem.run({
          id: item.id,
          groupId: g.id,
          productCode: item.product_code,
          sortOrder: item.sort_order ?? 0
        });
      }
    }
    const grpCount = db.prepare("SELECT COUNT(*) as c FROM plu_groups_temp").get().c;
    if (grpCount === 0) throw new Error("PLU temp boş — rollback");
    if (mode === "full") {
      const companyId = groups[0].companyId;
      const cashierId = groups[0].cashierId ?? null;
      const terminalId = groups[0].terminalId ?? null;
      let scopeWhere;
      let scopeParams;
      if (cashierId) {
        scopeWhere = "company_id = ? AND cashier_id = ?";
        scopeParams = [companyId, cashierId];
      } else if (terminalId) {
        scopeWhere = "company_id = ? AND terminal_id = ? AND cashier_id IS NULL";
        scopeParams = [companyId, terminalId];
      } else {
        scopeWhere = "company_id = ? AND terminal_id IS NULL AND cashier_id IS NULL";
        scopeParams = [companyId];
      }
      const existingIds = db.prepare(`SELECT id FROM plu_groups_cache WHERE ${scopeWhere}`).all(...scopeParams).map((r) => r.id);
      deleted = existingIds.length;
      if (existingIds.length > 0) {
        const ph = existingIds.map(() => "?").join(",");
        db.prepare(`DELETE FROM plu_items_cache WHERE group_id IN (${ph})`).run(...existingIds);
        db.prepare(`DELETE FROM plu_groups_cache WHERE ${scopeWhere}`).run(...scopeParams);
      }
      db.prepare("INSERT INTO plu_groups_cache SELECT * FROM plu_groups_temp").run();
      db.prepare("INSERT INTO plu_items_cache SELECT * FROM plu_items_temp").run();
    } else {
      db.prepare(`
        INSERT OR REPLACE INTO plu_groups_cache
        SELECT * FROM plu_groups_temp
      `).run();
      db.prepare(`
        INSERT OR REPLACE INTO plu_items_cache
        SELECT * FROM plu_items_temp
      `).run();
      updated = inserted;
      inserted = 0;
    }
    db.prepare("DELETE FROM plu_groups_temp").run();
    db.prepare("DELETE FROM plu_items_temp").run();
  });
  try {
    txn();
    return { success: true, inserted, updated, deleted };
  } catch (e) {
    return { success: false, inserted: 0, updated: 0, deleted: 0, error: String(e) };
  }
}
function syncCashiersAcid(cashierList, companyId, mode = "full") {
  const db = index.getSqlite();
  const now = (/* @__PURE__ */ new Date()).toISOString();
  let inserted = 0;
  let deleted = 0;
  if (cashierList.length === 0) {
    return { success: false, inserted: 0, updated: 0, deleted: 0, error: "Boş kasiyer listesi — sync iptal" };
  }
  const txn = db.transaction(() => {
    db.prepare("DELETE FROM cashiers_temp").run();
    const ins = db.prepare(`
      INSERT INTO cashiers_temp (id, company_id, full_name, cashier_code, password, role, is_active, card_number, synced_at)
      VALUES (@id, @companyId, @fullName, @cashierCode, @password, @role, @isActive, @cardNumber, @syncedAt)
    `);
    for (const c of cashierList) {
      ins.run({
        id: c.id,
        companyId,
        fullName: c.fullName,
        cashierCode: c.cashierCode,
        password: c.password,
        role: c.role ?? "cashier",
        isActive: c.isActive ? 1 : 0,
        cardNumber: c.cardNumber ?? null,
        syncedAt: now
      });
      inserted++;
    }
    const count = db.prepare("SELECT COUNT(*) as c FROM cashiers_temp").get().c;
    if (count === 0) throw new Error("Kasiyer temp boş — rollback");
    const delById = db.prepare("DELETE FROM cashiers WHERE id IN (SELECT id FROM cashiers_temp)").run();
    if (mode === "full") {
      const delByCompany = db.prepare("DELETE FROM cashiers WHERE company_id = ?").run(companyId);
      deleted = delById.changes + delByCompany.changes;
      db.prepare(`
        INSERT INTO cashiers (id, company_id, full_name, cashier_code, password, role, is_active, card_number, synced_at)
        SELECT id, company_id, full_name, cashier_code, password, role, is_active, card_number, synced_at FROM cashiers_temp
      `).run();
    } else {
      db.prepare(`
        INSERT INTO cashiers (id, company_id, full_name, cashier_code, password, role, is_active, card_number, synced_at)
        SELECT id, company_id, full_name, cashier_code, password, role, is_active, card_number, synced_at FROM cashiers_temp
      `).run();
      deleted = delById.changes;
    }
    db.prepare("DELETE FROM cashiers_temp").run();
  });
  try {
    txn();
    return { success: true, inserted, updated: 0, deleted };
  } catch (e) {
    return { success: false, inserted: 0, updated: 0, deleted: 0, error: String(e) };
  }
}
function mapCustomerRow(r) {
  const stored = String(r.customer_type ?? "");
  const type = stored === "individual" || stored === "corporate" ? stored : void 0;
  const ip = r.is_person;
  const isPerson = type === "corporate" ? false : type === "individual" ? true : !(ip === 0 || ip === false || ip === "0");
  return {
    id: String(r.id ?? ""),
    erpId: String(r.erp_id ?? ""),
    companyId: String(r.company_id ?? ""),
    code: String(r.code ?? ""),
    name: String(r.name ?? ""),
    phone: String(r.phone ?? ""),
    taxNo: String(r.tax_no ?? ""),
    address: String(r.address ?? ""),
    balance: Number(r.balance ?? 0),
    balanceUpdatedAt: r.balance_updated_at != null && String(r.balance_updated_at).trim() ? String(r.balance_updated_at) : null,
    isPerson,
    firstName: String(r.first_name ?? ""),
    lastName: String(r.last_name ?? ""),
    postalCode: String(r.postal_code ?? ""),
    city: String(r.city ?? ""),
    district: String(r.district ?? ""),
    email: String(r.email ?? ""),
    taxOffice: String(r.tax_office ?? ""),
    type,
    syncedAt: r.synced_at != null ? String(r.synced_at) : void 0
  };
}
function syncCustomersAcid(items, companyId, mode = "full") {
  const db = index.getSqlite();
  const now = (/* @__PURE__ */ new Date()).toISOString();
  let inserted = 0;
  let updated = 0;
  let deleted = 0;
  if (items.length === 0) {
    return { success: false, inserted: 0, updated: 0, deleted: 0, error: "Boş müşteri listesi" };
  }
  for (const c of items) {
    const explicit = String(c.erpId ?? "").trim();
    const remoteId = String(c.id ?? "").trim();
    c.erpId = explicit || remoteId;
    if (!c.id) c.id = c.erpId;
  }
  const txn = db.transaction(() => {
    const localKeys = db.prepare(
      `SELECT id, tax_no, erp_id FROM customers WHERE company_id = ?`
    ).all(companyId);
    const repair = planCustomerSyncRepair(
      localKeys.map((r) => ({ id: String(r.id), taxNo: String(r.tax_no ?? ""), erpId: String(r.erp_id ?? "") })),
      items.map((c) => ({ id: String(c.id), taxNo: String(c.taxNo ?? ""), erpId: String(c.erpId ?? "") }))
    );
    const dropLocal = db.prepare(`DELETE FROM customers WHERE company_id = ? AND id = ?`);
    for (const id of repair.deleteIds) dropLocal.run(companyId, id);
    const fixErp = db.prepare(`UPDATE customers SET erp_id = ? WHERE company_id = ? AND id = ?`);
    for (const upd of repair.erpUpdates) fixErp.run(upd.erpId, companyId, upd.id);
    const prevRows = db.prepare(
      `SELECT id, balance, balance_updated_at, tax_office, customer_type, erp_id FROM customers WHERE company_id = ?`
    ).all(companyId);
    const prev = new Map(prevRows.map((r) => [String(r.id), r]));
    db.prepare("DELETE FROM customers_temp").run();
    const ins = db.prepare(`
      INSERT INTO customers_temp (id, company_id, code, name, phone, tax_no, address, balance,
        is_person, first_name, last_name, postal_code, city, district, email, tax_office, customer_type, erp_id, balance_updated_at, synced_at)
      VALUES (@id, @companyId, @code, @name, @phone, @taxNo, @address, @balance,
        @isPerson, @firstName, @lastName, @postalCode, @city, @district, @email, @taxOffice, @customerType, @erpId, @balanceUpdatedAt, @syncedAt)
    `);
    for (const c of items) {
      const old = prev.get(String(c.id));
      const known = c.balanceKnown !== false;
      ins.run({
        id: c.id,
        companyId,
        code: c.code ?? "",
        name: c.name ?? "",
        phone: c.phone ?? "",
        taxNo: c.taxNo ?? "",
        address: c.address ?? "",
        balance: known ? c.balance ?? 0 : Number((old == null ? void 0 : old.balance) ?? 0),
        balanceUpdatedAt: known ? now : (old == null ? void 0 : old.balance_updated_at) ?? null,
        isPerson: c.type === "corporate" ? 0 : c.type === "individual" ? 1 : c.isPerson ? 1 : 0,
        firstName: c.firstName ?? "",
        lastName: c.lastName ?? "",
        postalCode: c.postalCode ?? "",
        city: c.city ?? "",
        district: c.district ?? "",
        email: c.email ?? "",
        taxOffice: c.taxOffice && c.taxOffice.trim() ? c.taxOffice : String((old == null ? void 0 : old.tax_office) ?? ""),
        customerType: c.type === "individual" || c.type === "corporate" ? c.type : String((old == null ? void 0 : old.customer_type) ?? ""),
        erpId: String(c.erpId ?? "").trim() || String((old == null ? void 0 : old.erp_id) ?? ""),
        syncedAt: now
      });
      inserted++;
    }
    const cnt = db.prepare("SELECT COUNT(*) as c FROM customers_temp").get().c;
    if (cnt === 0) throw new Error("customers_temp boş — rollback");
    if (mode === "full") {
      deleted = db.prepare("SELECT COUNT(*) as c FROM customers WHERE company_id = ?").get(companyId).c;
      db.prepare("DELETE FROM customers WHERE company_id = ?").run(companyId);
      db.prepare("INSERT INTO customers SELECT * FROM customers_temp").run();
      inserted = items.length;
    } else {
      db.prepare("INSERT OR REPLACE INTO customers SELECT * FROM customers_temp").run();
      updated = inserted;
      inserted = 0;
    }
    db.prepare("DELETE FROM customers_temp").run();
  });
  try {
    txn();
    return { success: true, inserted, updated, deleted };
  } catch (e) {
    return { success: false, inserted: 0, updated: 0, deleted: 0, error: String(e) };
  }
}
function updateCustomerBalance(customerId, balance, asOf) {
  const db = index.getSqlite();
  db.prepare(`
    UPDATE customers SET balance = ?, balance_updated_at = ? WHERE id = ?
  `).run(balance, asOf, customerId);
}
function getSaleErpEffect(key) {
  const sqlite2 = index.getSqlite();
  const sale = sqlite2.prepare(`
    SELECT invoice_sent, invoice_id FROM sales
    WHERE id = ? OR order_no = ? OR receipt_no = ?
    LIMIT 1
  `).get(key, key, key);
  if (!sale || Number(sale.invoice_sent) !== 1 || !sale.invoice_id) {
    return { invoiceSent: Number(sale == null ? void 0 : sale.invoice_sent) === 1, paymentsSentTotal: 0 };
  }
  const rows = sqlite2.prepare(`
    SELECT payload FROM operation_queue WHERE type = 'payment' AND status = 'success'
  `).all();
  let total = 0;
  for (const row of rows) {
    try {
      const p = JSON.parse(row.payload);
      if (String(p.invoice_id ?? "") !== String(sale.invoice_id)) continue;
      total += Number(p.cash_amount ?? 0) + Number(p.card_amount ?? 0);
    } catch {
    }
  }
  return { invoiceSent: true, paymentsSentTotal: parseFloat(total.toFixed(2)) };
}
function getCustomerById(companyId, id) {
  if (!id.trim()) return null;
  const db = index.getSqlite();
  const r = db.prepare(`
    SELECT * FROM customers WHERE company_id = ? AND id = ?
  `).get(companyId, id.trim());
  if (!r) return null;
  return mapCustomerRow(r);
}
function getCustomerByCode(companyId, code) {
  const trimmed = code.trim();
  if (!trimmed) return null;
  const db = index.getSqlite();
  const r = db.prepare(`
    SELECT * FROM customers WHERE company_id = ? AND code = ?
  `).get(companyId, trimmed);
  if (!r) return null;
  return mapCustomerRow(r);
}
function getCustomers(companyId, query) {
  const db = index.getSqlite();
  if (query && query.trim()) {
    const q = `%${query.trim().toLowerCase()}%`;
    const rows2 = db.prepare(`
      SELECT * FROM customers
      WHERE company_id = ?
        AND (LOWER(name) LIKE ? OR LOWER(code) LIKE ? OR LOWER(phone) LIKE ? OR LOWER(tax_no) LIKE ? OR LOWER(IFNULL(email,'')) LIKE ?)
      ORDER BY name
      LIMIT 100
    `).all(companyId, q, q, q, q, q);
    return rows2.map(mapCustomerRow);
  }
  const rows = db.prepare(`
    SELECT * FROM customers WHERE company_id = ? ORDER BY name LIMIT 500
  `).all(companyId);
  return rows.map(mapCustomerRow);
}
function mapOperationQueueRow(r) {
  const st = String(r.status ?? "pending");
  const status = st === "pending_dayend" || st === "processing" || st === "success" || st === "failed" || st === "done" ? st : "pending";
  const tp = String(r.type ?? "");
  const type = [
    "invoice",
    "return_invoice",
    "customer",
    "day_end_invoice",
    "payment",
    "terminal_local_settings",
    "payment_device",
    "app_report",
    "cash_reconciliation"
  ].includes(tp) ? tp : "invoice";
  return {
    id: String(r.id ?? ""),
    companyId: String(r.company_id ?? ""),
    type,
    payload: String(r.payload ?? "{}"),
    status,
    attempts: Number(r.attempts ?? 0),
    maxAttempts: Number(r.max_attempts ?? 3),
    error: r.error != null ? String(r.error) : null,
    createdAt: String(r.created_at ?? ""),
    sentAt: r.sent_at != null ? String(r.sent_at) : null,
    label: r.label != null ? String(r.label) : null,
    invoiceNumber: r.invoice_number != null && String(r.invoice_number).trim() ? String(r.invoice_number).trim() : null
  };
}
function upsertCustomer(row) {
  const db = index.getSqlite();
  const synced = row.syncedAt ?? (/* @__PURE__ */ new Date()).toISOString();
  const erpId = String(row.erpId ?? "").trim();
  if (!erpId) return;
  const id = String(row.id || erpId).trim();
  const previousId = String(row.previousId ?? "").trim();
  if (previousId && previousId !== id) {
    const target = db.prepare(`SELECT id FROM customers WHERE id = ?`).get(id);
    if (target) db.prepare(`DELETE FROM customers WHERE id = ?`).run(previousId);
    else db.prepare(`UPDATE customers SET id = ? WHERE id = ?`).run(id, previousId);
  }
  db.prepare(`
    INSERT INTO customers (id, company_id, code, name, phone, tax_no, address, balance,
      is_person, first_name, last_name, postal_code, city, district, email, tax_office, customer_type, erp_id, synced_at)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    ON CONFLICT(id) DO UPDATE SET
      code=excluded.code,
      name=excluded.name, phone=excluded.phone, tax_no=excluded.tax_no,
      address=excluded.address, city=excluded.city, district=excluded.district,
      email=excluded.email, tax_office=excluded.tax_office,
      customer_type=excluded.customer_type,
      erp_id=excluded.erp_id,
      is_person=excluded.is_person, first_name=excluded.first_name, last_name=excluded.last_name,
      postal_code=excluded.postal_code,
      synced_at=excluded.synced_at
  `).run(
    id,
    row.companyId,
    row.code,
    row.name,
    row.phone,
    row.taxNo,
    row.address,
    row.balance,
    row.type === "corporate" ? 0 : row.type === "individual" ? 1 : row.isPerson ? 1 : 0,
    row.firstName,
    row.lastName,
    row.postalCode,
    row.city,
    row.district,
    row.email ?? "",
    row.taxOffice ?? "",
    row.type === "individual" || row.type === "corporate" ? row.type : "",
    erpId,
    synced
  );
}
function enqueueDayEndInvoicePackage(params) {
  const db = index.getSqlite();
  const settings = getTerminalSettings();
  const invoiceType = settings.invoiceType === "paper" ? "paper" : "e_archive";
  const endpoint = invoiceType === "paper" ? `/integration/invoice-paper/${params.companyId}` : `/integration/invoice/${params.companyId}`;
  const torbaRef = { type: "torba" };
  const scope = params.scope === "z" ? "z" : "previous_days";
  const run = db.transaction(() => {
    const rows = db.prepare(`
      SELECT id, created_at
      FROM sales
      WHERE invoice_sent = 0
        AND day_end_queue_id IS NULL
        AND (customer_id IS NULL OR customer_id = '')
        AND (is_return IS NULL OR is_return = 0)
        AND (invoice_mode IS NULL OR invoice_mode = 'z_single')
      ORDER BY created_at ASC
    `).all();
    const packages = main.groupDayEndSales(
      rows.map((r) => ({ id: r.id, createdAt: r.created_at })),
      scope,
      (/* @__PURE__ */ new Date()).toISOString()
    );
    if (packages.length === 0) {
      return { queued: false, queueId: null, saleCount: 0, fail: 0 };
    }
    const markErr = db.prepare(`
      UPDATE sales SET invoice_sent = 2, invoice_error = ?, invoice_at = ?
      WHERE id = ?
    `);
    const mark = db.prepare(`UPDATE sales SET day_end_queue_id = ? WHERE id = ?`);
    const insert = db.prepare(`
      INSERT INTO operation_queue (id, company_id, type, payload, status, attempts, created_at, label)
      VALUES (?, ?, 'day_end_invoice', ?, 'pending', 0, ?, ?)
    `);
    const usedSaleIds = new Set(
      db.prepare(`
        SELECT json_extract(payload, '$.sale_id') AS sid
        FROM operation_queue
        WHERE type = 'day_end_invoice'
          AND json_extract(payload, '$.sale_id') IS NOT NULL
      `).all().map((r) => String(r.sid ?? "")).filter(Boolean)
    );
    let saleCount = 0;
    let fail = 0;
    let lastQueueId = null;
    let error;
    for (const pack of packages) {
      const groupMap = /* @__PURE__ */ new Map();
      let expectedTotal = 0;
      const goodIds = [];
      const badSaleIds = [];
      const badNames = [];
      for (const sale of pack.sales) {
        const items = getSaleItems(sale.id);
        const saleBad = items.some(
          (i) => !String(i.productCode ?? "").trim() || !Number.isFinite(Number(i.vatRate))
        );
        if (saleBad) {
          badSaleIds.push(sale.id);
          for (const i of items) {
            if (!String(i.productCode ?? "").trim() || !Number.isFinite(Number(i.vatRate))) {
              badNames.push(i.productName ?? "?");
            }
          }
          continue;
        }
        goodIds.push(sale.id);
        for (const i of items) {
          const qty = Math.abs(Number(i.quantity) || 0);
          const unitPriceGross = Number(i.unitPriceGross ?? i.price);
          const grossAmount = Number(i.grossAmount ?? (unitPriceGross * qty).toFixed(2));
          const discountAmount = Number(i.discountAmount ?? 0);
          const netAmount = Number(i.netAmount ?? (grossAmount - discountAmount).toFixed(2));
          expectedTotal = Math.round((expectedTotal + netAmount) * 100) / 100;
          const key = `${i.productCode}|${unitPriceGross}|${i.vatRate}`;
          const existing = groupMap.get(key);
          if (existing) {
            existing.quantity = Math.round((existing.quantity + qty) * 1e3) / 1e3;
            existing.gross_amount = Math.round((existing.gross_amount + grossAmount) * 100) / 100;
            existing.discount_amount = Math.round((existing.discount_amount + discountAmount) * 100) / 100;
            existing.net_amount = Math.round((existing.net_amount + netAmount) * 100) / 100;
            if (existing.product_id === 0 && i.productId) {
              existing.product_id = Number.parseInt(i.productId, 10) || 0;
            }
          } else {
            groupMap.set(key, {
              product_code: i.productCode,
              name: i.productName ?? i.productCode,
              quantity: qty,
              vatRate: i.vatRate,
              unit: i.unit ?? "Adet",
              product_id: i.productId ? Number.parseInt(i.productId, 10) || 0 : 0,
              unit_price_gross: unitPriceGross,
              gross_amount: grossAmount,
              discount_amount: discountAmount,
              net_amount: netAmount
            });
          }
        }
      }
      if (badSaleIds.length > 0) {
        const msg = `Ürün kodu/KDV eksik: ${badNames.join(", ") || "satır yok"}`;
        const at = (/* @__PURE__ */ new Date()).toISOString();
        for (const sid of badSaleIds) markErr.run(msg, at, sid);
        fail += badSaleIds.length;
        error = msg;
      }
      if (goodIds.length === 0 || groupMap.size === 0) continue;
      const lastId = goodIds[goodIds.length - 1];
      const last = pack.sales.find((s) => s.id === lastId) ?? pack.sales[pack.sales.length - 1];
      const invoiceDate = main.invoiceDateStamp(last.createdAt);
      const label = main.formatDayEndInvoiceLabel(pack.day, goodIds.length);
      let daySaleId = `gunsonu-${pack.day}`;
      if (usedSaleIds.has(daySaleId)) {
        let n = 2;
        while (usedSaleIds.has(`gunsonu-${pack.day}-${n}`)) n += 1;
        daySaleId = `gunsonu-${pack.day}-${n}`;
      }
      usedSaleIds.add(daySaleId);
      const cardByBank = getCardTotalsByBank(db, goodIds);
      const cashTotal = getCashTotal(db, goodIds);
      const cardAmount = Object.values(cardByBank).reduce((sum, row) => sum + Number(row.amount ?? 0), 0);
      const paymentAccounts = index.matchPaymentAccounts(db, {
        cashAmount: cashTotal,
        cardAmount,
        cardAcquirerId: null,
        cardByBank
      });
      const queueId = crypto.randomUUID();
      const payload = {
        sale_id: daySaleId,
        day_end_sale_ids: goodIds,
        customer_ref: torbaRef,
        items: Array.from(groupMap.values()),
        expected_total: expectedTotal,
        invoice_date: invoiceDate,
        description: label,
        endpoint,
        cash_amount: cashTotal,
        card_amount: cardAmount,
        card_acquirer_id: null,
        card_by_bank: cardByBank,
        terminal_id: params.terminalId,
        payment_accounts: paymentAccounts
      };
      insert.run(
        queueId,
        params.companyId,
        JSON.stringify(payload),
        (/* @__PURE__ */ new Date()).toISOString(),
        label
      );
      for (const id of goodIds) mark.run(queueId, id);
      saleCount += goodIds.length;
      lastQueueId = queueId;
    }
    if (!lastQueueId) {
      return {
        queued: false,
        queueId: null,
        saleCount: 0,
        fail,
        error
      };
    }
    return {
      queued: true,
      queueId: lastQueueId,
      saleCount,
      fail,
      error
    };
  });
  return run();
}
function enqueueOperation(params) {
  const db = index.getSqlite();
  const status = params.status ?? "pending";
  const run = db.transaction(() => {
    if (params.type === "payment") {
      const invoiceId = String(params.payload.invoice_id ?? "").trim();
      if (invoiceId) {
        const dup = db.prepare(`
          SELECT id FROM operation_queue
          WHERE type = 'payment'
            AND json_extract(payload, '$.invoice_id') = ?
          LIMIT 1
        `).get(invoiceId);
        if (dup) return false;
      }
    }
    if (params.type === "invoice") {
      const saleId = String(params.payload.sale_id ?? "").trim();
      if (saleId) {
        const dup = db.prepare(`
          SELECT id FROM operation_queue
          WHERE type = 'invoice'
            AND json_extract(payload, '$.sale_id') = ?
          LIMIT 1
        `).get(saleId);
        if (dup) return false;
      }
    }
    if (params.type === "terminal_local_settings" || params.type === "payment_device" || params.type === "app_report") {
      db.prepare(`
        DELETE FROM operation_queue
        WHERE company_id = ? AND type = ? AND status = 'pending'
      `).run(params.companyId, params.type);
    }
    db.prepare(`
      INSERT INTO operation_queue (id, company_id, type, payload, status, attempts, created_at, label)
      VALUES (?, ?, ?, ?, ?, 0, ?, ?)
    `).run(
      params.id,
      params.companyId,
      params.type,
      JSON.stringify(params.payload),
      status,
      (/* @__PURE__ */ new Date()).toISOString(),
      params.label ?? null
    );
    return true;
  });
  return { inserted: run() };
}
function markOperationDone(id) {
  const db = index.getSqlite();
  db.prepare(`
    UPDATE operation_queue SET status = 'done', sent_at = ? WHERE id = ?
  `).run((/* @__PURE__ */ new Date()).toISOString(), id);
}
function getPendingReturnInvoices(companyId) {
  const db = index.getSqlite();
  const rows = db.prepare(`
    SELECT * FROM operation_queue
    WHERE company_id = ?
      AND type = 'return_invoice'
      AND status = 'pending_dayend'
    ORDER BY created_at ASC
  `).all(companyId);
  return rows.map(mapOperationQueueRow);
}
function getPendingOperations(companyId) {
  const db = index.getSqlite();
  const rows = db.prepare(`
    SELECT * FROM operation_queue
    WHERE company_id = ? AND status = 'pending' AND attempts < max_attempts
    ORDER BY created_at ASC
  `).all(companyId);
  return rows.map(mapOperationQueueRow);
}
function getAllOperations(companyId, limit = 100) {
  const db = index.getSqlite();
  const rows = db.prepare(`
    SELECT * FROM operation_queue
    WHERE company_id = ?
    ORDER BY created_at DESC
    LIMIT ?
  `).all(companyId, limit);
  return rows.map(mapOperationQueueRow);
}
function markOperationProcessing(id) {
  const db = index.getSqlite();
  db.prepare(`
    UPDATE operation_queue SET status = 'processing', attempts = attempts + 1 WHERE id = ?
  `).run(id);
}
function markOperationSuccess(id) {
  const db = index.getSqlite();
  db.prepare(`
    UPDATE operation_queue SET status = 'success', sent_at = ?, error = NULL WHERE id = ?
  `).run((/* @__PURE__ */ new Date()).toISOString(), id);
}
function markOperationFailed(id, error) {
  const db = index.getSqlite();
  db.prepare(`
    UPDATE operation_queue
    SET status = CASE WHEN attempts >= max_attempts THEN 'failed' ELSE 'pending' END,
        error = ?
    WHERE id = ?
  `).run(error, id);
}
function retryOperation(id) {
  const db = index.getSqlite();
  db.prepare(`
    UPDATE operation_queue SET status = 'pending', attempts = 0, error = NULL WHERE id = ?
  `).run(id);
}
function retryOperationsByErrorPrefix(companyId, errorPrefix) {
  const db = index.getSqlite();
  const pattern = `${errorPrefix}%`;
  const result = db.prepare(`
    UPDATE operation_queue
    SET status = 'pending', attempts = 0, error = NULL
    WHERE company_id = ? AND status = 'failed' AND error LIKE ?
  `).run(companyId, pattern);
  return result.changes;
}
function updateOperationPayload(id, payload) {
  const db = index.getSqlite();
  db.prepare(`
    UPDATE operation_queue SET payload = ? WHERE id = ?
  `).run(JSON.stringify(payload), id);
}
function refreshOperationCustomer(id, next, previousCode) {
  const db = index.getSqlite();
  let changed = false;
  const run = db.transaction(() => {
    const row = db.prepare(`SELECT payload, status FROM operation_queue WHERE id = ?`).get(id);
    if (!row || row.status !== "pending" && row.status !== "failed") return;
    const payload = JSON.parse(row.payload);
    const patched = applyCustomerPatch(payload, next, previousCode, (/* @__PURE__ */ new Date()).toISOString());
    db.prepare(`
      UPDATE operation_queue
      SET payload = ?, status = 'pending', attempts = 0, error = NULL
      WHERE id = ?
    `).run(JSON.stringify(patched), id);
    changed = true;
  });
  run();
  return changed;
}
function markOperationConfigFailed(id, error) {
  const db = index.getSqlite();
  db.prepare(`
    UPDATE operation_queue
    SET status = 'failed', error = ?, attempts = max_attempts
    WHERE id = ?
  `).run(error, id);
}
function markOperationManuallySent(id, note) {
  const db = index.getSqlite();
  const at = (/* @__PURE__ */ new Date()).toISOString();
  console.log(`[operation_queue] manual sent id=${id} note=${note}`);
  db.prepare(`
    UPDATE operation_queue SET status = 'success', sent_at = ?, error = NULL WHERE id = ?
  `).run(at, id);
}
function deleteOperation(id) {
  const db = index.getSqlite();
  const run = db.transaction(() => {
    const row = db.prepare(`
      SELECT type FROM operation_queue WHERE id = ?
    `).get(id);
    db.prepare(`DELETE FROM operation_queue WHERE id = ?`).run(id);
    if ((row == null ? void 0 : row.type) === "day_end_invoice") {
      db.prepare(`
        UPDATE sales
        SET day_end_queue_id = NULL
        WHERE day_end_queue_id = ?
          AND invoice_sent = 0
      `).run(id);
    }
  });
  run();
}
function getSalesReport(opts) {
  const db = index.getSqlite();
  const rows = db.prepare(`
    SELECT
      s.id, s.receipt_no, s.order_no, s.net_amount, s.cash_amount, s.card_amount,
      s.customer_name, s.cashier_name, s.created_at,
      s.invoice_sent, s.invoice_id, s.invoice_number, s.invoice_error, s.day_end_run_id, s.is_return
    FROM sales s
    WHERE date(s.created_at) >= ? AND date(s.created_at) <= ?
    ORDER BY s.created_at DESC
  `).all(opts.dateFrom, opts.dateTo);
  const payStmt = db.prepare(`
    SELECT method, amount, acquirer_name
    FROM sale_payments WHERE sale_id = ?
  `);
  return rows.map((s) => {
    const payments = payStmt.all(String(s.id));
    return {
      id: String(s.id),
      receiptNo: String(s.receipt_no),
      orderNo: s.order_no != null ? String(s.order_no) : null,
      type: s.is_return ? "return" : "sale",
      netAmount: Number(s.net_amount),
      cashAmount: Number(s.cash_amount ?? 0),
      cardAmount: Number(s.card_amount ?? 0),
      customerName: s.customer_name ? String(s.customer_name) : null,
      cashierName: s.cashier_name ? String(s.cashier_name) : null,
      createdAt: String(s.created_at),
      invoiceSent: Number(s.invoice_sent ?? 0),
      invoiceId: s.invoice_id ? String(s.invoice_id) : null,
      invoiceNumber: s.invoice_number ? String(s.invoice_number) : null,
      invoiceError: s.invoice_error ? String(s.invoice_error) : null,
      dayEndRunId: s.day_end_run_id ? String(s.day_end_run_id) : null,
      isReturn: Number(s.is_return ?? 0),
      payments: payments.map((p) => ({
        method: p.method,
        amount: p.amount,
        acquirerName: p.acquirer_name
      }))
    };
  });
}
function getDayEndReport(opts) {
  const db = index.getSqlite();
  const rows = db.prepare(`
    SELECT id, label, status, created_at, sent_at, error
    FROM operation_queue
    WHERE type = 'day_end_invoice'
      AND date(created_at) >= ? AND date(created_at) <= ?
    ORDER BY created_at DESC
  `).all(opts.dateFrom, opts.dateTo);
  return rows.map((r) => ({
    id: String(r.id),
    label: r.label != null ? String(r.label) : null,
    status: String(r.status),
    created_at: String(r.created_at),
    sent_at: r.sent_at != null ? String(r.sent_at) : null,
    error: r.error != null ? String(r.error) : null
  }));
}
function saveCariPayment(row) {
  const db = index.getSqlite();
  const method = row.method ?? null;
  if (row.type === "odeme" && method !== "cash") {
    console.warn("[cari-odeme] blocked non-cash", { id: row.id, method });
    throw new Error("Cari ödeme yalnızca nakit olabilir");
  }
  db.prepare(`
    INSERT INTO cari_payments
      (id, company_id, type, amount, customer_id, customer_name,
       customer_code, cashier_id, cashier_name, description, created_at, method)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
  `).run(
    row.id,
    row.companyId,
    row.type,
    row.amount,
    row.customerId ?? null,
    row.customerName ?? null,
    row.customerCode ?? null,
    row.cashierId ?? null,
    row.cashierName ?? null,
    row.description ?? null,
    row.createdAt,
    method
  );
}
function getCariPayments(opts) {
  const db = index.getSqlite();
  const rows = db.prepare(`
    SELECT * FROM cari_payments
    WHERE company_id = ?
      AND date(created_at) >= ?
      AND date(created_at) <= ?
    ORDER BY created_at DESC
  `).all(opts.companyId, opts.dateFrom, opts.dateTo);
  return rows.map((r) => ({
    id: String(r.id),
    type: String(r.type),
    amount: Number(r.amount),
    customer_name: r.customer_name != null ? String(r.customer_name) : null,
    customer_code: r.customer_code != null ? String(r.customer_code) : null,
    cashier_name: r.cashier_name != null ? String(r.cashier_name) : null,
    description: r.description != null ? String(r.description) : null,
    created_at: String(r.created_at)
  }));
}
function saveEnabledBrands(terminalId, brands) {
  const db = index.getSqlite();
  db.prepare(`DELETE FROM enabled_payment_brands WHERE terminal_id = ?`).run(terminalId);
  const stmt = db.prepare(`
    INSERT OR REPLACE INTO enabled_payment_brands
      (terminal_id, payment_provider_brand_id, payment_provider_brand_nm, payment_mediator, synced_at)
    VALUES (?, ?, ?, ?, ?)
  `);
  for (const b of brands) {
    stmt.run(terminalId, b.payment_provider_brand_id, b.payment_provider_brand_nm, b.payment_mediator, (/* @__PURE__ */ new Date()).toISOString());
  }
}
function getEnabledBrands(terminalId) {
  return index.getSqlite().prepare(
    `SELECT payment_provider_brand_id, payment_provider_brand_nm, payment_mediator
     FROM enabled_payment_brands WHERE terminal_id = ? ORDER BY payment_provider_brand_id ASC`
  ).all(terminalId);
}
function saveBarcodeFormats(terminalId, formats) {
  const db = index.getSqlite();
  db.prepare(`DELETE FROM barcode_formats_cache WHERE terminal_id = ?`).run(terminalId);
  const stmt = db.prepare(`
    INSERT OR REPLACE INTO barcode_formats_cache
      (id, company_id, terminal_id, flag_code, type,
       integer_length, decimal_length, decimal_multiplier,
       minimum_value, is_active, label, synced_at)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
  `);
  for (const f of formats) {
    stmt.run(
      f.id,
      f.company_id,
      f.terminal_id,
      f.flag_code,
      f.type,
      f.integer_length,
      f.decimal_length,
      f.decimal_multiplier,
      f.minimum_value,
      f.is_active ? 1 : 0,
      f.label,
      (/* @__PURE__ */ new Date()).toISOString()
    );
  }
}
function getBarcodeFormats(terminalId) {
  return index.getSqlite().prepare(`
    SELECT * FROM barcode_formats_cache
    WHERE terminal_id = ? AND is_active = 1
    ORDER BY flag_code ASC
  `).all(terminalId);
}
function mapReconciliation(r) {
  return {
    id: String(r.id ?? ""),
    terminalId: String(r.terminal_id ?? ""),
    cashierId: r.cashier_id != null ? String(r.cashier_id) : null,
    filterCashierId: r.filter_cashier_id != null ? String(r.filter_cashier_id) : null,
    periodStart: String(r.period_start ?? ""),
    periodEnd: String(r.period_end ?? ""),
    periodOverridden: Number(r.period_overridden ?? 0),
    entered: String(r.entered ?? "{}"),
    lockedAt: String(r.locked_at ?? ""),
    lines: String(r.lines ?? "[]"),
    cashDetail: String(r.cash_detail ?? "{}"),
    info: String(r.info ?? "{}"),
    totalDiff: Number(r.total_diff ?? 0),
    note: r.note != null ? String(r.note) : null,
    createdAt: String(r.created_at ?? ""),
    synced: Number(r.synced ?? 0),
    cashierName: r.cashier_name != null ? String(r.cashier_name) : null
  };
}
function getLastDayEndAt() {
  var _a;
  const row = index.getSqlite().prepare(`
    SELECT COALESCE(sent_at, created_at) AS ts
    FROM operation_queue
    WHERE type = 'day_end_invoice' AND status IN ('success', 'done')
    ORDER BY ts DESC
    LIMIT 1
  `).get();
  const ts = (_a = row == null ? void 0 : row.ts) == null ? void 0 : _a.trim();
  return ts ? ts : null;
}
function getLastCountedCash(terminalId) {
  const row = index.getSqlite().prepare(`
    SELECT cash_detail FROM cash_reconciliations
    WHERE terminal_id = ?
    ORDER BY created_at DESC
    LIMIT 1
  `).get(terminalId);
  if (!(row == null ? void 0 : row.cash_detail)) return null;
  try {
    const detail = JSON.parse(row.cash_detail);
    const carry = Number(detail.carry_over);
    if (Number.isFinite(carry)) return carry;
    const counted = Number(detail.counted);
    return Number.isFinite(counted) ? counted : null;
  } catch {
    return null;
  }
}
function loadReconDefs(terminalId) {
  const db = index.getSqlite();
  const accounts = db.prepare(`
    SELECT payment_type, pavo_acquirer_id, isbasi_account_name
    FROM payment_accounts_cache
    WHERE pavo_acquirer_id IS NOT NULL AND TRIM(pavo_acquirer_id) != ''
  `).all();
  const brands = db.prepare(`
    SELECT payment_provider_brand_id, payment_provider_brand_nm, payment_mediator
    FROM enabled_payment_brands
    WHERE terminal_id = ?
    ORDER BY payment_provider_brand_id ASC
  `).all(terminalId);
  return {
    banks: accounts.filter((r) => String(r.payment_type ?? "") !== "cash").map((r) => ({
      acquirerId: String(r.pavo_acquirer_id),
      label: String(r.isbasi_account_name || r.pavo_acquirer_id)
    })),
    brands: brands.map((r) => ({
      brandId: Number(r.payment_provider_brand_id ?? 0),
      mediator: Number(r.payment_mediator ?? 0),
      label: String(r.payment_provider_brand_nm ?? "")
    }))
  };
}
function listReconCatalog(terminalId) {
  const defs = loadReconDefs(terminalId);
  return catalogFromDefs(defs.banks, defs.brands);
}
function computeCashReconciliation(opts) {
  const db = index.getSqlite();
  const cashier = opts.cashierId ?? "";
  const sales2 = db.prepare(`
    SELECT id, is_return, net_amount, discount_amount, cash_amount, card_amount
    FROM sales
    WHERE created_at >= ? AND created_at <= ?
      AND (? = '' OR cashier_id = ?)
  `).all(opts.startIso, opts.endIso, cashier, cashier);
  const payments = db.prepare(`
    SELECT sp.sale_id, sp.method, sp.amount, sp.mediator, sp.acquirer_id, sp.acquirer_name, s.is_return
    FROM sale_payments sp
    JOIN sales s ON s.id = sp.sale_id
    WHERE s.created_at >= ? AND s.created_at <= ?
      AND (? = '' OR s.cashier_id = ?)
  `).all(opts.startIso, opts.endIso, cashier, cashier);
  const collections = db.prepare(`
    SELECT amount, method
    FROM cari_payments
    WHERE company_id = ?
      AND type = 'tahsilat'
      AND created_at >= ? AND created_at <= ?
      AND (? = '' OR cashier_id = ?)
  `).all(opts.companyId, opts.startIso, opts.endIso, cashier, cashier);
  const disbursements = db.prepare(`
    SELECT amount, method
    FROM cari_payments
    WHERE company_id = ?
      AND type = 'odeme'
      AND created_at >= ? AND created_at <= ?
      AND (? = '' OR cashier_id = ?)
  `).all(opts.companyId, opts.startIso, opts.endIso, cashier, cashier);
  const defs = loadReconDefs(opts.terminalId);
  return aggregateReconciliation({
    sales: sales2.map((r) => ({
      id: String(r.id),
      isReturn: Number(r.is_return ?? 0) === 1,
      netAmount: Number(r.net_amount ?? 0),
      discountAmount: Number(r.discount_amount ?? 0),
      cashAmount: Number(r.cash_amount ?? 0),
      cardAmount: Number(r.card_amount ?? 0)
    })),
    payments: payments.map((r) => ({
      saleId: String(r.sale_id),
      method: String(r.method ?? ""),
      amount: Number(r.amount ?? 0),
      mediator: r.mediator == null ? null : Number(r.mediator),
      acquirerId: r.acquirer_id != null ? String(r.acquirer_id) : null,
      acquirerName: r.acquirer_name != null ? String(r.acquirer_name) : null,
      isReturn: Number(r.is_return ?? 0) === 1
    })),
    collections: collections.map((r) => ({
      amount: Number(r.amount ?? 0),
      method: r.method != null ? String(r.method) : null
    })),
    disbursements: disbursements.map((r) => ({
      amount: Number(r.amount ?? 0),
      method: r.method != null ? String(r.method) : null
    })),
    banks: defs.banks,
    brands: defs.brands
  });
}
function saveCashReconciliation(row) {
  index.getSqlite().prepare(`
    INSERT INTO cash_reconciliations (
      id, terminal_id, cashier_id, filter_cashier_id,
      period_start, period_end, period_overridden, entered, locked_at,
      lines, cash_detail, info, total_diff, note, created_at, synced
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 0)
  `).run(
    row.id,
    row.terminalId,
    row.cashierId,
    row.filterCashierId,
    row.periodStart,
    row.periodEnd,
    row.periodOverridden ? 1 : 0,
    row.entered,
    row.lockedAt,
    row.lines,
    row.cashDetail,
    row.info,
    row.totalDiff,
    row.note,
    row.createdAt
  );
}
function finalizeCashReconciliation(row) {
  index.getSqlite().prepare(`
    UPDATE cash_reconciliations
    SET note = ?, cash_detail = ?
    WHERE id = ?
  `).run(row.note, row.cashDetail, row.id);
}
function listCashReconciliations(terminalId, limit = 30) {
  const rows = index.getSqlite().prepare(`
    SELECT r.*, c.full_name AS cashier_name
    FROM cash_reconciliations r
    LEFT JOIN cashiers c ON c.id = r.cashier_id
    WHERE r.terminal_id = ?
    ORDER BY r.created_at DESC
    LIMIT ?
  `).all(terminalId, limit);
  return rows.map(mapReconciliation);
}
function markCashReconciliationSynced(id) {
  index.getSqlite().prepare(`UPDATE cash_reconciliations SET synced = 1 WHERE id = ?`).run(id);
}
const operations = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  computeCashReconciliation,
  deactivatePaymentDevice,
  deleteCashierPluForTerminal,
  deleteHeldDocument,
  deleteOperation,
  enqueueDayEndInvoicePackage,
  enqueueOperation,
  finalizeCashReconciliation,
  findByBarcode,
  getActivation,
  getAllCashiers,
  getAllOperations,
  getAllPaymentDeviceSettings,
  getAllProducts,
  getAllUnitMappings,
  getBarcodeFormats,
  getCardTotalsByBank,
  getCariPayments,
  getCashTotal,
  getCashierSettings,
  getCommandHistory,
  getCustomerByCode,
  getCustomerById,
  getCustomers,
  getDayEndReport,
  getEnabledBrands,
  getHeldDocuments,
  getLastCountedCash,
  getLastDayEndAt,
  getLastSale,
  getPaymentDeviceSettings,
  getPendingInvoices,
  getPendingOperations,
  getPendingReturnInvoices,
  getPluGroups,
  getProductByCode,
  getProductByName,
  getProductIdByCode,
  getRecentSales,
  getSaleByOrderNo,
  getSaleByReceiptNo,
  getSaleErpEffect,
  getSaleItems,
  getSalePayments,
  getSales,
  getSalesReport,
  getTerminalSettings,
  getUnitPavoCode,
  hasLocalPaymentDevice,
  holdDocument,
  listCashReconciliations,
  listReconCatalog,
  markCashReconciliationSynced,
  markInvoiceError,
  markInvoiceSent,
  markOperationConfigFailed,
  markOperationDone,
  markOperationFailed,
  markOperationManuallySent,
  markOperationProcessing,
  markOperationSuccess,
  matchPaymentAccountsForQueue,
  nextPavoSequence,
  refreshOperationCustomer,
  retryOperation,
  retryOperationsByErrorPrefix,
  saveActivation,
  saveBarcodeFormats,
  saveCariPayment,
  saveCashReconciliation,
  saveCashiers,
  saveCommandHistory,
  saveEnabledBrands,
  savePluGroups,
  saveProducts,
  saveSale,
  saveSalePayments,
  syncCashiersAcid,
  syncCustomersAcid,
  syncPluGroupsAcid,
  syncProductsAcid,
  syncSettingsBundle,
  updateCustomerBalance,
  updateHeldDocumentLabel,
  updateOperationPayload,
  updatePavoSequence,
  upsertCustomer,
  upsertPaymentDeviceSettings,
  upsertUnitMapping,
  verifyCashier,
  verifyCashierByCard
}, Symbol.toStringTag, { value: "Module" }));
exports.customerErpNumber = customerErpNumber;
exports.getSaleItems = getSaleItems;
exports.invoiceCustomerBody = invoiceCustomerBody;
exports.isbasiIdOf = isbasiIdOf;
exports.operations = operations;
