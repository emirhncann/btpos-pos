"use strict";
const electron = require("electron");
electron.contextBridge.exposeInMainWorld("electron", {
  store: {
    get: (key) => electron.ipcRenderer.invoke("store:get", key),
    set: (key, value) => electron.ipcRenderer.invoke("store:set", key, value),
    getCartSettings: () => electron.ipcRenderer.invoke("store:getCartSettings"),
    setCartSettings: (s) => electron.ipcRenderer.invoke("store:setCartSettings", s)
  },
  device: {
    uid: () => electron.ipcRenderer.invoke("device:uid"),
    info: () => electron.ipcRenderer.invoke("device:info")
  },
  app: {
    version: () => electron.ipcRenderer.invoke("app:version"),
    hostname: () => electron.ipcRenderer.invoke("app:hostname"),
    log: (line) => electron.ipcRenderer.invoke("app:log", line),
    restart: () => electron.ipcRenderer.invoke("app:restart"),
    requestExit: () => electron.ipcRenderer.invoke("app:requestExit"),
    onExitBlocked: (cb) => {
      const handler = (_, data) => cb(data);
      electron.ipcRenderer.on("app:exit-blocked", handler);
      return () => {
        electron.ipcRenderer.removeListener("app:exit-blocked", handler);
      };
    },
    openKeyboard: () => electron.ipcRenderer.invoke("app:openKeyboard"),
    selectFolder: () => electron.ipcRenderer.invoke("app:selectFolder"),
    reinitDb: (p) => electron.ipcRenderer.invoke("app:reinitDb", p)
  },
  update: {
    getVersion: () => electron.ipcRenderer.invoke("update:getVersion"),
    prepare: (baseUrl, targetVersion) => electron.ipcRenderer.invoke("update:prepare", baseUrl, targetVersion),
    download: () => electron.ipcRenderer.invoke("update:download"),
    install: () => electron.ipcRenderer.invoke("update:install"),
    onProgress: (cb) => {
      const handler = (_, percent) => cb(percent);
      electron.ipcRenderer.on("update:progress", handler);
      return () => {
        electron.ipcRenderer.removeListener("update:progress", handler);
      };
    },
    onRunScheduled: (cb) => {
      const handler = () => cb();
      electron.ipcRenderer.on("update:run-scheduled", handler);
      return () => {
        electron.ipcRenderer.removeListener("update:run-scheduled", handler);
      };
    }
  },
  window: {
    isFullscreen: () => electron.ipcRenderer.invoke("window:isFullscreen"),
    toggleFullscreen: () => electron.ipcRenderer.invoke("window:toggleFullscreen"),
    focusWindow: () => electron.ipcRenderer.invoke("window:focus"),
    toggleDevTools: () => electron.ipcRenderer.invoke("window:toggleDevTools")
  },
  printer: {
    list: () => electron.ipcRenderer.invoke("printer:list"),
    print: (printerName, dataB64) => electron.ipcRenderer.invoke("printer:print", printerName, dataB64),
    printRaw: (config, dataB64) => electron.ipcRenderer.invoke("printer:printRaw", config, dataB64),
    getSettings: () => electron.ipcRenderer.invoke("printer:getSettings"),
    saveSettings: (s) => electron.ipcRenderer.invoke("printer:saveSettings", s),
    getDocSettings: () => electron.ipcRenderer.invoke("printer:getDocSettings"),
    saveDocSettings: (s) => electron.ipcRenderer.invoke("printer:saveDocSettings", s),
    printPaymentReceipt: (opts) => electron.ipcRenderer.invoke("printer:printPaymentReceipt", opts),
    testPrint: (settings) => electron.ipcRenderer.invoke("printer:testPrint", settings)
  },
  templates: {
    getAll: () => electron.ipcRenderer.invoke("templates:getAll"),
    getByTrigger: (triggerType) => electron.ipcRenderer.invoke("templates:getByTrigger", triggerType),
    getDefault: (triggerType) => electron.ipcRenderer.invoke("templates:getDefault", triggerType),
    save: (templates) => electron.ipcRenderer.invoke("templates:save", templates),
    printWithBehavior: (opts) => electron.ipcRenderer.invoke("templates:printWithBehavior", opts)
  },
  display: {
    apply: (enabled) => electron.ipcRenderer.invoke("display:apply", enabled)
  },
  devtools: {
    refresh: () => electron.ipcRenderer.invoke("devtools:refresh"),
    open: () => electron.ipcRenderer.invoke("devtools:open")
  },
  secondScreen: {
    open: () => electron.ipcRenderer.invoke("secondScreen:open"),
    update: (payload) => electron.ipcRenderer.invoke("secondScreen:update", payload),
    close: () => electron.ipcRenderer.invoke("secondScreen:close"),
    getLatest: () => electron.ipcRenderer.invoke("secondScreen:getLatest"),
    onData: (listener) => {
      const handler = (_event, payload) => listener(payload);
      electron.ipcRenderer.on("secondScreen:data", handler);
      return () => electron.ipcRenderer.removeListener("secondScreen:data", handler);
    }
  },
  db: {
    selectFolder: () => electron.ipcRenderer.invoke("db:selectFolder"),
    setLocation: (dir, opts) => electron.ipcRenderer.invoke("db:setLocation", dir, opts),
    getLocation: () => electron.ipcRenderer.invoke("db:getLocation"),
    userVersion: () => electron.ipcRenderer.invoke("db:userVersion"),
    backupNow: (label) => electron.ipcRenderer.invoke("db:backupNow", label),
    saveProducts: (products) => electron.ipcRenderer.invoke("db:saveProducts", products),
    getProducts: () => electron.ipcRenderer.invoke("db:getProducts"),
    saveSale: (sale, items, device) => electron.ipcRenderer.invoke("db:saveSale", sale, items, device),
    getSales: (dateFrom, dateTo) => electron.ipcRenderer.invoke("db:getSales", dateFrom, dateTo),
    saveCashiers: (cashiers) => electron.ipcRenderer.invoke("db:saveCashiers", cashiers),
    verifyCashier: (code, password) => electron.ipcRenderer.invoke("db:verifyCashier", code, password),
    verifyCashierByCard: (cardNumber) => electron.ipcRenderer.invoke("db:verifyCashierByCard", cardNumber),
    getAllCashiers: () => electron.ipcRenderer.invoke("db:getAllCashiers"),
    getCashiers: () => electron.ipcRenderer.invoke("db:getCashiers"),
    holdDocument: (doc) => electron.ipcRenderer.invoke("db:holdDocument", doc),
    getHeldDocuments: (companyId) => electron.ipcRenderer.invoke("db:getHeldDocuments", companyId),
    deleteHeldDocument: (id) => electron.ipcRenderer.invoke("db:deleteHeldDocument", id),
    updateHeldDocumentLabel: (id, label) => electron.ipcRenderer.invoke("db:updateHeldDocumentLabel", id, label),
    savePluGroups: (groups) => electron.ipcRenderer.invoke("db:savePluGroups", groups),
    getPluGroups: (companyId, wpId, cashierId) => electron.ipcRenderer.invoke("db:getPluGroups", companyId, wpId, cashierId),
    getTerminalSettings: () => electron.ipcRenderer.invoke("db:getTerminalSettings"),
    getCashierSettings: (cashierId) => electron.ipcRenderer.invoke("db:getCashierSettings", cashierId),
    saveActivation: (row) => electron.ipcRenderer.invoke("db:saveActivation", row),
    getActivation: () => electron.ipcRenderer.invoke("db:getActivation"),
    syncSettingsBundle: (bundle, terminalId) => electron.ipcRenderer.invoke("db:syncSettingsBundle", bundle, terminalId),
    matchPaymentAccounts: (opts) => electron.ipcRenderer.invoke("db:matchPaymentAccounts", opts),
    saveCommandHistory: (row) => electron.ipcRenderer.invoke("db:saveCommandHistory", row),
    getCommandHistory: (limit) => electron.ipcRenderer.invoke("db:getCommandHistory", limit),
    syncProductsAcid: (items, mode) => electron.ipcRenderer.invoke("db:syncProductsAcid", items, mode ?? "full"),
    syncPluGroupsAcid: (groups, mode) => electron.ipcRenderer.invoke("db:syncPluGroupsAcid", groups, mode ?? "full"),
    deleteCashierPluForTerminal: (terminalId) => electron.ipcRenderer.invoke("db:deleteCashierPluForTerminal", terminalId),
    syncCashiersAcid: (cashiers, companyId, mode) => electron.ipcRenderer.invoke("db:syncCashiersAcid", cashiers, companyId, mode ?? "full"),
    syncCustomersAcid: (items, companyId, mode) => electron.ipcRenderer.invoke("db:syncCustomersAcid", items, companyId, mode ?? "full"),
    getCustomers: (companyId, query) => electron.ipcRenderer.invoke("db:getCustomers", companyId, query),
    getCustomerById: (companyId, id) => electron.ipcRenderer.invoke("db:getCustomerById", companyId, id),
    updateCustomerBalance: (customerId, balance, asOf) => electron.ipcRenderer.invoke("db:updateCustomerBalance", customerId, balance, asOf),
    getSaleErpEffect: (key) => electron.ipcRenderer.invoke("db:getSaleErpEffect", key),
    getCustomerByCode: (companyId, code) => electron.ipcRenderer.invoke("db:getCustomerByCode", companyId, code),
    getPendingInvoices: (onlyAnonymous) => electron.ipcRenderer.invoke("db:getPendingInvoices", onlyAnonymous),
    markInvoiceSent: (saleId, invoiceId, invoiceNumber) => electron.ipcRenderer.invoke("db:markInvoiceSent", saleId, invoiceId, invoiceNumber ?? null),
    markInvoiceError: (saleId, error) => electron.ipcRenderer.invoke("db:markInvoiceError", saleId, error),
    getSaleItems: (saleId) => electron.ipcRenderer.invoke("db:getSaleItems", saleId),
    getSaleByReceiptNo: (receiptNo) => electron.ipcRenderer.invoke("db:getSaleByReceiptNo", receiptNo),
    getSaleByOrderNo: (orderNo) => electron.ipcRenderer.invoke("db:getSaleByOrderNo", orderNo),
    saveSalePayments: (payments) => electron.ipcRenderer.invoke("db:saveSalePayments", payments),
    getSalePayments: (saleId) => electron.ipcRenderer.invoke("db:getSalePayments", saleId),
    getCardTotalsByBank: (saleIds) => electron.ipcRenderer.invoke("db:getCardTotalsByBank", saleIds),
    getCashTotal: (saleIds) => electron.ipcRenderer.invoke("db:getCashTotal", saleIds),
    getProductByCode: (code) => electron.ipcRenderer.invoke("db:getProductByCode", code),
    getProductByName: (name) => electron.ipcRenderer.invoke("db:getProductByName", name),
    getProductIdByCode: (code) => electron.ipcRenderer.invoke("db:getProductIdByCode", code),
    upsertCustomer: (row) => electron.ipcRenderer.invoke("db:upsertCustomer", row),
    applyDayEndRun: (input) => electron.ipcRenderer.invoke("db:applyDayEndRun", input),
    dayEndRunStatus: (runId) => electron.ipcRenderer.invoke("db:dayEndRunStatus", runId),
    countDayEndProcessing: (runId) => electron.ipcRenderer.invoke("db:countDayEndProcessing", runId),
    releaseDayEndRun: (runId) => electron.ipcRenderer.invoke("db:releaseDayEndRun", runId),
    markDayEndRunStatus: (runId, status) => electron.ipcRenderer.invoke("db:markDayEndRunStatus", runId, status),
    dayEndProgress: (runId) => electron.ipcRenderer.invoke("db:dayEndProgress", runId),
    listDayEndProgress: (companyId) => electron.ipcRenderer.invoke("db:listDayEndProgress", companyId),
    markDayEndProgress: (runId, docsTotal, docsSent) => electron.ipcRenderer.invoke("db:markDayEndProgress", runId, docsTotal, docsSent),
    dayEndSummaryDays: (runId) => electron.ipcRenderer.invoke("db:dayEndSummaryDays", runId),
    buildDailySummary: (dayKey) => electron.ipcRenderer.invoke("db:buildDailySummary", dayKey),
    rebuildDayEndRetry: (companyId, runId) => electron.ipcRenderer.invoke("db:rebuildDayEndRetry", companyId, runId),
    prepareDayEndPayment: (queueId) => electron.ipcRenderer.invoke("db:prepareDayEndPayment", queueId),
    rememberQueueInvoice: (queueId, invoiceId, invoiceNumber) => electron.ipcRenderer.invoke("db:rememberQueueInvoice", queueId, invoiceId, invoiceNumber ?? null),
    enqueueDayEndPayments: (input) => electron.ipcRenderer.invoke("db:enqueueDayEndPayments", input),
    settleDayEndRuns: (companyId) => electron.ipcRenderer.invoke("db:settleDayEndRuns", companyId),
    enqueueDayEndInvoicePackage: (companyId, scope) => electron.ipcRenderer.invoke("db:enqueueDayEndInvoicePackage", companyId, scope),
    enqueueOperation: (params) => electron.ipcRenderer.invoke("db:enqueueOperation", params),
    getPendingReturnInvoices: (companyId) => electron.ipcRenderer.invoke("db:getPendingReturnInvoices", companyId),
    markOperationDone: (id) => electron.ipcRenderer.invoke("db:markOperationDone", id),
    getPendingOperations: (companyId) => electron.ipcRenderer.invoke("db:getPendingOperations", companyId),
    getAllOperations: (companyId, limit) => electron.ipcRenderer.invoke("db:getAllOperations", companyId, limit),
    markOperationProcessing: (id) => electron.ipcRenderer.invoke("db:markOperationProcessing", id),
    markOperationSuccess: (id) => electron.ipcRenderer.invoke("db:markOperationSuccess", id),
    markOperationFailed: (id, error) => electron.ipcRenderer.invoke("db:markOperationFailed", id, error),
    retryOperation: (id) => electron.ipcRenderer.invoke("db:retryOperation", id),
    retryOperationsByErrorPrefix: (companyId, prefix) => electron.ipcRenderer.invoke("db:retryOperationsByErrorPrefix", companyId, prefix),
    updateOperationPayload: (id, payload) => electron.ipcRenderer.invoke("db:updateOperationPayload", id, payload),
    refreshOperationCustomer: (id, next, previousCode) => electron.ipcRenderer.invoke("db:refreshOperationCustomer", id, next, previousCode),
    markOperationConfigFailed: (id, error) => electron.ipcRenderer.invoke("db:markOperationConfigFailed", id, error),
    markOperationManuallySent: (id, note) => electron.ipcRenderer.invoke("db:markOperationManuallySent", id, note),
    deleteOperation: (id) => electron.ipcRenderer.invoke("db:deleteOperation", id),
    getSalesReport: (opts) => electron.ipcRenderer.invoke("db:getSalesReport", opts),
    getDayEndReport: (opts) => electron.ipcRenderer.invoke("db:getDayEndReport", opts),
    saveCariPayment: (row) => electron.ipcRenderer.invoke("db:saveCariPayment", row),
    getCariPayments: (opts) => electron.ipcRenderer.invoke("db:getCariPayments", opts),
    getPaymentDeviceSettings: (provider) => electron.ipcRenderer.invoke("db:getPaymentDeviceSettings", provider),
    upsertPaymentDeviceSettings: (row) => electron.ipcRenderer.invoke("db:upsertPaymentDeviceSettings", row),
    getAllPaymentDeviceSettings: () => electron.ipcRenderer.invoke("db:getAllPaymentDeviceSettings"),
    hasLocalPaymentDevice: (provider) => electron.ipcRenderer.invoke("db:hasLocalPaymentDevice", provider),
    deactivatePaymentDevice: (provider) => electron.ipcRenderer.invoke("db:deactivatePaymentDevice", provider),
    nextPavoSequence: () => electron.ipcRenderer.invoke("db:nextPavoSequence"),
    updatePavoSequence: (seq) => electron.ipcRenderer.invoke("db:updatePavoSequence", seq),
    getUnitPavoCode: (unitName) => electron.ipcRenderer.invoke("db:getUnitPavoCode", unitName),
    upsertUnitMapping: (row) => electron.ipcRenderer.invoke("db:upsertUnitMapping", row),
    getAllUnitMappings: (companyId) => electron.ipcRenderer.invoke("db:getAllUnitMappings", companyId),
    getLastSale: () => electron.ipcRenderer.invoke("db:getLastSale"),
    getRecentSales: (opts) => electron.ipcRenderer.invoke("db:getRecentSales", opts),
    saveEnabledBrands: (terminalId, brands) => electron.ipcRenderer.invoke("db:saveEnabledBrands", terminalId, brands),
    getEnabledBrands: (terminalId) => electron.ipcRenderer.invoke("db:getEnabledBrands", terminalId),
    getLastDayEndAt: () => electron.ipcRenderer.invoke("db:getLastDayEndAt"),
    getLastCountedCash: (terminalId) => electron.ipcRenderer.invoke("db:getLastCountedCash", terminalId),
    listReconCatalog: (terminalId) => electron.ipcRenderer.invoke("db:listReconCatalog", terminalId),
    computeCashReconciliation: (opts) => electron.ipcRenderer.invoke("db:computeCashReconciliation", opts),
    saveCashReconciliation: (row) => electron.ipcRenderer.invoke("db:saveCashReconciliation", row),
    finalizeCashReconciliation: (row) => electron.ipcRenderer.invoke("db:finalizeCashReconciliation", row),
    listCashReconciliations: (terminalId) => electron.ipcRenderer.invoke("db:listCashReconciliations", terminalId),
    markCashReconciliationSynced: (id) => electron.ipcRenderer.invoke("db:markCashReconciliationSynced", id),
    saveBarcodeFormats: (terminalId, formats) => electron.ipcRenderer.invoke("db:saveBarcodeFormats", terminalId, formats),
    getBarcodeFormats: (terminalId) => electron.ipcRenderer.invoke("db:getBarcodeFormats", terminalId)
  },
  cart: {
    saveDraft: (opts) => electron.ipcRenderer.invoke("cart:saveDraft", opts),
    loadDraft: () => electron.ipcRenderer.invoke("cart:loadDraft"),
    clearDraft: () => electron.ipcRenderer.invoke("cart:clearDraft")
  },
  pavo: {
    log: (entry) => electron.ipcRenderer.invoke("pavo:log", entry),
    getReturnableSale: (opts) => electron.ipcRenderer.invoke("pavo:getReturnableSale", opts),
    partialReturn: (opts) => electron.ipcRenderer.invoke("pavo:partialReturn", opts)
  },
  scale: {
    listPorts: () => electron.ipcRenderer.invoke("scale:listPorts"),
    connect: (opts) => electron.ipcRenderer.invoke("scale:connect", opts),
    disconnect: () => electron.ipcRenderer.invoke("scale:disconnect"),
    getLastReading: () => electron.ipcRenderer.invoke("scale:getLastReading"),
    write: (data) => electron.ipcRenderer.invoke("scale:write", data),
    saveSettings: (s) => electron.ipcRenderer.invoke("scale:saveSettings", s),
    getSettings: () => electron.ipcRenderer.invoke("scale:getSettings"),
    onData: (cb) => {
      const handler = (_, r) => cb(r);
      electron.ipcRenderer.on("scale:data", handler);
      return () => electron.ipcRenderer.removeListener("scale:data", handler);
    },
    onRaw: (cb) => {
      const handler = (_, raw) => cb(raw);
      electron.ipcRenderer.on("scale:raw", handler);
      return () => electron.ipcRenderer.removeListener("scale:raw", handler);
    }
  }
});
