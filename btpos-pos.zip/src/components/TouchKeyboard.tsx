import { useState, useCallback, type CSSProperties } from 'react'
import { C, solidBtn } from '../theme/colors'

export type KeyboardType = 'qwerty' | 'numeric'

const TURKISH_UPPER: Record<string, string> = {
  'i': 'İ', 'ı': 'I', 'ğ': 'Ğ', 'ü': 'Ü',
  'ş': 'Ş', 'ö': 'Ö', 'ç': 'Ç',
}

function displayKey(k: string, shifted: boolean): string {
  if (!shifted) return k
  return TURKISH_UPPER[k] ?? k.toUpperCase()
}

interface TouchKeyboardProps {
  title?:          string
  value:           string
  onChange:        (v: string) => void
  onConfirm:       (v: string) => void
  onClose:         () => void
  type?:           KeyboardType
  searchResults?:  CustomerRow[]
  onSelectResult?: (c: CustomerRow) => void
  searching?:      boolean
}

export function TouchKeyboard({
  title, value, onChange, onConfirm, onClose, type = 'qwerty',
  searchResults, onSelectResult, searching,
}: TouchKeyboardProps) {
  const [tab,   setTab]   = useState<'abc' | '123'>(type === 'numeric' ? '123' : 'abc')
  const [shift, setShift] = useState(false)

  const press = useCallback((key: string) => {
    if (key === '⌫')    { onChange(value.slice(0, -1)); return }
    if (key === 'SPACE') { onChange(value + ' ');        return }
    if (key === 'ABC')   { setTab('abc');                return }
    if (key === '123')   { setTab('123');                return }

    const ch = shift
      ? (TURKISH_UPPER[key] ?? key.toUpperCase())
      : key

    onChange(value + ch)
    if (shift) setShift(false)
  }, [value, shift, onChange])

  const keyStyle = (extra?: CSSProperties): CSSProperties => ({
    display: 'flex', alignItems: 'center', justifyContent: 'center',
    padding: 'clamp(10px,2vw,16px) 0',
    fontSize: 'clamp(14px,1.6vw,18px)', fontWeight: 400,
    borderRadius: 8, border: '0.5px solid var(--pos-key-border)',
    background: 'var(--pos-key-bg)', cursor: 'pointer', userSelect: 'none',
    color: 'var(--pos-key-text)', ...extra,
  })

  const rows_abc = [
    ['q', 'w', 'e', 'r', 't', 'y', 'u', 'ı', 'o', 'p', 'ğ', 'ü'],
    ['a', 's', 'd', 'f', 'g', 'h', 'j', 'k', 'l', 'ş', 'i'],
    ['z', 'x', 'c', 'v', 'b', 'n', 'm', 'ö', 'ç'],
  ]

  const rows_123_1 = ['1','2','3','4','5','6','7','8','9','0']
  const rows_123_2 = ['!','@','#','$','%','&','-','+','=','/']

  return (
    <div className="pos-keyboard" style={{ position: 'fixed', inset: 0, zIndex: 10003,
      background: 'rgba(0,0,0,0.45)', display: 'flex',
      alignItems: 'center', justifyContent: 'center' }}
      onClick={onClose}>
      <div onClick={e => e.stopPropagation()}
        style={{ background: 'var(--pos-surface)', borderRadius: 16, padding: 20,
          width: 'min(560px, 96vw)', display: 'flex', flexDirection: 'column', gap: 10 }}>

        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
          <div style={{ display: 'flex', gap: 8, alignItems: 'center' }}>
            {title && <span style={{ fontSize: 13, color: 'var(--pos-text-muted)' }}>{title}</span>}
            <div style={{ display: 'flex', gap: 4 }}>
              {(['abc','123'] as const).map(t => (
                <button key={t} type="button" onClick={() => setTab(t)}
                  style={{ ...(tab === t ? solidBtn(C.primary, false, true) : solidBtn(C.neutral)),
                    padding: '4px 12px', fontSize: 12, borderRadius: 6 }}>
                  {t.toUpperCase()}
                </button>
              ))}
            </div>
          </div>
          <button type="button"
            onMouseDown={e => { e.preventDefault(); onClose() }}
            style={{ background: 'none', border: 'none', cursor: 'pointer',
              color: '#9CA3AF', fontSize: 18, padding: 0, lineHeight: 1 }}>✕</button>
        </div>

        <div style={{ padding: '10px 14px', fontSize: 16, fontWeight: 500,
          borderRadius: 8, border: '0.5px solid var(--pos-border)',
          background: 'var(--pos-surface-alt)', minHeight: 44, color: 'var(--pos-text)',
          letterSpacing: 0.5, wordBreak: 'break-all' }}>
          {value || <span style={{ color: 'var(--pos-text-muted)' }}>—</span>}
        </div>

        {searchResults && searchResults.length > 0 && (
          <div style={{
            maxHeight: 160, overflowY: 'auto',
            border: '0.5px solid var(--pos-border)', borderRadius: 10,
            background: 'var(--pos-surface)',
          }}>
            {searchResults.map((c, i) => (
              <div key={c.id ?? i}
                role="button"
                tabIndex={0}
                onMouseDown={e => {
                  e.preventDefault()
                  onSelectResult?.(c)
                }}
                style={{ padding: '10px 14px', cursor: 'pointer',
                  display: 'flex', justifyContent: 'space-between', alignItems: 'center',
                  borderBottom: i < searchResults.length - 1 ? '0.5px solid #F3F4F6' : 'none',
                  background: 'var(--pos-surface)' }}
                onMouseEnter={e => { (e.currentTarget as HTMLDivElement).style.background = 'var(--pos-hover)' }}
                onMouseLeave={e => { (e.currentTarget as HTMLDivElement).style.background = 'var(--pos-surface)' }}>
                <div>
                  <div style={{ fontSize: 13, fontWeight: 500, color: 'var(--pos-text)' }}>{c.name}</div>
                  {c.phone && (
                    <div style={{ fontSize: 11, color: '#9CA3AF', marginTop: 1 }}>{c.phone}</div>
                  )}
                </div>
                <span style={{ fontSize: 11, color: '#9CA3AF',
                  fontFamily: 'monospace', flexShrink: 0, marginLeft: 8 }}>
                  {c.code}
                </span>
              </div>
            ))}
          </div>
        )}

        {searching && (
          <div style={{ textAlign: 'center', fontSize: 12, color: '#9CA3AF', padding: '8px 0' }}>
            ⟳ Aranıyor...
          </div>
        )}

        {tab === 'abc' && (
          <div style={{ display: 'flex', flexDirection: 'column', gap: 5 }}>
            {rows_abc.map((row, ri) => (
              <div key={ri} style={{ display: 'flex', gap: 4, justifyContent: 'center',
                padding: ri === 1 ? '0 4%' : ri === 2 ? '0 8%' : '0' }}>
                {row.map(k => (
                  <button key={k} type="button" onMouseDown={e => { e.preventDefault(); press(k) }}
                    style={{ ...keyStyle(), flex: 1, maxWidth: 44 }}>
                    {displayKey(k, shift)}
                  </button>
                ))}
              </div>
            ))}
            <div style={{ display: 'flex', gap: 4 }}>
              <button type="button" onMouseDown={e => { e.preventDefault(); setShift(s => !s) }}
                style={{ ...keyStyle(shift
                  ? { flex: 1.5, background: 'var(--pos-key-action-bg)', color: 'var(--pos-key-action-text)' }
                  : { flex: 1.5 }), fontSize: 16 }}>
                ⇧
              </button>
              <button type="button" onMouseDown={e => { e.preventDefault(); press('123') }}
                style={{ ...keyStyle({ flex: 1.5, fontSize: 12 }) }}>
                123
              </button>
              <button type="button" onMouseDown={e => { e.preventDefault(); press('@') }}
                style={{ ...keyStyle({ flex: 1 }) }}>
                @
              </button>
              <button type="button" onMouseDown={e => { e.preventDefault(); press('SPACE') }}
                style={{ ...keyStyle({ flex: 4 }), fontSize: 12 }}>
                boşluk
              </button>
              <button type="button" onMouseDown={e => { e.preventDefault(); press('.') }}
                style={keyStyle({ flex: 1 })}>.</button>
              <button type="button" onMouseDown={e => { e.preventDefault(); press('_') }}
                style={keyStyle({ flex: 1 })}>_</button>
              <button type="button" onMouseDown={e => { e.preventDefault(); press('⌫') }}
                style={{ ...keyStyle({ flex: 1.5 }), fontSize: 16 }}>
                ⌫
              </button>
            </div>
          </div>
        )}

        {tab === '123' && (
          <div style={{ display: 'flex', flexDirection: 'column', gap: 5 }}>
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(10,1fr)', gap: 4 }}>
              {rows_123_1.map(k => (
                <button key={k} type="button" onMouseDown={e => { e.preventDefault(); press(k) }}
                  style={keyStyle()}>{k}</button>
              ))}
            </div>
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(10,1fr)', gap: 4 }}>
              {rows_123_2.map(k => (
                <button key={k} type="button" onMouseDown={e => { e.preventDefault(); press(k) }}
                  style={keyStyle()}>{k}</button>
              ))}
            </div>
            <div style={{ display: 'flex', gap: 4 }}>
              <button type="button" onMouseDown={e => { e.preventDefault(); press('ABC') }}
                style={{ ...keyStyle({ flex: 1.5, fontSize: 12 }) }}>ABC</button>
              <button type="button" onMouseDown={e => { e.preventDefault(); press('(') }}
                style={keyStyle({ flex: 1 })}>(</button>
              <button type="button" onMouseDown={e => { e.preventDefault(); press(')') }}
                style={keyStyle({ flex: 1 })}>)</button>
              <button type="button" onMouseDown={e => { e.preventDefault(); press('SPACE') }}
                style={{ ...keyStyle({ flex: 3 }), fontSize: 12 }}>boşluk</button>
              <button type="button" onMouseDown={e => { e.preventDefault(); press(',') }}
                style={keyStyle({ flex: 1 })}>,</button>
              <button type="button" onMouseDown={e => { e.preventDefault(); press('.') }}
                style={keyStyle({ flex: 1 })}>.</button>
              <button type="button" onMouseDown={e => { e.preventDefault(); press('⌫') }}
                style={{ ...keyStyle({ flex: 1.5 }), fontSize: 16 }}>⌫</button>
            </div>
          </div>
        )}

        <div style={{ display: 'grid', gridTemplateColumns: '1fr 2fr', gap: 8, marginTop: 4 }}>
          <button type="button"
            onMouseDown={e => { e.preventDefault(); onChange('') }}
            style={{ padding: '12px 0', fontSize: 14, borderRadius: 10,
              border: '0.5px solid var(--pos-key-border)', background: 'var(--pos-key-bg)',
              cursor: 'pointer', color: 'var(--pos-key-text)' }}>
            Temizle
          </button>
          <button type="button" className="pos-key-action"
            onMouseDown={e => { e.preventDefault(); onConfirm(value) }}
            style={{ padding: '12px 0', fontSize: 14, fontWeight: 500,
              borderRadius: 10, border: 'none',
              background: 'var(--pos-key-action-bg)', color: 'var(--pos-key-action-text)', cursor: 'pointer' }}>
            Onayla
          </button>
        </div>

      </div>
    </div>
  )
}
