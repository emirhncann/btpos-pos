// Pavo REST API ile iletisim
import {
  parsePavoResult,
  normalizePavoSaleResult,
  deviceResultFromNormalizedPavo,
  isSuccessfulPavoPayment,
  type PaymentDeviceResult,
  type PavoFinalSale,
  type PavoFinalPayment,
} from './paymentDevice'
import { customerTypeOf, digitsOnly, splitPersonName } from './customerIdentity'

export {
  normalizePavoSaleResult,
  deviceResultFromNormalizedPavo,
  isSuccessfulPavoPayment,
  type PavoFinalSale,
  type PavoFinalPayment,
}

export interface PavoSettings {
  ipAddress: string
  port: number
  serialNo: string
  cardReadTimeout: number
  printWidth: '58mm' | '80mm'
}

/** Pavo CompleteSale: SMS + e-posta bildirimi */
export interface PavoSaleNotifyOptions {
  sendSms?: boolean
  smsPhone?: string | null
  sendEmail?: boolean
  mailAddr?: string | null
}

function normalizeTrMobilePavo(raw: string): string {
  let d = raw.replace(/\D/g, '')
  if (d.startsWith('90')) d = d.slice(2)
  while (d.startsWith('0')) d = d.slice(1)
  d = d.slice(0, 10)
  if (d.length > 0 && d[0] !== '5') return ''
  return d
}

function isValidNotificationEmail(s: string): boolean {
  const t = s.trim()
  if (t.length < 5 || !t.includes('@')) return false
  const [a, b] = t.split('@')
  return Boolean(a && b && b.includes('.'))
}

export function notificationPhoneDigitCount(s: string): number {
  return s.replace(/\D/g, '').length
}

export interface PavoSaleItem {
  name: string
  code?: string
  unitName?: string
  vatRate: number
  quantity: number
  unitPrice: number
  grossPrice: number
  totalPrice: number
  priceEffect?: {
    Type: number
    Rate: number
    Amount: number | null
  }
}

const TAX_GROUP: Record<number, string> = {
  0: 'KDV0',
  1: 'KDV1',
  8: 'KDV8',
  10: 'KDV10',
  18: 'KDV18',
  20: 'KDV20',
}

function taxGroupCode(vatRate: number): string {
  return TAX_GROUP[vatRate] ?? `KDV${vatRate}`
}

function buildCustomerParty(
  customer?: CustomerRow | null,
  notify?: PavoSaleNotifyOptions | null,
): Record<string, unknown> | undefined {
  if (!customer) return undefined
  const parts = (customer.name ?? '').split(' ')
  const partyMail = (() => {
    const m = String(notify?.mailAddr ?? '').trim()
    if (notify?.sendEmail && isValidNotificationEmail(m)) return m
    return String(customer.email ?? '').trim()
  })()
  return {
    CustomerType:  customer.isPerson ? 1 : 2,
    FirstName:     customer.isPerson ? (parts[0] ?? '') : '',
    MiddleName:    '',
    FamilyName:    customer.isPerson ? parts.slice(1).join(' ') : '',
    CompanyName:   customer.isPerson ? '' : (customer.name ?? ''),
    TaxOfficeCode: '',
    TaxNumber:     customer.taxNo  ?? '',
    Phone:         customer.phone  ?? '',
    EMail:         partyMail,
    Country:       'Türkiye',
    City:          customer.city     ?? '',
    District:      customer.district ?? '',
    Neighborhood:  '',
    Address:       customer.address  ?? '',
  }
}

function buildNotifyPhone(notify?: PavoSaleNotifyOptions | null): string {
  const raw = String(notify?.smsPhone ?? '')
  const norm = normalizeTrMobilePavo(raw)
  return Boolean(notify?.sendSms) && norm.length === 10 ? norm : ''
}

function buildNotifyMail(notify?: PavoSaleNotifyOptions | null): string {
  const m = String(notify?.mailAddr ?? '').trim()
  return Boolean(notify?.sendEmail) && isValidNotificationEmail(m) ? m : ''
}

/** CompleteSale ile aynı cihaz UI bayrakları — puanlı satış / müşteri sorularını atla */
function pavoDeviceUiFlags(settings: PavoSettings, opts?: { showCreditCardMenu?: boolean }) {
  return {
    ShowCreditCardMenu: Boolean(opts?.showCreditCardMenu),
    SelectedSlots: ['rf', 'icc', 'manual'],
    AllowDismissCardRead: false,
    CardReadTimeout: settings.cardReadTimeout,
    SkipAmountCash: true,
    CancelPaymentLater: true,
    AskCustomer: false,
    ShowLoyalty: false,
    SkipLoyalty: true,
    SendResponseBeforePrint: false,
  }
}

/** Fiş altına OrderNo barkodu — Pavo BottomPrintableItems (tek kaynak) */
export function buildBottomPrintableItems(
  orderNo: string,
  printWidth: '58mm' | '80mm' = '80mm',
): Array<{
  type:         string
  barcodeData:  string
  alignment:    string
  barcodeType:  string
  showText:     boolean
  fontSize:     number
  height:       number
  width:        number
}> {
  const width = printWidth === '58mm' ? 280 : 384
  const height = printWidth === '58mm' ? 150 : 200
  return [
    {
      type:        'dBarcode',
      barcodeData: orderNo,
      alignment:   'center',
      barcodeType: 'Code128',
      showText:    true,
      fontSize:    25,
      height,
      width,
    },
  ]
}

/** @deprecated buildBottomPrintableItems kullan */
export function buildOrderNoBottomPrintItems(
  orderNo: string,
  printWidth: '58mm' | '80mm',
) {
  return buildBottomPrintableItems(orderNo, printWidth)
}

function pavoBaseUrl(settings: PavoSettings): string {
  return `http://${settings.ipAddress}:${settings.port}`
}

function localISOString(): string {
  const now = new Date()
  const offset = now.getTimezoneOffset() * 60000
  const local = new Date(now.getTime() - offset)
  return local.toISOString().replace('Z', '').slice(0, 26)
}

function transactionHandle(settings: PavoSettings, seq: number) {
  return {
    SerialNumber: settings.serialNo,
    TransactionDate: localISOString(),
    TransactionSequence: seq,
    Fingerprint: 'test1',
  }
}

const CARI_TAX_MISSING = 'Carinin vergi/TC numarası eksik. Önce müşteri bilgisini düzenleyin.'

function maskTail(value: string): string {
  const s = String(value ?? '')
  if (s.length <= 4) return s ? '****' : ''
  return `${'*'.repeat(s.length - 4)}${s.slice(-4)}`
}

export type PavoAdvanceSaleBody = {
  TransactionHandle: ReturnType<typeof transactionHandle>
  Sale: {
    RefererApp: 'BTPOS'
    RefererAppVersion: string
    OrderNo: string
    TotalAmount: number
    SaleReason: string
    SendPhoneNotification: false
    SendEMailNotification: false
    SkipAmountCash: boolean
    AllowDismissCardRead: false
    CardReadTimeout: 60
    AskCustomer: false
    PaymentInformations: Array<{
      Mediator: number
      Amount: number
      CurrencyCode: 'TRY'
      ExchangeRate: 1
      IsVoid: false
    }>
    ReceiptInformation: {
      ReceiptWidth: '80mm'
      PrintCustomerReceipt: true
      PrintCustomerReceiptCopy: false
      PrintMerchantReceipt: true
    }
    CustomerParty: {
      CustomerType: 1 | 2
      FirstName: string
      MiddleName: ''
      FamilyName: string
      CompanyName: string
      TaxOfficeCode: ''
      TaxNumber: string
      Phone: string
      EMail: string
      Country: 'Türkiye'
      City: string
      District: string
      Neighborhood: ''
      Address: string
    }
  }
}

/** Cari tahsilat AdvanceSale gövdesi. Normal satış (/CompleteSale) bunu kullanmaz. */
export function buildPavoAdvanceSale(input: {
  settings: PavoSettings
  seq: number
  orderNo: string
  appVersion: string
  amount: number
  mediator: number
  customer: CustomerRow
  workplaceCity?: string | null
}): { ok: true; body: PavoAdvanceSaleBody } | { ok: false; message: string } {
  const tax = digitsOnly(String(input.customer.taxNo ?? ''))
  if (tax.length !== 10 && tax.length !== 11) {
    return { ok: false, message: CARI_TAX_MISSING }
  }
  if (input.mediator !== 1 && input.mediator !== 2) {
    return { ok: false, message: 'Ödeme yöntemi seçin.' }
  }

  const corporate = customerTypeOf({ type: input.customer.type, taxNo: tax }) === 'corporate'
  const city = String(input.customer.city ?? '').trim() || String(input.workplaceCity ?? '').trim()
  const district = String(input.customer.district ?? '').trim() || city
  const address = String(input.customer.address ?? '').trim() || (city ? `${city} Merkez` : '')
  const split = splitPersonName(input.customer.name ?? '')
  const storedFirst = String(input.customer.firstName ?? '').trim()
  const storedLast = String(input.customer.lastName ?? '').trim()
  const firstName = corporate ? '' : (storedFirst || split.first_name)
  const familyName = corporate ? '' : (storedLast || (storedFirst ? '' : split.last_name))
  const amount = Math.round(Number(input.amount) * 100) / 100
  const reason = `Tahsilat — ${String(input.customer.name ?? '').trim()}`.slice(0, 60)

  return {
    ok: true,
    body: {
      TransactionHandle: transactionHandle(input.settings, input.seq),
      Sale: {
        RefererApp: 'BTPOS',
        RefererAppVersion: String(input.appVersion ?? ''),
        OrderNo: input.orderNo,
        TotalAmount: amount,
        SaleReason: reason,
        SendPhoneNotification: false,
        SendEMailNotification: false,
        SkipAmountCash: input.mediator === 1,
        AllowDismissCardRead: false,
        CardReadTimeout: 60,
        AskCustomer: false,
        PaymentInformations: [{
          Mediator: input.mediator,
          Amount: amount,
          CurrencyCode: 'TRY',
          ExchangeRate: 1,
          IsVoid: false,
        }],
        ReceiptInformation: {
          ReceiptWidth: '80mm',
          PrintCustomerReceipt: true,
          PrintCustomerReceiptCopy: false,
          PrintMerchantReceipt: true,
        },
        CustomerParty: {
          CustomerType: corporate ? 2 : 1,
          FirstName: firstName,
          MiddleName: '',
          FamilyName: familyName,
          CompanyName: corporate ? String(input.customer.name ?? '').trim() : '',
          TaxOfficeCode: '',
          TaxNumber: tax,
          Phone: String(input.customer.phone ?? ''),
          EMail: String(input.customer.email ?? ''),
          Country: 'Türkiye',
          City: city,
          District: district,
          Neighborhood: '',
          Address: address,
        },
      },
    },
  }
}

function logAdvanceSaleBody(body: PavoAdvanceSaleBody): void {
  const party = body.Sale.CustomerParty
  console.debug('[pavo-advance] body', {
    ...body,
    Sale: {
      ...body.Sale,
      CustomerParty: {
        ...party,
        TaxNumber: maskTail(party.TaxNumber),
        Phone: maskTail(party.Phone),
      },
    },
  })
}

function isPavoSequenceError(data: Record<string, unknown>): boolean {
  if ([72, 73].includes(Number(data.ErrorCode))) return true
  const msg = String(data.ErrorMessage ?? data.Message ?? '').toLocaleLowerCase('tr-TR')
  return msg.includes('sıra') || msg.includes('sequence') || msg.includes('seq')
}

function pavoRetryHandle(data: Record<string, unknown>): Record<string, unknown> | null {
  const handle = data.TransactionHandle as Record<string, unknown> | undefined
  if (!handle) return null
  if (handle.TransactionDate == null || handle.TransactionSequence == null) return null
  return handle
}

function pavoCardWaitTimeoutMs(settings: PavoSettings): number {
  return ((settings.cardReadTimeout || 30) + 30) * 1000
}

async function pavoRequest(
  url: string,
  body: object,
  timeoutMs: number = 30_000,
): Promise<Record<string, unknown>> {
  const endpoint = url.split('/').pop() ?? url

  void window.electron.pavo.log({
    direction: 'REQUEST',
    endpoint,
    data: body,
  }).catch(() => {})

  const postJson = async (payload: object): Promise<Record<string, unknown>> => {
    const controller = new AbortController()
    const timer = setTimeout(() => controller.abort(), timeoutMs)

    try {
      const res = await fetch(url, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
        signal: controller.signal,
      })
      return res.json() as Promise<Record<string, unknown>>
    } catch (e) {
      if ((e as Error).name === 'AbortError') {
        throw new Error(`Pavo zaman aşımı (${timeoutMs / 1000}sn): ${endpoint}`)
      }
      const msg = e instanceof Error ? e.message : String(e)
      if (/failed to fetch|networkerror|load failed|fetch failed/i.test(msg)) {
        throw new Error(`Failed to fetch (${endpoint})`)
      }
      throw e
    } finally {
      clearTimeout(timer)
    }
  }

  const startTime = Date.now()
  let data = await postJson(body)

  for (let attempt = 0; attempt < 2; attempt++) {
    const hasError = data.HasError === true || data.IsError === true
    if (!hasError) break
    if (!isPavoSequenceError(data)) break

    const handle = pavoRetryHandle(data)
    if (!handle) break

    await syncPavoSequenceFromResponse(data)

    const retryBody = {
      ...(body as Record<string, unknown>),
      TransactionHandle: {
        ...((body as Record<string, unknown>).TransactionHandle as object),
        TransactionDate:     handle.TransactionDate,
        TransactionSequence: handle.TransactionSequence,
      },
    }
    data = await postJson(retryBody)
  }

  await syncPavoSequenceFromResponse(data)

  const durationMs = Date.now() - startTime

  void window.electron.pavo.log({
    direction:  'RESPONSE',
    endpoint,
    data,
    durationMs,
  }).catch(() => {})

  return data
}

export async function pavoPair(settings: PavoSettings, seq: number): Promise<PaymentDeviceResult> {
  try {
    const data = await pavoRequest(`${pavoBaseUrl(settings)}/Pairing`, {
      TransactionHandle: transactionHandle(settings, seq),
    })
    return parsePavoResult(data)
  } catch (e) {
    return { success: false, provider: 'pavo', message: String(e), raw: {} }
  }
}

/** PaymentMediators — bağlantı testi ve sequence senkronu. Hata metnini (ErrorCode dahil) olduğu gibi döner. */
export async function pavoTestConnection(settings: PavoSettings): Promise<{ success: boolean; message: string }> {
  try {
    const seq = await window.electron.db.nextPavoSequence()
    const data = await pavoRequest(`${pavoBaseUrl(settings)}/PaymentMediators`, {
      TransactionHandle: transactionHandle(settings, seq),
    }, 20_000)
    const hasError = data.HasError === true || data.IsError === true
    if (!hasError) return { success: true, message: 'Bağlantı başarılı' }
    const code = data.ErrorCode
    const base = pavoErrorMessage(data, 'Bağlantı hatası')
    const message = code != null && String(code) !== '' && Number(code) !== 0
      ? `${base} (ErrorCode ${code})`
      : base
    return { success: false, message }
  } catch (e) {
    return { success: false, message: String(e) }
  }
}

export async function pavoCompleteSale(
  settings: PavoSettings,
  seq: number,
  orderNo: string,
  grossAmount: number,
  amount: number,
  items: PavoSaleItem[],
  payments: Array<{
    Mediator: number
    Amount: number
    CurrencyCode: string
    ExchangeRate: number
    Brand?: number
  }>,
  explicitPriceEffect?: {
    Type: number
    Rate: number
    Amount: number
  },
  customer?: CustomerRow | null,
  notify?: PavoSaleNotifyOptions | null,
  opts?: { showCreditCardMenu?: boolean },
): Promise<PaymentDeviceResult> {
  const customerParty = buildCustomerParty(customer, notify)

  const saleItems = await Promise.all(items.map(async i => {
    const unitCode = await window.electron.db.getUnitPavoCode(i.unitName ?? 'Adet')
    return {
      Name:             i.name,
      IsGeneric:        false,
      UnitCode:         unitCode,
      TaxGroupCode:     taxGroupCode(i.vatRate),
      ItemQuantity:     i.quantity,
      UnitPriceAmount:  i.unitPrice,
      GrossPriceAmount: i.grossPrice,
      TotalPriceAmount: i.totalPrice,
      ...(i.code ? { StockReference: i.code } : {}),
      ...(i.priceEffect ? { PriceEffect: i.priceEffect } : {}),
    }
  }))
  const itemsTotal = saleItems.reduce((sum, item) => sum + Number(item.TotalPriceAmount ?? 0), 0)
  const priceEffectAmount = Math.max(0, parseFloat((itemsTotal - amount).toFixed(2)))
  const computedPriceEffect = priceEffectAmount > 0
    ? { Type: 2, Rate: 0, Amount: priceEffectAmount }
    : undefined
  const priceEffect = explicitPriceEffect ?? computedPriceEffect

  const phoneNorm = buildNotifyPhone(notify)
  const mailTrim = buildNotifyMail(notify)

  const body = {
    TransactionHandle: transactionHandle(settings, seq),
    Sale: {
      RefererApp: 'BTPOS',
      RefererAppVersion: '1.0.0',
      OrderNo: orderNo,
      MainDocumentType: 1,
      GrossPrice: grossAmount,
      TotalPrice: amount,
      CurrencyCode: 'TRY',
      ExchangeRate: 1,
      SendPhoneNotification: Boolean(phoneNorm),
      ...(phoneNorm ? { NotificationPhone: phoneNorm } : {}),
      SendEMailNotification: Boolean(mailTrim),
      ...(mailTrim ? { NotificationEMail: mailTrim } : {}),
      ...pavoDeviceUiFlags(settings, {
        showCreditCardMenu: Boolean(opts?.showCreditCardMenu),
      }),
      AddedSaleItems: saleItems,
      ...(priceEffect ? { PriceEffect: priceEffect } : {}),
      PaymentInformations: payments,
      ReceiptInformation: {
        ReceiptImageEnabled: false,
        ReceiptWidth: settings.printWidth,
        PrintCustomerReceipt: true,
        PrintCustomerReceiptCopy: false,
        PrintMerchantReceipt: true,
      },
      BottomPrintableItems: buildBottomPrintableItems(orderNo, settings.printWidth),
      ...(customerParty ? { CustomerParty: customerParty } : {}),
    },
  }

  try {
    const data = await pavoRequest(
      `${pavoBaseUrl(settings)}/CompleteSale`,
      body,
      pavoCardWaitTimeoutMs(settings),
    )
    return parsePavoResult(data)
  } catch (e) {
    const msg = e instanceof Error ? e.message : String(e)
    return { success: false, provider: 'pavo', message: msg, raw: {} }
  }
}

function cleanPavoRefString(v: unknown): string {
  const s = String(v ?? '').trim()
  if (!s || s === '0' || s === 'undefined' || s === 'null' || s === '[object Object]') return ''
  return s
}

function buildPavoSaleRef(ref: {
  saleId?: number | null
  saleNumber?: string | null
  orderNo?: string | null
}): Record<string, unknown> {
  const saleNumber = cleanPavoRefString(ref.saleNumber)
  if (saleNumber) return { SaleNumber: saleNumber }
  const orderNo = cleanPavoRefString(ref.orderNo)
  if (orderNo) return { OrderNo: orderNo }
  if (ref.saleId != null && Number(ref.saleId) > 0) return { Id: Number(ref.saleId) }
  return {}
}

function buildPavoAbandonSale(ref: {
  saleId?: number | null
  saleNumber?: string | null
  orderNo?: string | null
}): Record<string, unknown> {
  const saleNumber = cleanPavoRefString(ref.saleNumber)
  const orderNo = cleanPavoRefString(ref.orderNo)
  const saleId = Number(ref.saleId)
  const sale: Record<string, unknown> = {}
  if (saleNumber) sale.SaleNumber = saleNumber
  if (orderNo) sale.OrderNo = orderNo
  if (Number.isFinite(saleId) && saleId > 0) sale.Id = saleId
  return sale
}

export async function pavoStartSaleWithItems(
  settings: PavoSettings,
  seq: number,
  orderNo: string,
  grossAmount: number,
  amount: number,
  items: PavoSaleItem[],
  explicitPriceEffect?: {
    Type: number
    Rate: number
    Amount: number
  } | null,
  customer?: CustomerRow | null,
  notify?: PavoSaleNotifyOptions | null,
  opts?: { showCreditCardMenu?: boolean },
): Promise<{
  success: boolean
  message?: string
  saleId?: number
  saleNumber?: string
  remainingPaymentAmount?: number
  data?: unknown
}> {
  try {
    const saleItems = await Promise.all(items.map(async i => {
      const unitCode = await window.electron.db.getUnitPavoCode(i.unitName ?? 'Adet')
      return {
        Name:             i.name,
        IsGeneric:        false,
        UnitCode:         unitCode,
        TaxGroupCode:     taxGroupCode(i.vatRate),
        ItemQuantity:     i.quantity,
        UnitPriceAmount:  i.unitPrice,
        GrossPriceAmount: i.grossPrice,
        TotalPriceAmount: i.totalPrice,
        ...(i.code ? { StockReference: i.code } : {}),
        ...(i.priceEffect ? { PriceEffect: i.priceEffect } : {}),
      }
    }))

    const itemsTotal = saleItems.reduce((sum, item) => sum + Number(item.TotalPriceAmount ?? 0), 0)
    const priceEffectAmount = Math.max(0, parseFloat((itemsTotal - amount).toFixed(2)))
    const computedPriceEffect = priceEffectAmount > 0
      ? { Type: 2, Rate: 0, Amount: priceEffectAmount }
      : undefined
    const priceEffect = explicitPriceEffect ?? computedPriceEffect

    const customerParty = buildCustomerParty(customer, notify)
    const phoneNorm     = buildNotifyPhone(notify)
    const mailTrim      = buildNotifyMail(notify)

    const body = {
      TransactionHandle: transactionHandle(settings, seq),
      Sale: {
        RefererApp:            'BTPOS',
        RefererAppVersion:     '1.0.0',
        OrderNo:               orderNo,
        MainDocumentType:      1,
        GrossPrice:            grossAmount,
        TotalPrice:            amount,
        CurrencyCode:          'TRY',
        ExchangeRate:          1,
        SendPhoneNotification: Boolean(phoneNorm),
        ...(phoneNorm ? { NotificationPhone: phoneNorm } : {}),
        SendEMailNotification: Boolean(mailTrim),
        ...(mailTrim ? { NotificationEMail: mailTrim } : {}),
        ...pavoDeviceUiFlags(settings, {
          showCreditCardMenu: Boolean(opts?.showCreditCardMenu),
        }),
        ...(priceEffect ? { PriceEffect: priceEffect } : {}),
        AddedSaleItems:        saleItems,
        ReceiptInformation: {
          ReceiptWidth:             settings.printWidth,
          PrintCustomerReceipt:     true,
          PrintCustomerReceiptCopy: false,
          PrintMerchantReceipt:     true,
        },
        BottomPrintableItems: buildBottomPrintableItems(orderNo, settings.printWidth),
        ...(customerParty ? { CustomerParty: customerParty } : {}),
      },
    }

    console.log('[StartSaleWithItems] body:', JSON.stringify(body, null, 2))

    const data = await pavoRequest(
      `${pavoBaseUrl(settings)}/StartSaleWithItems`,
      body,
      30_000,
    )

    console.log('[StartSaleWithItems] response:', JSON.stringify(data, null, 2))
    await syncPavoSequenceFromResponse(data)

    if (data.HasError === true || data.IsError === true) {
      return { success: false, message: pavoErrorMessage(data, 'Sepet oluşturulamadı') }
    }

    const d = data.Data as Record<string, unknown> | undefined
    const saleId = Number(d?.SaleId ?? d?.Id ?? 0)
    const saleNumber = String(d?.SaleNumber ?? '').trim() || undefined
    const remainingPaymentAmount = Number(d?.RemainingPaymentAmount ?? amount)

    // Offline/askı satışta Id: 0 gelebilir; SaleNumber yeterli referans
    if (!(saleId > 0 || saleNumber)) {
      return { success: false, message: 'Sepet oluşturuldu ama satış referansı alınamadı' }
    }

    return { success: true, saleId, saleNumber, remainingPaymentAmount, data }
  } catch (e) {
    return { success: false, message: String(e) }
  }
}

export async function pavoAddPayment(
  settings: PavoSettings,
  seq: number,
  saleRef: {
    saleId?: number | null
    saleNumber?: string | null
    orderNo?: string | null
  },
  payment: {
    mediator: number
    amount: number
    currencyCode?: string
    brand?: number
  },
  saleTotals?: {
    grossPrice: number
    totalPrice: number
  },
  endpoint: 'AddPayment' | 'AddPaymentAndFinalizeSale' = 'AddPayment',
): Promise<{
  success: boolean
  message?: string
  remainingPaymentAmount?: number
  finalized?: boolean
  data?: unknown
}> {
  try {
    const ref = buildPavoSaleRef(saleRef)
    if (Object.keys(ref).length === 0) {
      return { success: false, message: 'Ödeme için satış referansı yok' }
    }

    const paymentInfo: Record<string, unknown> = {
      Mediator:     payment.mediator,
      Amount:       payment.amount,
      CurrencyCode: payment.currencyCode ?? 'TRY',
      ExchangeRate: 1,
      IsVoid:       false,
    }
    if (payment.brand && payment.brand !== 999) paymentInfo.Brand = payment.brand

    const orderNo = cleanPavoRefString(saleRef.orderNo)
    const body = {
      TransactionHandle: transactionHandle(settings, seq),
      Sale: {
        ...ref,
        ...(saleTotals ? {
          GrossPrice: saleTotals.grossPrice,
          TotalPrice: saleTotals.totalPrice,
        } : {}),
        PaymentInformations: [paymentInfo],
        ...pavoDeviceUiFlags(settings, {
          showCreditCardMenu: payment.brand === 999,
        }),
        ReceiptInformation: {
          ReceiptImageEnabled: false,
          ReceiptWidth: settings.printWidth,
          PrintCustomerReceipt: true,
          PrintCustomerReceiptCopy: false,
          PrintMerchantReceipt: true,
        },
        // Satış bu istekle kapanabilir — fiş barkodu burada basılmalı
        ...(orderNo ? {
          BottomPrintableItems: buildBottomPrintableItems(orderNo, settings.printWidth),
        } : {}),
      },
    }

    console.log(`[${endpoint}] body:`, JSON.stringify(body, null, 2))
    const data = await pavoRequest(
      `${pavoBaseUrl(settings)}/${endpoint}`,
      body,
      pavoCardWaitTimeoutMs(settings),
    )
    console.log(`[${endpoint}] response:`, JSON.stringify(data, null, 2))
    await syncPavoSequenceFromResponse(data)

    if (data.HasError === true || data.IsError === true) {
      return { success: false, message: pavoErrorMessage(data, 'Ödeme eklenemedi') }
    }

    const d = data.Data as Record<string, unknown> | undefined
    const remaining = Number(d?.RemainingPaymentAmount ?? 0)
    const finalized = remaining <= 0

    return { success: true, remainingPaymentAmount: remaining, finalized, data }
  } catch (e) {
    return { success: false, message: String(e) }
  }
}

export async function pavoFinalizeSale(
  settings: PavoSettings,
  seq: number,
  saleRef: {
    saleId?: number | null
    saleNumber?: string | null
    orderNo?: string | null
  },
): Promise<{ success: boolean; message?: string; data?: unknown }> {
  try {
    const ref = buildPavoSaleRef(saleRef)
    if (Object.keys(ref).length === 0) {
      return { success: false, message: 'Finalize için satış referansı yok' }
    }

    const orderNo = cleanPavoRefString(saleRef.orderNo)
    const body = {
      TransactionHandle: transactionHandle(settings, seq),
      Sale: {
        ...ref,
        ...(orderNo ? {
          BottomPrintableItems: buildBottomPrintableItems(orderNo, settings.printWidth),
        } : {}),
      },
    }

    const data = await pavoRequest(
      `${pavoBaseUrl(settings)}/FinalizeSale`,
      body,
      30_000,
    )
    await syncPavoSequenceFromResponse(data)

    if (data.HasError === true || data.IsError === true) {
      return { success: false, message: pavoErrorMessage(data, 'Satış kapatılamadı') }
    }

    return { success: true, data }
  } catch (e) {
    return { success: false, message: String(e) }
  }
}

export async function pavoCheckPendingSale(
  settings: PavoSettings,
  seq: number,
  orderNo: string,
): Promise<{
  success: boolean
  message?: string
  hasPending?: boolean
  saleId?: number
  saleNumber?: string
  remainingPaymentAmount?: number
  totalPrice?: number
  data?: unknown
}> {
  try {
    const body = {
      TransactionHandle: transactionHandle(settings, seq),
      Sale: { OrderNo: orderNo },
    }

    const data = await pavoRequest(
      `${pavoBaseUrl(settings)}/CheckPendingSale`,
      body,
      15_000,
    )
    await syncPavoSequenceFromResponse(data)

    if (data.HasError === true || data.IsError === true) {
      const msg = pavoErrorMessage(data, 'Kontrol başarısız')
      const notFound = msg.toLowerCase().includes('bulunamadı') || Number(data.ErrorCode) === 404
      return { success: true, hasPending: false, message: notFound ? 'Satış bulunamadı' : msg }
    }

    const d = data.Data as Record<string, unknown> | undefined
    return {
      success: true,
      hasPending: true,
      saleId: Number(d?.SaleId ?? d?.Id ?? 0),
      saleNumber: String(d?.SaleNumber ?? '').trim() || undefined,
      remainingPaymentAmount: Number(d?.RemainingPaymentAmount ?? 0),
      totalPrice: Number(d?.TotalPrice ?? 0),
      data,
    }
  } catch (e) {
    return { success: false, message: String(e) }
  }
}

export async function pavoAbandonSuspendedSale(
  settings: PavoSettings,
  seq: number,
  saleRef: {
    saleId?: number | null
    saleNumber?: string | null
    orderNo?: string | null
  },
): Promise<{ success: boolean; message?: string; data?: unknown }> {
  try {
    const ref = buildPavoAbandonSale(saleRef)
    if (!ref.SaleNumber && !ref.OrderNo) {
      return { success: false, message: 'İptal için SaleNumber veya OrderNo yok' }
    }

    const body = {
      TransactionHandle: transactionHandle(settings, seq),
      Sale: ref,
    }

    console.log('[AbandonSuspendedSale] body:', JSON.stringify(body))
    const data = await pavoRequest(
      `${pavoBaseUrl(settings)}/AbandonSuspendedSale`,
      body,
      15_000,
    )
    console.log('[AbandonSuspendedSale] response:', JSON.stringify(data))
    await syncPavoSequenceFromResponse(data)

    if (data.HasError === true || data.IsError === true) {
      const msg = pavoErrorMessage(data, 'İptal başarısız')
      const invalidRef = /saleNumber|order\s*no|geçersiz/i.test(msg)
      if (invalidRef && ref.SaleNumber && ref.OrderNo) {
        const retrySeq = await window.electron.db.nextPavoSequence()
        const retryBody = {
          TransactionHandle: transactionHandle(settings, retrySeq),
          Sale: { SaleNumber: ref.SaleNumber },
        }
        console.log('[AbandonSuspendedSale] retry SaleNumber only:', JSON.stringify(retryBody))
        const retry = await pavoRequest(
          `${pavoBaseUrl(settings)}/AbandonSuspendedSale`,
          retryBody,
          15_000,
        )
        await syncPavoSequenceFromResponse(retry)
        if (retry.HasError !== true && retry.IsError !== true) {
          return { success: true, data: retry }
        }
        const retry2Seq = await window.electron.db.nextPavoSequence()
        const retry2Body = {
          TransactionHandle: transactionHandle(settings, retry2Seq),
          Sale: { OrderNo: ref.OrderNo },
        }
        console.log('[AbandonSuspendedSale] retry OrderNo only:', JSON.stringify(retry2Body))
        const retry2 = await pavoRequest(
          `${pavoBaseUrl(settings)}/AbandonSuspendedSale`,
          retry2Body,
          15_000,
        )
        await syncPavoSequenceFromResponse(retry2)
        if (retry2.HasError !== true && retry2.IsError !== true) {
          return { success: true, data: retry2 }
        }
        return { success: false, message: pavoErrorMessage(retry2, msg) }
      }
      return { success: false, message: msg }
    }

    return { success: true, data }
  } catch (e) {
    return { success: false, message: String(e) }
  }
}

const COMPLETED_STATUS_IDS = [3, 4, 5, 6, 8, 9, 10, 18, 19, 20, 21, 22, 24]

export async function pavoGetSaleResult(
  settings: PavoSettings,
  seq: number,
  orderNo: string,
): Promise<{
  success: boolean
  message?: string
  status?: 'completed' | 'uncompleted' | 'suspended' | 'pending' | 'failed'
  statusId?: number
  saleId?: number
  saleNumber?: string
  notFound?: boolean
  data?: unknown
}> {
  try {
    const body = {
      TransactionHandle: transactionHandle(settings, seq),
      Sale: { OrderNo: orderNo },
    }

    const data = await pavoRequest(
      `${pavoBaseUrl(settings)}/GetSaleResult`,
      body,
      15_000,
    )
    await syncPavoSequenceFromResponse(data)

    if (data.HasError === true || data.IsError === true) {
      return {
        success: false,
        notFound: isPavoSaleNotFound(data),
        message: pavoErrorMessage(data, 'Sonuç alınamadı'),
      }
    }

    const d = data.Data as Record<string, unknown> | undefined
    const statusId = Number(d?.StatusId ?? d?.SaleStatusId ?? 0)
    const isOffline = Boolean(d?.IsOffline)
    const status: 'completed' | 'uncompleted' | 'suspended' | 'pending' | 'failed' =
      COMPLETED_STATUS_IDS.includes(statusId) ? 'completed' :
      statusId === 23 && isOffline ? 'uncompleted' :
      statusId === 23 ? 'uncompleted' :
      statusId === 1  ? 'suspended'  :
      statusId === 2  ? 'pending'    :
      'failed'

    return {
      success: true,
      status,
      statusId,
      saleId:     Number(d?.SaleId ?? d?.Id ?? 0),
      saleNumber: String(d?.SaleNumber ?? ''),
      data,
    }
  } catch (e) {
    return { success: false, message: String(e) }
  }
}

export interface PavoReturnableSaleItem {
  Id:                 number
  ProductName:        string
  Quantity:           number
  ReturnableQuantity: number
  UnitPrice:          number
  TotalPrice:         number
}

export interface PavoReturnableSale {
  Id:           number
  SaleNumber:   string
  CustomerInfo: { CustomerType?: number; CompanyName?: string } | null
  Items:        PavoReturnableSaleItem[]
  Payments:     Array<{
    Mediator:         number
    Amount:           number
    ReturnableAmount: number
    PaymentId:        number
  }>
}

function pavoErrorMessage(data: Record<string, unknown>, fallback: string): string {
  return String(data.ErrorMessage ?? data.Message ?? fallback)
}

/** GetSaleResult: cihaz ayakta, bu OrderNo kayıtlı değil. Ağ hatası değil. */
export function isPavoSaleNotFound(data: Record<string, unknown>): boolean {
  const msg = String(data.Message ?? data.ErrorMessage ?? '').toLocaleLowerCase('tr-TR')
  return msg.includes('nolu satış bulunamadı') || msg.includes('nolu satis bulunamadi')
}

function extractPavoSale(data: Record<string, unknown>): Record<string, unknown> | null {
  if (data.Sale && typeof data.Sale === 'object') {
    return data.Sale as Record<string, unknown>
  }
  const inner = data.Data as Record<string, unknown> | undefined
  if (inner?.Sale && typeof inner.Sale === 'object') {
    return inner.Sale as Record<string, unknown>
  }
  if (inner && typeof inner === 'object' && inner.Id != null) {
    return inner
  }
  return null
}

function pavoSaleItems(sale: Record<string, unknown>): unknown[] {
  const raw = sale.AddedSaleItems ?? sale.Items
  return Array.isArray(raw) ? raw : []
}

function pavoSalePayments(sale: Record<string, unknown>): unknown[] {
  const raw = sale.AddedPayments ?? sale.Payments
  return Array.isArray(raw) ? raw : []
}

function mapPavoReturnableItems(sale: Record<string, unknown>): PavoReturnableSaleItem[] {
  return pavoSaleItems(sale).map((row) => {
    const item = row as Record<string, unknown>
    const qty = Number(item.ItemQuantity ?? item.Quantity ?? 0)
    return {
      Id:                 Number(item.Id ?? item.RelatedSaleItemId ?? 0),
      ProductName:        String(item.Name ?? item.ProductName ?? ''),
      Quantity:           qty,
      ReturnableQuantity: Number(item.ReturnableQuantity ?? qty),
      UnitPrice:          Number(item.UnitPriceAmount ?? item.UnitPrice ?? 0),
      TotalPrice:         Number(item.TotalPriceAmount ?? item.TotalPrice ?? 0),
    }
  })
}

function mapPavoReturnablePayments(sale: Record<string, unknown>) {
  return pavoSalePayments(sale)
    .filter(p => Number((p as Record<string, unknown>).StatusId ?? 2) === 2)
    .map((row) => {
      const p = row as Record<string, unknown>
      const amount = Number(p.PaymentAmount ?? p.Amount ?? 0)
      return {
        Mediator:         Number(p.PaymentMediatorId ?? p.Mediator ?? 0),
        Amount:           amount,
        ReturnableAmount: Number(p.RemainingVoidableAmount ?? p.ReturnableAmount ?? amount),
        PaymentId:        Number(p.Id ?? p.PaymentId ?? 0),
      }
    })
}

async function syncPavoSequenceFromResponse(data: Record<string, unknown>): Promise<void> {
  const handle = data.TransactionHandle as Record<string, unknown> | undefined
  const pavoSeq = Number(handle?.TransactionSequence)
  if (Number.isFinite(pavoSeq)) {
    await window.electron.db.updatePavoSequence(pavoSeq)
  }
}

export async function pavoGetReturnableSale(
  settings: PavoSettings,
  seq: number,
  opts: { searchBy: 'order' | 'sale'; query: string },
): Promise<{ success: boolean; message?: string; data?: PavoReturnableSale }> {
  try {
    const query = opts.query.trim()
    const salePayload: Record<string, unknown> = {
      ReceiptImageEnabled: false,
      ReceiptJsonEnabled:  false,
      ReceiptTextEnabled:  false,
    }
    if (opts.searchBy === 'sale') {
      salePayload.SaleNumber = query
    } else {
      salePayload.OrderNo = query
    }

    const data = await pavoRequest(`${pavoBaseUrl(settings)}/GetReturnableSale`, {
      TransactionHandle: transactionHandle(settings, seq),
      Sale: salePayload,
    })

    await syncPavoSequenceFromResponse(data)

    if (data.HasError === true || data.IsError === true) {
      return { success: false, message: pavoErrorMessage(data, 'Satış bulunamadı') }
    }

    const sale = extractPavoSale(data)
    if (!sale) {
      return { success: false, message: 'Satış bulunamadı' }
    }

    const items = mapPavoReturnableItems(sale)
    const payments = mapPavoReturnablePayments(sale)

    const customerRaw = sale.CustomerInfo ?? sale.CustomerParty
    const customerInfo = customerRaw && typeof customerRaw === 'object'
      ? customerRaw as { CustomerType?: number; CompanyName?: string }
      : null

    return {
      success: true,
      data: {
        Id:           Number(sale.Id ?? 0),
        SaleNumber:   String(sale.SaleNumber ?? (opts.searchBy === 'sale' ? query : '')),
        CustomerInfo: customerInfo ?? null,
        Items:        items,
        Payments:     payments,
      },
    }
  } catch (e) {
    return { success: false, message: String(e) }
  }
}

export async function pavoPartialReturn(
  settings: PavoSettings,
  seq: number,
  opts: Record<string, unknown>,
): Promise<{ success: boolean; message?: string; data?: unknown }> {
  try {
    const printWidth = opts.ReceiptWidth ?? settings.printWidth

    const data = await pavoRequest(`${pavoBaseUrl(settings)}/PartialReturn`, {
      TransactionHandle: transactionHandle(settings, seq),
      Sale: {
        RefererApp:            'BTPOS',
        RefererAppVersion:     '1.0.0',
        IntegrationSaleType:   6,
        ...opts,
        ReceiptWidth:          printWidth,
        PrintCustomerReceipt:  opts.PrintCustomerReceipt ?? true,
        PrintMerchantReceipt:  opts.PrintMerchantReceipt ?? true,
      },
    })

    await syncPavoSequenceFromResponse(data)

    if (data.HasError === true || data.IsError === true) {
      return { success: false, message: pavoErrorMessage(data, 'İade başarısız') }
    }

    return { success: true, data }
  } catch (e) {
    return { success: false, message: String(e) }
  }
}

/** Pavo AdvanceSale — cari tahsilat. Gövde yalnızca buildPavoAdvanceSale'den gelir. */
export async function pavoAdvanceSale(
  settings: PavoSettings,
  body: PavoAdvanceSaleBody,
): Promise<{ success: boolean; message?: string; data?: unknown }> {
  try {
    logAdvanceSaleBody(body)
    const data = await pavoRequest(
      `${pavoBaseUrl(settings)}/AdvanceSale`,
      body,
      pavoCardWaitTimeoutMs(settings),
    )
    console.log('[AdvanceSale] response:', JSON.stringify(data, null, 2))

    await syncPavoSequenceFromResponse(data)

    if (data.HasError === true || data.IsError === true) {
      return { success: false, message: pavoErrorMessage(data, 'Tahsilat başarısız') }
    }

    const d = data.Data as Record<string, unknown> | undefined
    const payments = (d?.AddedPayments ?? []) as Array<Record<string, unknown>>

    const allFailed = payments.length > 0 && payments.every(p => Number(p.StatusId) === 3)

    if (allFailed) {
      const lastPayment = payments[payments.length - 1]
      const errMsg = (lastPayment?.OnlinePayment as Record<string, unknown>)
        ?.ResponseDescription as string ?? 'Ödeme başarısız'
      return { success: false, message: errMsg }
    }

    // Sale StatusId — 4=tamamlandı, 23=askıda (tamamlanmamış)
    const statusId = Number(d?.StatusId ?? 0)
    if (statusId !== 4) {
      return { success: false, message: 'Ödeme tamamlanamadı' }
    }

    return { success: true, data }
  } catch (e) {
    return { success: false, message: String(e) }
  }
}

export async function pavoCompleteUncompletedSale(
  settings: PavoSettings,
  seq: number,
  saleRef: { saleId?: number | null; saleNumber?: string | null; orderNo: string },
): Promise<{ success: boolean; message?: string; data?: unknown }> {
  try {
    const orderNo = cleanPavoRefString(saleRef.orderNo)
    const body = {
      TransactionHandle: transactionHandle(settings, seq),
      Sale: {
        SaleNumber: saleRef.saleNumber ?? undefined,
        Id:         saleRef.saleId    ?? undefined,
        OrderNo:    saleRef.orderNo,
        ...(orderNo ? {
          BottomPrintableItems: buildBottomPrintableItems(orderNo, settings.printWidth),
        } : {}),
      },
    }
    const data = await pavoRequest(
      `${pavoBaseUrl(settings)}/CompleteUncompletedSale`,
      body,
      15_000,
    )
    await syncPavoSequenceFromResponse(data)
    if (data.HasError === true || data.IsError === true) {
      return { success: false, message: pavoErrorMessage(data, 'Satış tamamlanamadı') }
    }
    return { success: true, data }
  } catch (e) {
    return { success: false, message: String(e) }
  }
}

function extractPendingSaleList(data: Record<string, unknown>): Record<string, unknown>[] {
  const collect = (raw: unknown): Record<string, unknown>[] => {
    if (Array.isArray(raw)) return raw as Record<string, unknown>[]
    if (typeof raw === 'string') {
      try { return collect(JSON.parse(raw)) } catch { return [] }
    }
    if (!raw || typeof raw !== 'object') return []
    const obj = raw as Record<string, unknown>
    const nested =
      obj.$values ?? obj.Sales ?? obj.SaleList ?? obj.PendingSales ??
      obj.List ?? obj.Data ?? obj.Result
    if (nested != null && nested !== raw) {
      const fromNested = collect(nested)
      if (fromNested.length > 0) return fromNested
    }
    if (obj.Id != null || obj.SaleId != null || obj.SaleNumber != null || obj.OrderNo != null) {
      return [obj]
    }
    return []
  }
  return collect(data.Data ?? data)
}

function mapPendingSaleRow(s: Record<string, unknown>): {
  saleId: number
  saleNumber: string
  orderNo: string
  totalPrice: number
  remainingPaymentAmount: number
  paidAmount: number
  items: Array<{
    name: string
    quantity: number
    unitPrice: number
    vatRate: number
    total: number
  }>
} {
  const nested = s.Sale && typeof s.Sale === 'object' ? s.Sale as Record<string, unknown> : null
  const sale = nested ? { ...s, ...nested } : s
  const payments = (sale.AddedPayments ?? s.AddedPayments ?? []) as Array<Record<string, unknown>>
  const isOffline = sale.IsOffline === true || s.IsOffline === true
  const paidAmount = payments
    .filter(p => Number(p.StatusId) === 2)
    .reduce((sum, p) => sum + Number(p.PaymentAmount ?? 0), 0)
  const totalPrice = Number(sale.TotalPrice ?? s.TotalPrice ?? 0)
  const remainingPaymentAmount = Math.max(0, totalPrice - paidAmount)
  const items = ((sale.AddedSaleItems ?? s.AddedSaleItems ?? []) as Array<Record<string, unknown>>).map(item => {
    const vatDirect = Number(item.VATRate ?? item.VatRate ?? item.TaxRate ?? 0)
    const vatFromCode = Number(String(item.TaxGroupCode ?? '').replace(/\D/g, '') || 0)
    const quantity = Number(item.ItemQuantity ?? item.Quantity ?? 1)
    const unitPrice = Number(item.UnitPriceAmount ?? item.UnitPrice ?? 0)
    const total = Number(item.TotalPriceAmount ?? item.TotalPrice ?? (quantity * unitPrice))
    return {
      code:      String(item.StockReference ?? item.ItemCode ?? item.ProductCode ?? '').trim(),
      name:      String(item.Name ?? item.ProductName ?? ''),
      quantity,
      unitPrice,
      vatRate:   vatDirect > 0 ? vatDirect : vatFromCode,
      total,
    }
  })
  return {
    saleId:     isOffline ? 0 : Number(sale.Id ?? s.Id ?? 0),
    saleNumber: cleanPavoRefString(sale.SaleNumber ?? s.SaleNumber),
    orderNo:    cleanPavoRefString(sale.OrderNo ?? s.OrderNo),
    totalPrice,
    remainingPaymentAmount,
    paidAmount,
    items,
  }
}

function isNoPendingSalesError(data: Record<string, unknown>): boolean {
  const code = Number(data.ErrorCode)
  if (code === 228) return true
  const msg = pavoErrorMessage(data, '').toLocaleLowerCase('tr-TR')
  return (
    msg.includes('askıda bekleyen satış bulunamadı') ||
    msg.includes('bekleyen satış bulunamadı') ||
    (msg.includes('askıda') && msg.includes('bulunamadı'))
  )
}

export async function pavoListPendingSales(
  settings: PavoSettings,
  seq: number,
): Promise<{
  success: boolean
  sales: Array<{
    saleId:                 number
    saleNumber:             string
    orderNo:                string
    totalPrice:             number
    remainingPaymentAmount: number
    paidAmount:             number
    items: Array<{
      code?:     string
      name:      string
      quantity:  number
      unitPrice: number
      vatRate:   number
      total:     number
    }>
  }>
  message?: string
}> {
  const call = async (endpoint: 'ListPendingSaleWithDetail' | 'ListPendingSale', sequence: number) => {
    const body = { TransactionHandle: transactionHandle(settings, sequence) }
    const data = await pavoRequest(
      `${pavoBaseUrl(settings)}/${endpoint}`,
      body,
      15_000,
    )
    await syncPavoSequenceFromResponse(data)
    console.log(`[pavo] ${endpoint} raw:`, JSON.stringify(data))
    if (data.HasError === true || data.IsError === true) {
      if (isNoPendingSalesError(data)) {
        return { success: true as const, sales: [], empty: true as const, data }
      }
      return {
        success: false as const,
        sales: [],
        empty: false as const,
        message: pavoErrorMessage(data, 'Liste alınamadı'),
        data,
      }
    }
    return {
      success: true as const,
      sales: extractPendingSaleList(data).map(mapPendingSaleRow),
      empty: false as const,
      data,
    }
  }

  try {
    const first = await call('ListPendingSaleWithDetail', seq)
    if (first.success) return { success: true, sales: first.sales }

    const seq2 = await window.electron.db.nextPavoSequence()
    const second = await call('ListPendingSale', seq2)
    if (second.success) return { success: true, sales: second.sales }

    return { success: false, sales: [], message: first.message ?? second.message }
  } catch (e) {
    return { success: false, sales: [], message: String(e) }
  }
}
